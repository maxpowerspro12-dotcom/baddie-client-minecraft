@echo off
title Baddy Client - Update
echo.
echo   ==========================================
echo         BADDY CLIENT  -  Schnell-Update
echo   ==========================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$c = Get-Content -LiteralPath '%~f0' -Raw; $i = $c.IndexOf('#' + 'PSCODE#'); Invoke-Expression $c.Substring($i + 8)"
if errorlevel 1 (
  echo.
  echo   Das Update hat nicht geklappt - siehe Fehler oben.
  echo   Bitte einen Screenshot von diesem Fenster machen.
  pause
  exit /b
)
timeout /t 5 >nul
exit /b

#PSCODE#
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try {
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  $base = 'https://raw.githubusercontent.com/maxpowerspro12-dotcom/baddie-client-minecraft/main/update/'
  $app = Join-Path $env:LOCALAPPDATA 'Programs\Baddy Client'
  $exe = Join-Path $app 'Baddy Client.exe'
  if (-not (Test-Path $exe)) { throw 'Der Baddy Client ist auf diesem PC nicht installiert. Bitte zuerst den Installer benutzen.' }

  Write-Host '  [1/4] Suche Update...'
  $info = Invoke-RestMethod -Uri ($base + 'update.json?t=' + [DateTime]::Now.Ticks) -UseBasicParsing -Headers @{ 'Cache-Control' = 'no-cache' }
  Write-Host "        Version $($info.version): $($info.notes)"

  Write-Host '  [2/4] Lade Update herunter...'
  $tmp = Join-Path $env:TEMP 'baddy-patch'
  if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
  New-Item -ItemType Directory -Path $tmp | Out-Null
  $zip = Join-Path $tmp 'update.zip'
  Invoke-WebRequest -Uri ($base + 'Baddy-Update.zip?t=' + [DateTime]::Now.Ticks) -OutFile $zip -UseBasicParsing
  Expand-Archive -Path $zip -DestinationPath (Join-Path $tmp 'files') -Force
  $files = Join-Path $tmp 'files'
  if (-not (Test-Path (Join-Path $files 'main.js'))) { throw 'Das Update-Paket ist unvollstaendig.' }

  Write-Host '  [3/4] Baue Update ein...'
  Get-Process -Name 'Baddy Client' -ErrorAction SilentlyContinue | Stop-Process -Force
  Start-Sleep -Milliseconds 800
  Copy-Item -Path (Join-Path $files '*') -Destination (Join-Path $app 'resources\app') -Recurse -Force

  # Mod direkt in Minecraft 1.21.11 legen (falls im Update dabei)
  $jar = Get-ChildItem (Join-Path $files 'mod') -Filter 'sigma-cosmetics-*.jar' -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($jar) {
    $mods = Join-Path $env:APPDATA '.sigmaclient\instances\1.21.11-fabric\mods'
    New-Item -ItemType Directory -Path $mods -Force | Out-Null
    Get-ChildItem $mods -Filter 'sigma-cosmetics-*' -ErrorAction SilentlyContinue | Remove-Item -Force
    Copy-Item $jar.FullName $mods
    Write-Host "        Mod aktualisiert: $($jar.Name)"
  }
  Remove-Item $tmp -Recurse -Force

  Write-Host '  [4/4] Starte den Baddy Client...'
  Start-Process $exe
  Write-Host ''
  Write-Host "  Fertig! Du hast jetzt Version $($info.version)."
} catch {
  Write-Host ''
  Write-Host "  FEHLER: $($_.Exception.Message)" -ForegroundColor Red
  exit 1
}
