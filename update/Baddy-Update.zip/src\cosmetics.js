// Farbschemata, Cosmetics und die Spieler-Vorschau des Baddy Client
(() => {
  // ================= Farbschemata =================
  const DARK_TEXT = { text: '#e6e8ee', muted: '#8a91a3', onAccent: '#ffffff' };
  const THEMES = [
    { id: 'sigma', name: 'Baddy Lila', bg: '#0b0c10', bg2: '#111318', panel: '#161920', panel2: '#1c2029', line: '#262b36', accent: '#8b5cf6', accent2: '#c084fc' },
    { id: 'ocean', name: 'Ozean', bg: '#071018', bg2: '#0b1621', panel: '#0f1d2b', panel2: '#142637', line: '#1e3448', accent: '#0ea5e9', accent2: '#67e8f9' },
    { id: 'bloodmoon', name: 'Blutmond', bg: '#0f0809', bg2: '#160c0e', panel: '#1d1013', panel2: '#261519', line: '#3a1f24', accent: '#ef4444', accent2: '#fb7185' },
    { id: 'emerald', name: 'Smaragd', bg: '#07100c', bg2: '#0b1712', panel: '#0f1f18', panel2: '#14281f', line: '#1f3a2d', accent: '#10b981', accent2: '#6ee7b7' },
    { id: 'sunset', name: 'Sonnenuntergang', bg: '#110a08', bg2: '#18100c', panel: '#201510', panel2: '#2a1b14', line: '#3d281d', accent: '#f97316', accent2: '#fbbf24' },
    { id: 'gold', name: 'Gold', bg: '#0e0c07', bg2: '#15120a', panel: '#1c180e', panel2: '#252013', line: '#3a321d', accent: '#eab308', accent2: '#fde047', onAccent: '#1a1404' },
    { id: 'bubblegum', name: 'Bubblegum', bg: '#100a0f', bg2: '#170e16', panel: '#1f121d', panel2: '#291826', line: '#3d2439', accent: '#ec4899', accent2: '#f9a8d4' },
    { id: 'ice', name: 'Eis', bg: '#0a0f14', bg2: '#0e151c', panel: '#131c25', panel2: '#19242f', line: '#263545', accent: '#7dd3fc', accent2: '#e0f2fe', onAccent: '#04121c' },
    { id: 'toxic', name: 'Toxic', bg: '#0a0d07', bg2: '#0f130a', panel: '#151b0e', panel2: '#1c2413', line: '#2c381d', accent: '#84cc16', accent2: '#d9f99d', onAccent: '#0d1404' },
    { id: 'midnight', name: 'Mitternacht', bg: '#000000', bg2: '#060606', panel: '#0d0d0d', panel2: '#151515', line: '#232323', accent: '#f5f5f5', accent2: '#a3a3a3', onAccent: '#000000' },
    { id: 'snow', name: 'Schnee (hell)', bg: '#f1f3f7', bg2: '#ffffff', panel: '#ffffff', panel2: '#eceff5', line: '#dce1ea', accent: '#7c3aed', accent2: '#a855f7', text: '#151821', muted: '#5d6475' }
  ].map(t => ({ ...DARK_TEXT, ...t }));

  const RARITY = {
    common: { name: 'Gewöhnlich', color: '#9ca3af' },
    rare: { name: 'Selten', color: '#3b82f6' },
    epic: { name: 'Episch', color: '#a855f7' },
    legendary: { name: 'Legendär', color: '#f59e0b' },
    mythic: { name: 'Mythisch', color: '#f43f5e', rainbow: true }
  };

  // ================= Hilfen =================
  let uid = 0;
  const nid = (p) => `${p}${++uid}`;
  const rnd = (a, b) => a + Math.random() * (b - a);
  const f1 = (n) => n.toFixed(1);
  function shade(hex, amt) { // amt -1..1 (dunkler..heller)
    const n = parseInt(hex.slice(1), 16);
    const c = [n >> 16, (n >> 8) & 255, n & 255].map(v => Math.round(amt < 0 ? v * (1 + amt) : v + (255 - v) * amt));
    return '#' + c.map(v => v.toString(16).padStart(2, '0')).join('');
  }
  function hslHex(h, sl, l) {
    const c = (1 - Math.abs(2 * l - 1)) * sl, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = l - c / 2;
    const [r, g, b] = h < 60 ? [c, x, 0] : h < 120 ? [x, c, 0] : h < 180 ? [0, c, x] : h < 240 ? [0, x, c] : h < 300 ? [x, 0, c] : [c, 0, x];
    return '#' + [r, g, b].map(v => Math.round((v + m) * 255).toString(16).padStart(2, '0')).join('');
  }
  const glowFilter = (id, color, sd = 3, op = .9) =>
    `<filter id="${id}" x="-40%" y="-40%" width="180%" height="180%"><feDropShadow dx="0" dy="0" stdDeviation="${sd}" flood-color="${color}" flood-opacity="${op}"/></filter>`;
  const lin = (id, stops, x2 = 1, y2 = 0) =>
    `<linearGradient id="${id}" x1="0" y1="0" x2="${x2}" y2="${y2}">${stops.map((c, i) => `<stop offset="${i / (stops.length - 1)}" stop-color="${c}"/>`).join('')}</linearGradient>`;
  const twinkle = (x, y, r, color, dur) =>
    `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(r)}" fill="${color}"><animate attributeName="opacity" values="0.15;1;0.15" dur="${f1(dur)}s" begin="-${f1(rnd(0, dur))}s" repeatCount="indefinite"/></circle>`;
  const sparkle = (x, y, s, color, dur) =>
    `<path d="M${x} ${y - s} Q${x + s * .2} ${y - s * .2} ${x + s} ${y} Q${x + s * .2} ${y + s * .2} ${x} ${y + s} Q${x - s * .2} ${y + s * .2} ${x - s} ${y} Q${x - s * .2} ${y - s * .2} ${x} ${y - s}Z" fill="${color}"><animate attributeName="opacity" values="0;1;0" dur="${dur}s" begin="-${f1(rnd(0, dur))}s" repeatCount="indefinite"/></path>`;

  // ================= Flügel (rechte Hälfte, Schulter bei 100/45) =================
  function featherFan(n, a0, a1, lenFn, w, fill, vein) {
    let s = '';
    for (let i = n - 1; i >= 0; i--) {
      const t = n === 1 ? 0 : i / (n - 1), a = a0 + (a1 - a0) * t, L = lenFn(t);
      s += `<path transform="translate(100 45) rotate(${f1(a)})" d="M0 0 C${f1(L * .25)} ${-w},${f1(L * .75)} ${f1(-w * .8)},${f1(L)} 0 C${f1(L * .75)} ${f1(w * .45)},${f1(L * .25)} ${f1(w * .6)},0 0Z" fill="${fill}" stroke="rgba(0,0,0,.28)" stroke-width=".6"/>`;
      s += `<path transform="translate(100 45) rotate(${f1(a)})" d="M${f1(L * .2)} ${f1(-w * .55)} C${f1(L * .5)} ${f1(-w * .85)},${f1(L * .8)} ${f1(-w * .6)},${f1(L * .97)} -.3" stroke="rgba(255,255,255,.22)" stroke-width=".7" fill="none"/>`;
      if (vein) s += `<path transform="translate(100 45) rotate(${f1(a)})" d="M3 0 L${f1(L * .9)} 0" stroke="${vein}" stroke-width=".7"/>`;
    }
    return s;
  }
  const PRIMARY = (t) => 98 * (1 - .5 * t);
  function marbleFan(n, a0, a1, lenFn, w, fill, ox = 100, oy = 45) {
    let s = '';
    for (let i = n - 1; i >= 0; i--) {
      const t = n === 1 ? 0 : i / (n - 1), a = a0 + (a1 - a0) * t, L = lenFn(t);
      const tr = `translate(${ox} ${oy}) rotate(${f1(a)})`;
      s += `<path transform="${tr}" d="M0 0 C${f1(L * .22)} ${-w},${f1(L * .7)} ${f1(-w * .95)},${f1(L)} ${f1(-w * .1)} C${f1(L * .72)} ${f1(w * .5)},${f1(L * .25)} ${f1(w * .7)},0 0Z" fill="${fill}" stroke="#000" stroke-width=".9"/>`;
      // weiße Marmor-Adern
      const veins = 1 + Math.floor(rnd(0, 2.6));
      for (let v = 0; v < veins; v++) {
        const x0 = L * rnd(.15, .45), x1 = L * rnd(.6, .95), yy = rnd(-w * .45, w * .25);
        s += `<path transform="${tr}" d="M${f1(x0)} ${f1(yy)} q${f1((x1 - x0) * .35)} ${f1(rnd(-w * .6, w * .6))} ${f1((x1 - x0) * .6)} ${f1(rnd(-w * .3, w * .3))} t${f1((x1 - x0) * .4)} ${f1(rnd(-w * .3, w * .3))}" stroke="#ffffff" stroke-opacity="${f1(rnd(.45, .95))}" stroke-width="${f1(rnd(.4, 1.5))}" fill="none" stroke-linecap="round"/>`;
      }
      if (Math.random() < .55) s += `<circle transform="${tr}" cx="${f1(L * rnd(.3, .85))}" cy="${f1(rnd(-w * .4, w * .2))}" r="${f1(rnd(.6, 1.4))}" fill="#fff" opacity=".9"/>`;
      s += `<path transform="${tr}" d="M${f1(L * .25)} ${f1(-w * .7)} C${f1(L * .55)} ${f1(-w * .95)},${f1(L * .85)} ${f1(-w * .55)},${f1(L * .98)} ${f1(-w * .12)}" stroke="rgba(255,255,255,.3)" stroke-width=".6" fill="none"/>`;
    }
    return s;
  }
  function fanPoint(maxFrac = .9) {
    const t = Math.random(), a = (-25 + 95 * t) * Math.PI / 180, r = rnd(14, PRIMARY(t) * maxFrac);
    return [100 + r * Math.cos(a), 45 + r * Math.sin(a)];
  }
  function wingHalf(item, ids) {
    const [c1, c2] = item.colors || ['#888', '#ccc'];
    switch (item.style) {
      case 'membrane': {
        const g = ids.g;
        return `<path d="M100 45 L140 18 L196 8 Q178 30 190 46 Q170 56 172 78 Q150 78 140 92 Q118 70 100 58Z" fill="url(#${g})" stroke="${shade(c1, -.4)}" stroke-width="1"/>
          <path d="M100 45 L140 18 L196 8 M140 18 L190 46 M140 18 L172 78 M140 18 L140 92" stroke="${shade(c1, -.5)}" stroke-width="2.6" stroke-linecap="round" fill="none"/>
          <path d="M100 45 L140 18 L196 8 M140 18 L190 46 M140 18 L172 78 M140 18 L140 92" stroke="${item.glow || shade(c2, .3)}" stroke-width=".8" stroke-linecap="round" fill="none" opacity=".8"><animate attributeName="opacity" values=".3;1;.3" dur="2.4s" repeatCount="indefinite"/></path>
          <path d="M140 18 l-3 -7 l7 4Z" fill="${shade(c2, .5)}"/><path d="M196 8 l6 -3 l-3 6Z" fill="${shade(c2, .5)}"/>`;
      }
      case 'mecha': {
        let s = `<polygon points="100,45 186,8 192,40 176,74 150,94" fill="${item.glow}" opacity=".12"><animate attributeName="opacity" values=".05;.22;.05" dur="2s" repeatCount="indefinite"/></polygon>`;
        for (let i = 4; i >= 0; i--) {
          const a = -26 + i * 23, L = 94 - i * 11;
          s += `<g transform="translate(100 45) rotate(${a})"><path d="M0 -3.5 L${L - 9} -6.5 L${L} 0 L${L - 9} 5.5 L0 3.5Z" fill="url(#${ids.g})" stroke="${item.glow}" stroke-width="1"/>
            <path d="M6 0 L${L - 12} 0" stroke="${item.glow}" stroke-width=".6" opacity=".6"/>
            <circle cx="${L - 5}" cy="0" r="2.2" fill="${item.glow}"><animate attributeName="opacity" values=".3;1;.3" dur="1.4s" begin="-${i * .25}s" repeatCount="indefinite"/></circle></g>`;
        }
        return s + `<circle cx="100" cy="45" r="7" fill="#0f172a" stroke="${item.glow}" stroke-width="2"/><circle cx="100" cy="45" r="2.5" fill="${item.glow}"/>`;
      }
      case 'crystal': {
        let s = '';
        for (let i = 6; i >= 0; i--) {
          const t = i / 6, a = -25 + 92 * t, L = 92 * (1 - .45 * t), w = 10;
          s += `<g transform="translate(100 45) rotate(${f1(a)})"><path d="M0 0 L${f1(L * .55)} ${-w} L${f1(L)} 0 L${f1(L * .55)} ${f1(w * .7)}Z" fill="url(#${ids.g})" stroke="rgba(255,255,255,.75)" stroke-width=".7"/>
            <path d="M0 0 L${f1(L)} 0 M${f1(L * .55)} ${-w} L${f1(L * .7)} 0" stroke="rgba(255,255,255,.45)" stroke-width=".5"/></g>`;
        }
        for (let i = 0; i < 6; i++) { const [x, y] = fanPoint(.95); s += sparkle(x, y, 3, '#fff', rnd(1.5, 3)); }
        return s;
      }
      case 'starfeather': {
        let s = featherFan(9, -25, 70, PRIMARY, 9.5, `url(#${ids.g})`, 'rgba(255,255,255,.45)');
        s += featherFan(6, -15, 50, t => 58 * (1 - .4 * t), 7.5, `url(#${ids.g2})`, 'rgba(255,255,255,.35)');
        s += `<g transform="translate(0 30)">${featherFan(6, 8, 62, t => 50 * (1 - .35 * t), 7, `url(#${ids.g})`, 'rgba(255,255,255,.45)')}</g>`;
        for (let i = 0; i < 46; i++) { const [x, y] = fanPoint(.95); s += twinkle(x, y, rnd(.35, 1.1), '#fff', rnd(1, 3)); }
        for (let i = 0; i < 14; i++) {
          const a = rnd(8, 62) * Math.PI / 180, r = rnd(10, 44);
          s += twinkle(100 + r * Math.cos(a), 75 + r * Math.sin(a), rnd(.35, 1), '#fff', rnd(1, 3));
        }
        for (let i = 0; i < 7; i++) {
          const [x, y] = fanPoint(.85);
          s += `<path d="M${f1(x)} ${f1(y)} q${f1(rnd(4, 9))} ${f1(rnd(-6, 6))} ${f1(rnd(10, 16))} ${f1(rnd(-3, 3))}" stroke="rgba(255,255,255,.55)" stroke-width="${f1(rnd(.6, 1.4))}" fill="none" stroke-linecap="round"/>`;
        }
        return s;
      }
      case 'frostdragon': {
        const bolt = (x0, y0, x1, y1, n) => {
          let d = `M${x0} ${y0}`;
          for (let i = 1; i <= n; i++) {
            const t = i / n, j = i === n ? 0 : rnd(-4, 4);
            d += ` L${f1(x0 + (x1 - x0) * t + j)} ${f1(y0 + (y1 - y0) * t + j * .6)}`;
          }
          return d;
        };
        const VE = item.vein || '#38bdf8', V2 = item.vein2 || '#7dd3fc', ED = item.edge || '#bae6fd', SP = item.spike || '#e0f2fe', CO = item.core || '#f0f9ff';
        const memb = 'M100 45 L140 18 L196 8 Q178 30 190 46 Q170 56 172 78 Q150 78 140 92 Q118 70 100 58Z';
        let s = `<path d="M100 40 L138 12 L199 1 L196 8 L140 18 L100 45Z" fill="${ED}" opacity=".55"/>
          <path d="${memb}" fill="url(#${ids.g})" stroke="${V2}" stroke-width="1.2"/>`;
        for (let i = 0; i < 30; i++) {
          const [x, y] = fanPoint(.85);
          if (y > 12 && y < 88) s += twinkle(x, y, rnd(.4, 1.2), V2, rnd(1, 2.6));
        }
        let veins = '';
        for (const [x1, y1] of [[194, 10], [188, 44], [170, 76], [140, 90], [118, 66]]) {
          veins += bolt(100, 46, x1, y1, 7) + ' ';
          veins += bolt(100 + (x1 - 100) * .45, 46 + (y1 - 46) * .45, 100 + (x1 - 100) * .7 + rnd(-10, 10), 46 + (y1 - 46) * .7 + rnd(-10, 10), 3) + ' ';
        }
        s += `<path d="${veins}" stroke="${VE}" stroke-width="1.6" fill="none" stroke-linejoin="round"><animate attributeName="opacity" values=".55;1;.7;1;.55" dur="1.6s" repeatCount="indefinite"/></path>
          <path d="${veins}" stroke="${CO}" stroke-width=".5" fill="none" stroke-linejoin="round"/>
          <path d="M100 45 L140 18 L196 8 M140 18 L190 46 M140 18 L172 78 M140 18 L140 92" stroke="${SP}" stroke-width="1.4" stroke-linecap="round" fill="none" opacity=".85"/>`;
        for (const [x, y] of [[190, 46], [182, 50], [172, 78], [164, 80], [140, 92], [132, 86], [124, 76], [196, 8]]) {
          s += `<path d="M${x - 3} ${y} L${x} ${y + rnd(6, 11)} L${x + 3} ${y}Z" fill="${SP}" opacity=".9"/>`;
        }
        return s;
      }
      case 'marble': {
        const dark = `url(#${ids.g})`;
        let s = `<path d="M98 46 Q132 16 190 2" stroke="#050505" stroke-width="6" stroke-linecap="round" fill="none"/>`;
        // unteres, kleines Flügelpaar
        s += marbleFan(8, 14, 72, t => 52 * (1 - .35 * t), 7, dark, 100, 74);
        // großes Flügelpaar: Schwungfedern, Deckfedern, Schulterfedern
        s += marbleFan(13, -24, 66, t => 100 * (1 - .52 * t), 8, dark);
        s += marbleFan(10, -24, 52, t => 66 * (1 - .45 * t), 7, dark);
        s += marbleFan(7, -18, 38, () => 34, 6, dark);
        for (let i = 0; i < 70; i++) { const [x, y] = fanPoint(.95); s += twinkle(x, y, rnd(.25, .9), '#fff', rnd(.8, 2.6)); }
        for (let i = 0; i < 8; i++) { const [x, y] = fanPoint(.9); s += sparkle(x, y, rnd(1.6, 3.2), '#ffffff', rnd(1.5, 3.5)); }
        return s;
      }
      case 'aurora': {
        let s = `<path d="M98 46 Q132 18 187 4\" stroke="${shade(c1, -.2)}" stroke-width="5" stroke-linecap="round" fill="none"/>`;
        s += featherFan(10, -26, 72, PRIMARY, 9.5, `url(#${ids.g})`, 'rgba(255,255,255,.35)');
        s += featherFan(8, -20, 58, t => 64 * (1 - .45 * t), 7.5, `url(#${ids.g2})`, 'rgba(255,255,255,.3)');
        s += featherFan(5, -15, 40, () => 32, 6, shade(c1, .15), 'rgba(255,255,255,.25)');
        s += `<path d="M104 40 Q140 20 180 12" stroke="rgba(255,255,255,.75)" stroke-width="2.5" fill="none" stroke-linecap="round" opacity="0"><animate attributeName="opacity" values="0;.9;0" dur="3s" repeatCount="indefinite"/></path>`;
        for (let i = 0; i < 16; i++) { const [x, y] = fanPoint(.95); s += sparkle(x, y, rnd(1.5, 3), '#ffffff', rnd(1.5, 3.5)); }
        return s;
      }
      case 'seraph': {
        let s = featherFan(9, -30, 55, PRIMARY, 10, `url(#${ids.g})`, '#fde68a');
        s += featherFan(6, -22, 45, t => 60 * (1 - .4 * t), 8, `url(#${ids.g2})`, '#fde68a');
        s += `<g transform="translate(0 32)">${featherFan(7, 5, 70, t => 56 * (1 - .4 * t), 8, `url(#${ids.g})`, '#fde68a')}</g>`;
        s += `<path d="M98 44 Q134 14 188 0" stroke="#f59e0b" stroke-width="2.4" fill="none" stroke-linecap="round"/>`;
        for (let i = 0; i < 18; i++) { const [x, y] = fanPoint(.95); s += sparkle(x, y, rnd(1.2, 2.6), '#fef3c7', rnd(1.5, 3)); }
        return s;
      }
      case 'butterfly':
        return `<path d="M100 45 C120 -5,190 -10,186 25 C183 48,140 52,100 47Z" fill="url(#${ids.g})" stroke="${shade(c1, -.5)}" stroke-width="1.4"/>
          <path d="M100 48 C140 52,172 70,160 95 C150 112,118 90,100 50Z" fill="url(#${ids.g2})" stroke="${shade(c1, -.5)}" stroke-width="1.4"/>
          <path d="M100 46 L178 8 M100 46 L186 30 M100 46 L150 46 M100 49 L156 84 M100 49 L130 90" stroke="rgba(0,0,0,.3)" stroke-width=".8" fill="none"/>
          <circle cx="158" cy="22" r="10" fill="${shade(c2, .25)}" opacity=".9"/><circle cx="158" cy="22" r="5" fill="${shade(c1, -.5)}"/><circle cx="160" cy="20" r="1.6" fill="#fff"/>
          <circle cx="140" cy="78" r="6" fill="${shade(c2, .3)}" opacity=".9"/><circle cx="140" cy="78" r="2.6" fill="${shade(c1, -.5)}"/>`;
      default: { // Federn (Engel, Phönix, Galaxie, Rabe)
        let s = `<path d="M98 46 Q132 18 187 4" stroke="${shade(c1, -.2)}" stroke-width="5" stroke-linecap="round" fill="none"/>`;
        s += featherFan(9, -25, 70, PRIMARY, 9, `url(#${ids.g})`, 'rgba(255,255,255,.25)');
        s += featherFan(7, -20, 55, t => 62 * (1 - .45 * t), 7.5, `url(#${ids.g2})`, 'rgba(255,255,255,.2)');
        s += featherFan(5, -15, 40, () => 32, 6, shade(c1, .1));
        if (item.style === 'phoenix') {
          for (let i = 0; i < 12; i++) {
            const [x, y] = fanPoint(1), d = rnd(1.2, 2.4);
            s += `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(rnd(1, 2.2))}" fill="${i % 2 ? '#fde047' : '#fb923c'}"><animate attributeName="cy" from="${f1(y)}" to="${f1(y - 26)}" dur="${f1(d)}s" begin="-${f1(rnd(0, d))}s" repeatCount="indefinite"/><animate attributeName="opacity" values="1;0" dur="${f1(d)}s" begin="-${f1(rnd(0, d))}s" repeatCount="indefinite"/></circle>`;
          }
        }
        if (item.style === 'galaxy') {
          for (let i = 0; i < 26; i++) { const [x, y] = fanPoint(.95); s += twinkle(x, y, rnd(.5, 1.3), '#fff', rnd(1.2, 3)); }
          for (let i = 0; i < 4; i++) { const [x, y] = fanPoint(.8); s += sparkle(x, y, 3, '#e9d5ff', rnd(2, 4)); }
        }
        return s;
      }
    }
  }
  function wingsSVG(item) {
    const ids = { g: nid('wg'), g2: nid('wg'), f: nid('wf') };
    const [c1, c2] = item.colors || ['#475569', '#cbd5e1'];
    const defs = lin(ids.g, item.style === 'mecha' ? ['#1f2937', '#64748b'] : (item.colors && item.colors.length > 2 ? item.colors : [c1, c2])) +
      lin(ids.g2, [shade(c1, .15), shade(c2, .35)]) + (item.glow ? glowFilter(ids.f, item.glow, 3.2) : '');
    const half = wingHalf(item, ids);
    const foldWrap = (h) => `<g transform="translate(100 45)"><g><animateTransform attributeName="transform" type="scale" values=".32 1;1 1;1 1;.32 1;.32 1" keyTimes="0;.25;.65;.9;1" dur="5s" repeatCount="indefinite"/><g transform="translate(-100 -45)">${h}</g></g></g>`;
    const flap = `<animateTransform attributeName="transform" type="rotate" values="0 100 45;-9 100 45;0 100 45" dur="${item.flap || 1.8}s" repeatCount="indefinite"/>`;
    return `<svg viewBox="0 0 200 120"><defs>${defs}</defs><g${item.glow ? ` filter="url(#${ids.f})"` : ''}>
      ${item.fold ? `<g>${foldWrap(half)}</g><g transform="translate(200 0) scale(-1 1)">${foldWrap(half)}</g>` : `<g>${flap}${half}</g><g transform="translate(200 0) scale(-1 1)"><g>${flap}${half}</g></g>`}</g></svg>`;
  }

  // ================= Umhänge (Rückansicht) =================
  const CAPE = 'M3 0 H87 Q88 95 90 184 Q45 193 0 184 Q2 95 3 0Z';
  function capeSVG(item) {
    const c = nid('cc'), g = nid('cg'), f = nid('cf');
    let defs = `<clipPath id="${c}"><path d="${CAPE}"/></clipPath>`, body = '', border = '#000', cls = '';
    switch (item.style) {
      case 'sigma':
        defs += lin(g, ['#2e1065', '#6d28d9', '#a855f7'], 0, 1) + glowFilter(f, '#c084fc', 4);
        body = `<rect width="90" height="192" fill="url(#${g})"/>
          <path d="M8 6 H82 L84 176 Q45 184 6 176Z" fill="none" stroke="#fbbf24" stroke-width="1.6"/>
          <text x="45" y="116" text-anchor="middle" font-size="74" font-weight="900" font-family="Segoe UI,Arial" fill="#fff" filter="url(#${f})">Σ</text>`;
        for (let i = 0; i < 10; i++) body += twinkle(rnd(10, 80), rnd(10, 175), rnd(.6, 1.3), '#f5d0fe', rnd(1.5, 3));
        border = '#1e1035'; break;
      case 'galaxy': {
        const b = nid('cb');
        defs += lin(g, ['#020617', '#1e1b4b', '#4c1d95'], 0, 1) + `<filter id="${b}"><feGaussianBlur stdDeviation="11"/></filter>`;
        body = `<rect width="90" height="192" fill="url(#${g})"/><g filter="url(#${b})" opacity=".75">
          <circle cx="22" cy="55" r="24" fill="#ec4899"/><circle cx="68" cy="120" r="28" fill="#3b82f6"/><circle cx="38" cy="168" r="20" fill="#a855f7"/></g>`;
        for (let i = 0; i < 42; i++) body += twinkle(rnd(4, 86), rnd(4, 186), rnd(.4, 1.3), '#fff', rnd(1, 3.5));
        for (let i = 0; i < 4; i++) body += sparkle(rnd(12, 78), rnd(15, 170), 3.5, '#fff', rnd(2, 4));
        border = '#0b0820'; break;
      }
      case 'lava':
        defs += `<linearGradient id="${g}" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="0" y2="80" spreadMethod="reflect">
          <stop offset="0" stop-color="#1c0a00"/><stop offset=".35" stop-color="#991b1b"/><stop offset=".7" stop-color="#ea580c"/><stop offset="1" stop-color="#fde047"/>
          <animateTransform attributeName="gradientTransform" type="translate" from="0 0" to="0 160" dur="5s" repeatCount="indefinite"/></linearGradient>`;
        body = `<rect width="90" height="192" fill="url(#${g})"/>
          <path d="M0 30 L20 42 L34 30 L52 48 L70 36 L90 50 M0 92 L18 80 L40 100 L58 86 L90 104 M0 150 L24 140 L44 160 L66 146 L90 158" stroke="#1c0a00" stroke-width="4" fill="none" opacity=".55"/>`;
        border = '#1c0a00'; break;
      case 'rainbow':
        defs += lin(g, ['#ef4444', '#f97316', '#eab308', '#22c55e', '#3b82f6', '#8b5cf6', '#ec4899'], 1, 1);
        body = `<rect width="90" height="192" fill="url(#${g})"/>
          <path d="M-20 60 L110 0 M-20 110 L110 50 M-20 160 L110 100 M-20 210 L110 150" stroke="rgba(255,255,255,.25)" stroke-width="7"/>`;
        cls = 'hue'; border = '#1f1f1f'; break;
      case 'storm': {
        const b = nid('cb');
        defs += lin(g, ['#020617', '#1e293b', '#334155'], 0, 1) + glowFilter(f, '#fde047', 4) + `<filter id="${b}"><feGaussianBlur stdDeviation="6"/></filter>`;
        body = `<rect width="90" height="192" fill="url(#${g})"/><g filter="url(#${b})" fill="#64748b" opacity=".8"><circle cx="15" cy="10" r="18"/><circle cx="45" cy="4" r="20"/><circle cx="78" cy="12" r="18"/></g>
          <polygon points="54,26 32,96 48,96 36,166 68,80 52,80 64,26" fill="#fde047" filter="url(#${f})"><animate attributeName="opacity" values="1;1;.15;1;.4;1;1" dur="2.6s" repeatCount="indefinite"/></polygon>`;
        border = '#020617'; break;
      }
      case 'sakura':
        defs += lin(g, ['#fdf2f8', '#f9a8d4', '#db2777'], 0, 1);
        body = `<rect width="90" height="192" fill="url(#${g})"/><path d="M90 30 Q60 60 52 100 M66 58 Q52 52 40 60 M58 82 Q76 92 84 110" stroke="#4a2c2a" stroke-width="3" fill="none" stroke-linecap="round"/>`;
        for (let i = 0; i < 18; i++) body += `<ellipse cx="${f1(rnd(6, 84))}" cy="${f1(rnd(10, 180))}" rx="3.2" ry="1.8" fill="#fff" opacity=".85" transform="rotate(${f1(rnd(0, 180))} 45 96)"/>`;
        border = '#831843'; break;
      case 'ocean':
        defs += lin(g, ['#082f49', '#0369a1', '#38bdf8'], 0, 1);
        body = `<rect width="90" height="192" fill="url(#${g})"/>`;
        for (let i = 0; i < 6; i++) body += `<path d="M-30 ${30 + i * 28} q15 -8 30 0 t30 0 t30 0 t30 0 t30 0" stroke="rgba(255,255,255,.35)" stroke-width="2.5" fill="none"><animateTransform attributeName="transform" type="translate" values="0 0;30 0" dur="${2 + i * .3}s" repeatCount="indefinite"/></path>`;
        border = '#082f49'; break;
      case 'aurora': {
        const b = nid('cb');
        defs += lin(g, ['#020617', '#0f172a', '#1e1b4b'], 0, 1) + `<filter id="${b}"><feGaussianBlur stdDeviation="7"/></filter>`;
        body = `<rect width="90" height="192" fill="url(#${g})"/><g filter="url(#${b})" opacity=".85">
          <path d="M-10 40 Q30 10 50 50 T110 40" stroke="#22c55e" stroke-width="16" fill="none"><animateTransform attributeName="transform" type="translate" values="0 0;0 10;0 0" dur="6s" repeatCount="indefinite"/></path>
          <path d="M-10 90 Q35 60 55 100 T110 85" stroke="#06b6d4" stroke-width="14" fill="none"><animateTransform attributeName="transform" type="translate" values="0 0;0 -8;0 0" dur="7s" repeatCount="indefinite"/></path>
          <path d="M-10 140 Q30 115 50 150 T110 135" stroke="#a855f7" stroke-width="14" fill="none"/></g>`;
        for (let i = 0; i < 30; i++) body += twinkle(rnd(4, 86), rnd(4, 186), rnd(.4, 1.1), '#fff', rnd(1, 3));
        border = '#020617'; break;
      }
      case 'scales': {
        defs += lin(g, ['#064e3b', '#065f46', '#022c22'], 0, 1);
        body = `<rect width="90" height="192" fill="url(#${g})"/>`;
        for (let r = 0; r < 20; r++) for (let c = 0; c < 7; c++) {
          const x = c * 14 + (r % 2 ? 7 : 0) - 4, y = r * 10 - 2;
          body += `<path d="M${x} ${y} q7 12 14 0" fill="${r % 3 ? '#10b981' : '#34d399'}" opacity=".55" stroke="#022c22" stroke-width=".8"/>`;
        }
        body += `<path d="M45 20 L45 175" stroke="#fbbf24" stroke-width="1.2" opacity=".6"/>`;
        border = '#022c22'; break;
      }
      case 'custom': {
        const c1 = item.c1 || '#7c3aed', c2 = item.c2 || '#1e1b4b';
        defs += lin(g, [c1, c2], 0, 1) + glowFilter(f, item.border || '#ffffff', 3);
        body = `<rect width="90" height="192" fill="url(#${g})"/>`;
        if (item.pattern === 'stars') for (let i = 0; i < 34; i++) body += twinkle(rnd(4, 86), rnd(4, 186), rnd(.4, 1.3), '#fff', rnd(1, 3));
        if (item.pattern === 'stripes') body += `<path d="M-20 60 L110 0 M-20 110 L110 50 M-20 160 L110 100 M-20 210 L110 150" stroke="rgba(255,255,255,.22)" stroke-width="9"/>`;
        if (item.pattern === 'waves') for (let i = 0; i < 6; i++) body += `<path d="M-30 ${30 + i * 28} q15 -8 30 0 t30 0 t30 0 t30 0 t30 0" stroke="rgba(255,255,255,.3)" stroke-width="2.5" fill="none"/>`;
        if (item.border) body += `<path d="M8 6 H82 L84 176 Q45 184 6 176Z" fill="none" stroke="${item.border}" stroke-width="1.6"/>`;
        if (item.emblem) body += `<text x="45" y="116" text-anchor="middle" font-size="64" font-weight="900" font-family="Segoe UI,Segoe UI Symbol,Arial" fill="${item.border || '#fff'}" filter="url(#${f})">${item.emblem}</text>`;
        border = shade(c2, -.5); break;
      }
      case 'image': {
        const bg = item.bg || '#111827', z = (item.zoom || 100) / 100, w = 90 * z, h = 192 * z;
        const x = (90 - w) / 2 + (item.ox || 0) * .9, y = (192 - h) / 2 + (item.oy || 0) * 1.92;
        body = `<rect width="90" height="192" fill="${bg}"/>` + (item.image
          ? `<image href="${item.image}" x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${w.toFixed(1)}" height="${h.toFixed(1)}" preserveAspectRatio="xMidYMid ${item.fit === 'contain' ? 'meet' : 'slice'}"/>`
          : `<text x="45" y="96" text-anchor="middle" font-size="11" font-family="Segoe UI,Arial" fill="#94a3b8">PNG hochladen</text>`);
        const bc = item.borderColor || '#ffffff', bw = item.borderW ?? 3;
        if (bw > 0) {
          if (item.borderGlow) defs += glowFilter(f, bc, 3.5);
          body += `<path d="${CAPE}" fill="none" stroke="${bc}" stroke-width="${bw * 2}"${item.borderGlow ? ` filter="url(#${f})"` : ''}/>`;
        }
        border = bw > 0 ? bc : shade(bg, -.4); break;
      }
      default:
        body = `<rect width="90" height="192" fill="#b91c1c"/><path d="M8 6 H82 L84 176 Q45 184 6 176Z" fill="none" stroke="#fff" stroke-width="2"/>`;
        border = '#450a0a';
    }
    return `<svg viewBox="0 0 90 192" class="${cls}"><defs>${defs}</defs><g clip-path="url(#${c})">${body}
      <rect width="90" height="192" fill="url(#${nid('x')})" opacity="0"/></g><path d="${CAPE}" fill="none" stroke="${border}" stroke-width="2"/>
      <path d="M3 0 H87" stroke="rgba(255,255,255,.35)" stroke-width="2"/></svg>`;
  }

  // ================= Kopf =================
  function headSVG(item) {
    const g = nid('hg'), f = nid('hf'), c = item.color || '#8b5cf6';
    switch (item.kind) {
      case 'band': {
        const dark = shade(c, -.35);
        return `<svg viewBox="0 0 130 40"><defs>${lin(g, [shade(c, .25), c, dark], 0, 1)}${item.glow ? glowFilter(f, item.glow, 2.5) : ''}</defs>
          <g${item.glow ? ` filter="url(#${f})"` : ''}>
          <g><animateTransform attributeName="transform" type="rotate" values="0 89 18;9 89 18;0 89 18;-5 89 18;0 89 18" dur="1.9s" repeatCount="indefinite"/>
            <path d="M88 14 C100 9,112 16,128 7 L126 16 C112 22,100 18,88 20Z" fill="${c}" stroke="rgba(0,0,0,.3)" stroke-width=".6"/>
            <path d="M88 18 C100 22,110 30,124 33 L119 38 C106 33,98 28,88 22Z" fill="${dark}" stroke="rgba(0,0,0,.3)" stroke-width=".6"/></g>
          <path d="M0 12 Q44 6 88 12 L88 24 Q44 18 0 24Z" fill="url(#${g})" stroke="rgba(0,0,0,.35)" stroke-width=".8"/>
          ${item.pattern === 'rainbow' ? `<defs><linearGradient id="${g}r"><stop offset="0" stop-color="#ef4444"/><stop offset=".33" stop-color="#eab308"/><stop offset=".66" stop-color="#22c55e"/><stop offset="1" stop-color="#8b5cf6"/></linearGradient></defs><path d="M0 12 Q44 6 88 12 L88 24 Q44 18 0 24Z" fill="url(#${g}r)"/>` : ''}
          ${item.pattern === 'stripes' || item.pattern === 'checker' ? `<path d="M0 18 Q44 12 88 18" stroke="${item.color2 || '#fff'}" stroke-width="12" stroke-dasharray="5 5" fill="none" opacity=".85"/>` : ''}
          ${item.pattern === 'dots' ? [10, 22, 34, 54, 66, 78].map(x => `<circle cx="${x}" cy="${18 - (44 - Math.abs(x - 44)) * .14}" r="1.8" fill="${item.color2 || '#fff'}"/>`).join('') : ''}
          ${item.gem ? `<rect x="40" y="13" width="8" height="8" transform="rotate(45 44 17)" fill="${item.gem}" stroke="#fff" stroke-width=".8"/>` : ''}
          <path d="M2 14 Q44 9 86 14" stroke="rgba(255,255,255,.45)" stroke-width="1" fill="none"/>
          <ellipse cx="89" cy="17" rx="5" ry="6" fill="${dark}" stroke="rgba(0,0,0,.3)" stroke-width=".6"/>
          ${(item.emblem || item.text) ? `<text x="44" y="21.5" text-anchor="middle" font-size="11" font-weight="900" font-family="Segoe UI,Segoe UI Symbol,Arial" fill="${/^#(f|e|d)/i.test(c) ? '#111' : '#fff'}">${item.emblem || item.text}</text>` : ''}</g></svg>`;
      }
      case 'halo': {
        const col = item.color || '#fbbf24';
        let spikes = '';
        if (item.spikes) for (let i = 0; i < 14; i++) {
          const a = i / 14 * Math.PI * 2, x = 50 + Math.cos(a) * 40, y = 20 + Math.sin(a) * 11, x2 = 50 + Math.cos(a) * 47, y2 = 20 + Math.sin(a) * 15;
          spikes += `<path d="M${f1(x)} ${f1(y)} L${f1(x2)} ${f1(y2)}" stroke="${col}" stroke-width="2.4" stroke-linecap="round"/>`;
        }
        return `<svg viewBox="0 0 100 40"><defs>${glowFilter(f, col, 3.5)}</defs><g filter="url(#${f})">
          <ellipse cx="50" cy="20" rx="38" ry="10" fill="none" stroke="${shade(col, .5)}" stroke-width="9" opacity=".3"><animate attributeName="opacity" values=".15;.45;.15" dur="2.2s" repeatCount="indefinite"/></ellipse>
          <ellipse cx="50" cy="20" rx="38" ry="10" fill="none" stroke="${col}" stroke-width="3.6"/>${spikes}
          ${sparkle(14, 14, 3, '#fff', 2.2)}${sparkle(84, 25, 2.5, '#fff', 2.8)}</g></svg>`;
      }
      case 'crown': {
        const [a, b, d] = item.colors || ['#fde68a', '#f59e0b', '#92400e'];
        return `<svg viewBox="0 0 70 40"><defs>${lin(g, [a, b, d], 0, 1)}${glowFilter(f, item.glow || '#fde047', 2)}</defs><g filter="url(#${f})">
          <path d="M4 36 L4 14 L18 24 L26 6 L35 20 L44 6 L52 24 L66 14 L66 36Z" fill="url(#${g})" stroke="${d}" stroke-width="1.2"/>
          <rect x="4" y="29" width="62" height="7" fill="${d}" opacity=".55"/>
          <circle cx="4" cy="13" r="2.6" fill="${a}"/><circle cx="26" cy="5" r="2.6" fill="${a}"/><circle cx="44" cy="5" r="2.6" fill="${a}"/><circle cx="66" cy="13" r="2.6" fill="${a}"/>
          <circle cx="35" cy="31" r="3.4" fill="${item.gem || '#ef4444'}" stroke="#fff" stroke-width=".6"/><circle cx="17" cy="32" r="2.4" fill="${item.gem2 || '#3b82f6'}"/><circle cx="53" cy="32" r="2.4" fill="${item.gem2 || '#3b82f6'}"/>
          ${sparkle(20, 16, 3.5, '#fff', 2)}${sparkle(50, 14, 3, '#fff', 2.6)}</g></svg>`;
      }
      case 'horns': {
        const [a, b] = item.colors || ['#7f1d1d', '#ef4444'];
        const horn = `<path d="M30 44 C22 30, 8 24, 6 2 C20 14, 32 22, 42 40Z" fill="url(#${g})" stroke="${shade(a, -.5)}" stroke-width="1"/>
          ${item.glow ? `<path d="M30 40 C24 30 14 24 10 10" stroke="${item.glow}" stroke-width="1.2" fill="none"><animate attributeName="opacity" values=".2;1;.2" dur="1.8s" repeatCount="indefinite"/></path>` : ''}
          <path d="M26 36 L34 32 M20 28 L28 25 M14 20 L22 18" stroke="rgba(0,0,0,.35)" stroke-width="1.2"/>`;
        return `<svg viewBox="0 0 110 45"><defs>${lin(g, [a, b], 0, -1)}${item.glow ? glowFilter(f, item.glow, 2.5) : ''}</defs>
          <g${item.glow ? ` filter="url(#${f})"` : ''}>${horn}<g transform="translate(110 0) scale(-1 1)">${horn}</g></g></svg>`;
      }
      case 'headset':
        return `<svg viewBox="0 0 100 60"><defs>${glowFilter(f, '#a855f7', 2.5)}</defs>
          <path d="M14 34 C14 0, 86 0, 86 34" stroke="#111827" stroke-width="6" fill="none"/><path d="M18 30 C18 6, 82 6, 82 30" stroke="#374151" stroke-width="1.5" fill="none"/>
          <rect x="3" y="27" width="17" height="27" rx="7" fill="#111827"/><rect x="80" y="27" width="17" height="27" rx="7" fill="#111827"/>
          <g filter="url(#${f})"><rect x="6" y="31" width="11" height="19" rx="5" fill="none" stroke-width="2.2"><animate attributeName="stroke" values="#ef4444;#22c55e;#3b82f6;#a855f7;#ef4444" dur="4s" repeatCount="indefinite"/></rect>
          <rect x="83" y="31" width="11" height="19" rx="5" fill="none" stroke-width="2.2"><animate attributeName="stroke" values="#ef4444;#22c55e;#3b82f6;#a855f7;#ef4444" dur="4s" repeatCount="indefinite"/></rect></g>
          <path d="M12 52 Q14 59 30 58" stroke="#111827" stroke-width="2.5" fill="none"/><circle cx="31" cy="58" r="2.5" fill="#374151"/></svg>`;
      case 'wizard':
        return `<svg viewBox="0 0 90 80"><defs>${lin(g, ['#a855f7', '#5b21b6', '#2e1065'], 0, 1)}</defs>
          <path d="M45 3 Q50 30 70 64 L20 64 Q36 34 45 3Z" fill="url(#${g})" stroke="#1e1035" stroke-width="1.2"/>
          <path d="M45 3 Q58 -2 66 8" stroke="#5b21b6" stroke-width="4" fill="none" stroke-linecap="round"/>
          <path d="M26 54 L64 54 L67 60 L23 60Z" fill="#fbbf24"/>
          <ellipse cx="45" cy="66" rx="44" ry="10" fill="#4c1d95" stroke="#1e1035" stroke-width="1.2"/>
          <path d="M40 30 a6 6 0 1 0 6 8 a5 5 0 1 1 -6 -8Z" fill="#fde047"/>
          ${sparkle(54, 40, 3.5, '#fde047', 2)}${sparkle(34, 46, 2.5, '#fff', 2.6)}${sparkle(48, 20, 2.5, '#fff', 3)}</svg>`;
      default: return '';
    }
  }

  // ================= Schuhe =================
  function bootsSVG(item) {
    const g = nid('bg'), f = nid('bf'), [a, b] = item.colors || ['#78350f', '#a16207'];
    const boot = (x) => `<g transform="translate(${x} 0)">
      <path d="M0 6 H38 V34 Q38 38 34 38 H4 Q0 38 0 34Z" fill="url(#${g})" stroke="${item.neon || shade(a, -.5)}" stroke-width="${item.neon ? 1.6 : 1}"/>
      <rect x="0" y="6" width="38" height="6" fill="${item.cuff || shade(b, .3)}" opacity=".9"/>
      <rect x="0" y="33" width="38" height="5" rx="2" fill="${item.sole || shade(a, -.55)}"/>
      <path d="M12 16 L26 16 M12 21 L26 21 M12 26 L26 26" stroke="rgba(255,255,255,.3)" stroke-width="1.2"/></g>`;
    let fx = '';
    if (item.fx === 'fire') for (const x of [8, 19, 30, 50, 61, 72]) fx += `<path d="M${x} 46 C${x + 6} 40 ${x + 4} 36 ${x} 30 C${x - 4} 36 ${x - 6} 40 ${x} 46Z" fill="${x % 2 ? '#fde047' : '#f97316'}"><animateTransform attributeName="transform" type="scale" values="1 1;1 1.25;1 .9;1 1" dur="${f1(rnd(.5, .9))}s" repeatCount="indefinite" additive="sum"/></path>`;
    if (item.fx === 'jet') for (const x of [19, 65]) fx += `<path d="M${x - 8} 38 Q${x} 62 ${x + 8} 38Z" fill="#38bdf8" opacity=".9"><animate attributeName="d" values="M${x - 8} 38 Q${x} 58 ${x + 8} 38Z;M${x - 8} 38 Q${x} 66 ${x + 8} 38Z;M${x - 8} 38 Q${x} 58 ${x + 8} 38Z" dur=".25s" repeatCount="indefinite"/></path><path d="M${x - 4} 38 Q${x} 52 ${x + 4} 38Z" fill="#fff"/>`;
    if (item.fx === 'ice') for (let i = 0; i < 8; i++) fx += sparkle(rnd(4, 84), rnd(30, 46), 2.6, '#e0f2fe', rnd(1.2, 2.4));
    if (item.fx === 'cloud') fx = `<g fill="#f8fafc" opacity=".95"><animateTransform attributeName="transform" type="translate" values="0 0;0 -1.5;0 0" dur="2s" repeatCount="indefinite"/>
      <circle cx="6" cy="40" r="7"/><circle cx="18" cy="43" r="8"/><circle cx="30" cy="40" r="7"/><circle cx="54" cy="40" r="7"/><circle cx="66" cy="43" r="8"/><circle cx="80" cy="40" r="7"/></g>`;
    if (item.fx === 'gold') fx = sparkle(14, 18, 4, '#fff', 1.8) + sparkle(64, 24, 3.5, '#fff', 2.4);
    if (item.fx === 'neon') fx = `<ellipse cx="44" cy="42" rx="44" ry="4" fill="${item.neon}" opacity=".35"><animate attributeName="opacity" values=".15;.5;.15" dur="1.6s" repeatCount="indefinite"/></ellipse>`;
    const under = item.fx === 'cloud' || item.fx === 'jet';
    return `<svg viewBox="0 0 88 48" style="overflow:visible"><defs>${lin(g, [b, a], 0, 1)}${item.neon ? glowFilter(f, item.neon, 2) : ''}</defs>
      ${under ? fx : ''}<g${item.neon ? ` filter="url(#${f})"` : ''}>${boot(4)}${boot(46)}</g>${under ? '' : fx}</svg>`;
  }

  // ================= Auren (Partikel) =================
  const SHAPES = {
    flame: '<svg viewBox="0 0 10 14"><path d="M5 0C9 5 9 9 7 12C6 13.5 4 13.5 3 12C1 9 1 5 5 0Z" fill="#f97316"/><path d="M5 5C7 8 7 10 6 11.5C5.5 12.2 4.5 12.2 4 11.5C3 10 3 8 5 5Z" fill="#fde047"/></svg>',
    snow: '<svg viewBox="0 0 12 12"><path d="M6 0V12M0 6H12M1.8 1.8L10.2 10.2M10.2 1.8L1.8 10.2" stroke="#e0f2fe" stroke-width="1.4" stroke-linecap="round"/></svg>',
    heart: '<svg viewBox="0 0 12 11"><path d="M6 11C2 8 0 6 0 3.4C0 1.4 1.5 0 3.3 0C4.5 0 5.4.6 6 1.5C6.6.6 7.5 0 8.7 0C10.5 0 12 1.4 12 3.4C12 6 10 8 6 11Z" fill="#f43f5e"/></svg>',
    star: '<svg viewBox="0 0 12 12"><path d="M6 0Q7 5 12 6Q7 7 6 12Q5 7 0 6Q5 5 6 0Z" fill="#fde68a"/></svg>',
    petal: '<svg viewBox="0 0 12 8"><ellipse cx="6" cy="4" rx="6" ry="3.2" fill="#f9a8d4"/><ellipse cx="5" cy="3.4" rx="3" ry="1.4" fill="#fdf2f8"/></svg>',
    spark: '<svg viewBox="0 0 10 14"><path d="M6 0L1 8H5L3 14L9 5H5Z" fill="#fde047"/></svg>',
    orb: '<svg viewBox="0 0 10 10"><circle cx="5" cy="5" r="5" fill="#7c3aed" opacity=".5"/><circle cx="5" cy="5" r="2.6" fill="#e9d5ff"/></svg>'
  };
  const RUNES = 'ᚠᚢᚦᚨᚱᚲᚷᚹᚺᚾᛁᛃᛇᛈᛉᛊᛏᛒᛖᛗᛚᛜᛞᛟ';
  function ringSVG(color, runes) {
    let s = `<svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="46" fill="none" stroke="${color}" stroke-width="2" opacity=".9"/><circle cx="50" cy="50" r="36" fill="none" stroke="${color}" stroke-width="1" opacity=".6"/>`;
    if (runes) for (let i = 0; i < 16; i++) s += `<text x="50" y="12" font-size="8" text-anchor="middle" fill="${color}" transform="rotate(${i * 22.5} 50 50)">${RUNES[i % RUNES.length]}</text>`;
    return s + '</svg>';
  }
  function auraHTML(item, count) {
    let h = '';
    if (item.ring) h += `<div class="ring" style="--rc:${item.ring}"><div>${ringSVG(item.ring, item.runes)}</div></div>`;
    for (let i = 0; i < count; i++) {
      const shape = item.shapes[i % item.shapes.length];
      const content = shape === 'rune' ? `<span class="glyph" style="color:${item.ring || '#c084fc'}">${RUNES[Math.floor(rnd(0, RUNES.length))]}</span>` : SHAPES[shape];
      const mode = item.mode || 'rise';
      h += `<span class="pt ${mode}" style="--x:${f1(rnd(18, 82))}%;--y:${f1(mode === 'fall' ? rnd(-5, 40) : rnd(45, 95))}%;--s:${f1(rnd(5, 9))}cqw;--t:${f1(rnd(2.2, 4.5))}s;--d:-${f1(rnd(0, 4.5))}s;--r:${f1(rnd(-180, 180))}deg">${content}</span>`;
    }
    return h;
  }

  // ================= Plushies =================
  function plushSVG(p) {
    if (p.type === 'chibi') return boxesSVG(chibiBoxes(p));
    const g = nid('pg'), body = p.body, belly = p.belly || shade(body, .55), dark = shade(body, -.35);
    const eye = (x) => `<ellipse cx="${x}" cy="45" rx="4" ry="4.8" fill="${p.eyes || '#1a1a2e'}"><animate attributeName="ry" values="4.8;4.8;.5;4.8" keyTimes="0;.92;.96;1" dur="4.5s" repeatCount="indefinite"/></ellipse><circle cx="${x + 1.4}" cy="43.2" r="1.4" fill="#fff"/>`;
    let back = '', ears = '', face = '', extra = '', front = '';
    switch (p.type) {
      case 'fox':
        back = `<path d="M70 82 C96 80 100 52 86 46 C84 62 76 70 66 72Z" fill="${body}" stroke="${dark}" stroke-width="1"/><path d="M90 52 C96 58 94 66 88 70 C88 62 87 57 86 46Z" fill="#fff7ed"/>`;
        ears = `<path d="M26 32 L24 6 L44 20Z" fill="${body}" stroke="${dark}" stroke-width="1"/><path d="M74 32 L76 6 L56 20Z" fill="${body}" stroke="${dark}" stroke-width="1"/><path d="M28 26 L27 12 L38 20Z" fill="#fde68a"/><path d="M72 26 L73 12 L62 20Z" fill="#fde68a"/><path d="M24 6 L27 12 L30 9Z M76 6 L73 12 L70 9Z" fill="#292524"/>`;
        face = `<ellipse cx="50" cy="54" rx="12" ry="8" fill="#fff7ed"/><ellipse cx="50" cy="50" rx="3" ry="2.2" fill="#292524"/>`; break;
      case 'axolotl':
        ears = [-1, 1].map(s => [0, 1, 2].map(i => `<rect x="${s < 0 ? 12 : 76}" y="${26 + i * 9}" width="12" height="6" rx="3" fill="#ec4899" transform="rotate(${s * (-22 + i * 18)} ${s < 0 ? 26 : 74} ${30 + i * 9})"/>`).join('')).join('');
        face = `<path d="M40 54 Q50 62 60 54" stroke="#9d174d" stroke-width="2" fill="none" stroke-linecap="round"/>`; break;
      case 'dragon':
        back = `<path d="M30 66 L6 50 L14 70 L2 72 L24 80Z" fill="#8b5cf6" stroke="#5b21b6" stroke-width="1"/><path d="M70 66 L94 50 L86 70 L98 72 L76 80Z" fill="#8b5cf6" stroke="#5b21b6" stroke-width="1"/><path d="M70 88 Q90 94 92 80 L98 84 L94 74 L86 78 Q86 86 70 84Z" fill="${body}" stroke="${dark}" stroke-width="1"/>`;
        ears = `<path d="M34 20 L30 4 L42 16Z M66 20 L70 4 L58 16Z" fill="#fef3c7" stroke="#a16207" stroke-width=".8"/><path d="M44 14 L50 6 L56 14Z" fill="#8b5cf6"/>`;
        face = `<ellipse cx="44" cy="54" rx="1.5" ry="1" fill="${dark}"/><ellipse cx="56" cy="54" rx="1.5" ry="1" fill="${dark}"/><path d="M44 58 Q50 62 56 58" stroke="${dark}" stroke-width="1.6" fill="none"/>`;
        extra = `<path d="M40 70 H60 M40 76 H60 M41 82 H59" stroke="${shade(belly, -.15)}" stroke-width="1.2"/>`; break;
      case 'penguin':
        face = `<ellipse cx="50" cy="48" rx="21" ry="17" fill="#f8fafc"/><path d="M45 52 L55 52 L50 58Z" fill="#f97316"/>`;
        front = `<ellipse cx="38" cy="93" rx="8" ry="4" fill="#f97316"/><ellipse cx="62" cy="93" rx="8" ry="4" fill="#f97316"/>`; break;
      case 'frog':
        ears = `<circle cx="34" cy="22" r="11" fill="${body}" stroke="${dark}" stroke-width="1"/><circle cx="66" cy="22" r="11" fill="${body}" stroke="${dark}" stroke-width="1"/>`;
        face = `<path d="M34 52 Q50 64 66 52" stroke="${dark}" stroke-width="2.2" fill="none" stroke-linecap="round"/>`; break;
      case 'ghost':
        return `<svg viewBox="0 0 100 100"><g><animateTransform attributeName="transform" type="translate" values="0 0;0 -4;0 0" dur="2.6s" repeatCount="indefinite"/>
          <path d="M22 44 C22 14 78 14 78 44 V90 L70 84 L62 92 L54 84 L46 92 L38 84 L30 92 L22 86Z" fill="#f1f5f9" stroke="#cbd5e1" stroke-width="1.5"/>
          <path d="M28 44 C30 22 70 22 72 44" stroke="rgba(0,0,0,.12)" stroke-width="1" stroke-dasharray="2 2" fill="none"/>
          ${eye(40)}${eye(60)}<ellipse cx="32" cy="54" rx="5" ry="3" fill="#93c5fd" opacity=".7"/><ellipse cx="68" cy="54" rx="5" ry="3" fill="#93c5fd" opacity=".7"/>
          <ellipse cx="50" cy="58" rx="4" ry="5" fill="#334155"/><path d="M14 60 Q8 52 16 48 M86 60 Q92 52 84 48" stroke="#cbd5e1" stroke-width="5" stroke-linecap="round" fill="none"/></g></svg>`;
      case 'bear':
        ears = `<circle cx="28" cy="22" r="10" fill="${body}" stroke="${dark}" stroke-width="1"/><circle cx="72" cy="22" r="10" fill="${body}" stroke="${dark}" stroke-width="1"/><circle cx="28" cy="22" r="5" fill="${belly}"/><circle cx="72" cy="22" r="5" fill="${belly}"/>`;
        face = `<ellipse cx="50" cy="54" rx="11" ry="8" fill="${belly}"/><ellipse cx="50" cy="51" rx="3.5" ry="2.5" fill="#292524"/>`; break;
      case 'bunny':
        ears = `<ellipse cx="38" cy="10" rx="7" ry="20" fill="${body}" stroke="${dark}" stroke-width="1" transform="rotate(-10 38 24)"/><ellipse cx="62" cy="10" rx="7" ry="20" fill="${body}" stroke="${dark}" stroke-width="1" transform="rotate(10 62 24)"/><ellipse cx="38" cy="12" rx="3.5" ry="14" fill="#fbcfe8" transform="rotate(-10 38 24)"/><ellipse cx="62" cy="12" rx="3.5" ry="14" fill="#fbcfe8" transform="rotate(10 62 24)"/>`;
        face = `<path d="M47 51 L53 51 L50 54Z" fill="#f472b6"/>`;
        front = `<g transform="rotate(-30 66 74)"><path d="M62 66 L70 66 L66 88Z" fill="#f97316"/><path d="M64 66 L62 60 M66 66 L66 59 M68 66 L70 60" stroke="#22c55e" stroke-width="2" stroke-linecap="round"/></g>`; break;
      case 'panda':
        ears = `<circle cx="28" cy="22" r="10" fill="#1f2937"/><circle cx="72" cy="22" r="10" fill="#1f2937"/>`;
        face = `<ellipse cx="38" cy="45" rx="8" ry="10" fill="#1f2937" transform="rotate(25 38 45)"/><ellipse cx="62" cy="45" rx="8" ry="10" fill="#1f2937" transform="rotate(-25 62 45)"/><ellipse cx="50" cy="53" rx="3.5" ry="2.5" fill="#1f2937"/>`; break;
      case 'bee':
        back = `<ellipse cx="30" cy="62" rx="14" ry="9" fill="#e0f2fe" opacity=".85" transform="rotate(-30 30 62)"><animateTransform attributeName="transform" type="rotate" values="-30 38 66;-50 38 66;-30 38 66" dur=".25s" repeatCount="indefinite"/></ellipse><ellipse cx="70" cy="62" rx="14" ry="9" fill="#e0f2fe" opacity=".85" transform="rotate(30 70 62)"><animateTransform attributeName="transform" type="rotate" values="30 62 66;50 62 66;30 62 66" dur=".25s" repeatCount="indefinite"/></ellipse>`;
        ears = `<path d="M42 18 Q38 6 32 4 M58 18 Q62 6 68 4" stroke="#1f2937" stroke-width="2" fill="none"/><circle cx="32" cy="4" r="3" fill="#1f2937"/><circle cx="68" cy="4" r="3" fill="#1f2937"/>`;
        extra = `<path d="M30 70 H70 M28 80 H72" stroke="#1f2937" stroke-width="5"/>`; break;
      case 'shark':
        ears = `<path d="M44 18 L58 0 L62 20Z" fill="${body}" stroke="${dark}" stroke-width="1"/>`;
        back = `<path d="M26 70 L8 78 L26 82Z M74 70 L92 78 L74 82Z" fill="${body}" stroke="${dark}" stroke-width="1"/>`;
        face = `<path d="M38 54 Q50 62 62 54 Z" fill="#fff" stroke="${dark}" stroke-width="1.2"/><path d="M42 55 L44 58 L46 56 L48 59 L50 56 L52 59 L54 56 L56 58 L58 55" stroke="${dark}" stroke-width=".6" fill="none"/><path d="M26 42 Q28 46 26 50 M74 42 Q72 46 74 50" stroke="${dark}" stroke-width="1.2" fill="none"/>`; break;
      case 'sigi':
        ears = `<path d="M50 16 Q48 6 52 0" stroke="${dark}" stroke-width="2" fill="none"/><circle cx="52" cy="0" r="4.5" fill="#fde047"><animate attributeName="r" values="4;5.5;4" dur="1.4s" repeatCount="indefinite"/></circle>`;
        extra = `<text x="50" y="86" text-anchor="middle" font-size="18" font-weight="900" font-family="Segoe UI,Arial" fill="#fff">Σ</text>`;
        face = `<path d="M45 53 Q50 58 55 53" stroke="#1e1035" stroke-width="2" fill="none" stroke-linecap="round"/>`; break;
    }
    if (!face.includes('Q50 6') && !['penguin', 'fox', 'bear', 'panda', 'dragon', 'shark', 'frog', 'sigi', 'axolotl'].includes(p.type)) face += `<path d="M45 54 Q47.5 57 50 54 Q52.5 57 55 54" stroke="#1f2937" stroke-width="1.4" fill="none" stroke-linecap="round"/>`;
    if (['penguin', 'fox', 'bear', 'panda'].includes(p.type)) face += `<path d="M46 58 Q50 61 54 58" stroke="#1f2937" stroke-width="1.4" fill="none" stroke-linecap="round"/>`;
    const eyesY = p.type === 'frog' ? 0 : 1;
    const eyes = p.type === 'frog'
      ? `<g transform="translate(-6 -22)">${eye(40)}</g><g transform="translate(6 -22)">${eye(60)}</g>`
      : eye(39) + eye(61);
    return `<svg viewBox="0 0 100 100"><defs><radialGradient id="${g}" cx=".35" cy=".3" r=".8"><stop offset="0" stop-color="${shade(body, .25)}"/><stop offset="1" stop-color="${body}"/></radialGradient></defs>
      <g><animateTransform attributeName="transform" type="translate" values="0 0;0 0;0 -9;0 0;0 -4;0 0;0 0" keyTimes="0;.55;.62;.7;.75;.8;1" dur="3.6s" repeatCount="indefinite"/>
      <g><animateTransform attributeName="transform" type="rotate" values="-3 50 92;3 50 92;-3 50 92" dur="3.2s" repeatCount="indefinite"/>
      ${back}
      <ellipse cx="50" cy="75" rx="25" ry="20" fill="url(#${g})" stroke="${dark}" stroke-width="1.2"/>
      <ellipse cx="50" cy="78" rx="14" ry="12" fill="${belly}"/>${extra}
      <ellipse cx="27" cy="74" rx="6.5" ry="9.5" fill="${p.type === 'panda' ? '#1f2937' : body}" stroke="${dark}" stroke-width="1" transform="rotate(20 27 74)"/>
      <ellipse cx="73" cy="74" rx="6.5" ry="9.5" fill="${p.type === 'panda' ? '#1f2937' : body}" stroke="${dark}" stroke-width="1" transform="rotate(-20 73 74)"/>
      ${p.type !== 'penguin' ? `<ellipse cx="39" cy="93" rx="8" ry="4.5" fill="${p.type === 'panda' ? '#1f2937' : dark}"/><ellipse cx="61" cy="93" rx="8" ry="4.5" fill="${p.type === 'panda' ? '#1f2937' : dark}"/>` : ''}
      ${ears}
      <circle cx="50" cy="42" r="28" fill="url(#${g})" stroke="${dark}" stroke-width="1.2"/>
      <path d="M26 36 C30 18 70 18 74 36" stroke="rgba(0,0,0,.14)" stroke-width="1" stroke-dasharray="2.2 2" fill="none"/>
      ${face}${eyesY ? eyes : ''}${p.type === 'frog' ? eyes : ''}
      <ellipse cx="33" cy="53" rx="5" ry="3" fill="#f472b6" opacity=".45"/><ellipse cx="67" cy="53" rx="5" ry="3" fill="#f472b6" opacity=".45"/>
      ${front}</g></g>
      <path d="M82 30 C78 26 72 28 74 33 C75 36 82 40 82 40 C82 40 89 36 90 33 C92 28 86 26 82 30Z" fill="#f472b6" opacity="0">
        <animate attributeName="opacity" values="0;0;1;1;0" keyTimes="0;.6;.66;.85;1" dur="3.6s" repeatCount="indefinite"/>
        <animateTransform attributeName="transform" type="translate" values="0 6;0 6;0 0;0 -10;0 -14" keyTimes="0;.6;.66;.85;1" dur="3.6s" repeatCount="indefinite"/></path></svg>`;
  }

  // ================= 3D-Stirnband (Kopf-Koordinaten wie Minecraft: Kopf x/z ±4, y -8..0, vorne = -z) =================
  const GLYPHS = {
    'Σ': ['111', '100', '010', '100', '111'],
    '★': ['00100', '11111', '01110', '01010', '10001'],
    '♥': ['01010', '11111', '11111', '01110', '00100']
  };
  function mix(a, b, t) {
    const pa = parseInt(a.slice(1), 16), pb = parseInt(b.slice(1), 16);
    const ch = (sh) => Math.round(((pa >> sh) & 255) * (1 - t) + ((pb >> sh) & 255) * t).toString(16).padStart(2, '0');
    return '#' + ch(16) + ch(8) + ch(0);
  }
  function bandBoxes(it) {
    it = resolve('head', it);
    const c1 = it.color || '#dc2626', c2 = it.color2 || shade(c1, -.35), pat = it.pattern || 'plain', list = [];
    const add = (x, y, z, w, h, d, c, p = 'band') => list.push({ x, y, z, w, h, d, c, p });
    const y0 = -6.2, H = 1.6, T = .5, R = 4;
    const segs = [];
    for (let i = 0; i < 9; i++) segs.push([-4.5 + i, -R - T, 1, T]);
    for (let i = 0; i < 8; i++) segs.push([R, -4 + i, T, 1]);
    for (let i = 0; i < 9; i++) segs.push([4.5 - (i + 1), R, 1, T]);
    for (let i = 0; i < 8; i++) segs.push([-R - T, 4 - (i + 1), T, 1]);
    segs.forEach(([x, z, w, d], i) => {
      if (pat === 'checker') { add(x, y0, z, w, H / 2, d, i % 2 ? c1 : c2); add(x, y0 + H / 2, z, w, H / 2, d, i % 2 ? c2 : c1); return; }
      if (pat === 'tri') { const c3 = it.color3 || '#ffce00'; add(x, y0, z, w, H / 3, d, c1); add(x, y0 + H / 3, z, w, H / 3, d, c2); add(x, y0 + 2 * H / 3, z, w, H / 3, d, c3); return; }
      if (pat === 'zigzag') { const up = i % 2 === 0; add(x, y0, z, w, H / 2, d, up ? c1 : c2); add(x, y0 + H / 2, z, w, H / 2, d, up ? c2 : c1); return; }
      const col = pat === 'stripes' ? (i % 2 ? c2 : c1) : pat === 'rainbow' ? hslHex(i / segs.length * 360, .8, .55) : pat === 'gradient' ? mix(c1, c2, Math.abs(((i / segs.length) * 2) % 2 - 1)) : c1;
      add(x, y0, z, w, H, d, col);
    });
    if (pat === 'dots') segs.forEach(([x, z, w, d], i) => { if (i % 3 === 1) add(x + w / 2 - .3, y0 + .5, z + d / 2 - .3, .6, .6, .6, c2); });
    if (it.gem) add(-.5, y0 + .3, -R - T - .35, 1, 1, .4, it.gem);
    const g = GLYPHS[it.emblem || it.text || ''];
    if (g) {
      const ps = .3, gw = g[0].length * ps, ec = it.emblemColor || (/^#(f|e|d)/i.test(c1) ? '#111111' : '#ffffff');
      g.forEach((row, r) => [...row].forEach((ch, c) => { if (ch === '1') add(-gw / 2 + c * ps, y0 + .05 + r * ps, -R - T - .12, ps, ps, .12, ec); }));
    }
    add(.5, y0 - .2, R + T, 1.6, 2, .8, c2);
    add(.7, y0 + 1.5, R + T + .3, .8, 4, .25, c1, 'tail');
    add(1.6, y0 + 1.2, R + T + .3, .8, 3.4, .25, c2, 'tail');
    return list;
  }

  // ================= v3: Auren (krass), Sprites, Ringe =================
  const svgURL = (svg) => 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg.includes('xmlns') ? svg : svg.replace('<svg ', '<svg xmlns="http://www.w3.org/2000/svg" '));
  function spriteSVG(name, c1, c2) {
    const g = nid('sg');
    const S = {
      flame: `<path d="M10 2C15 8 15 12.5 13 15.5C11.8 17.4 8.2 17.4 7 15.5C5 12.5 5 8 10 2Z" fill="${c1}"/><path d="M10 8C12.2 11 12.2 13 11.2 14.6C10.6 15.4 9.4 15.4 8.8 14.6C7.8 13 7.8 11 10 8Z" fill="${c2}"/>`,
      snow: `<path d="M10 3V17M3 10H17M5 5L15 15M15 5L5 15" stroke="${c1}" stroke-width="1.6" stroke-linecap="round"/><circle cx="10" cy="10" r="1.6" fill="${c2}"/>`,
      heart: `<path d="M10 16.5C5.5 13.3 3 11 3 8C3 5.8 4.7 4.2 6.7 4.2C8 4.2 9.3 4.9 10 6C10.7 4.9 12 4.2 13.3 4.2C15.3 4.2 17 5.8 17 8C17 11 14.5 13.3 10 16.5Z" fill="${c1}"/><ellipse cx="7" cy="7.4" rx="1.6" ry="1" fill="${c2}" opacity=".8"/>`,
      star: `<path d="M10 2Q11.4 8.6 18 10Q11.4 11.4 10 18Q8.6 11.4 2 10Q8.6 8.6 10 2Z" fill="${c1}"/><circle cx="10" cy="10" r="1.8" fill="${c2}"/>`,
      petal: `<g transform="rotate(-25 10 10)"><ellipse cx="10" cy="10" rx="7" ry="3.8" fill="${c1}"/><ellipse cx="9" cy="9.4" rx="3.4" ry="1.5" fill="${c2}"/></g>`,
      bolt: `<path d="M12 2L5 11H9.5L7.5 18L15 8.5H10.5Z" fill="${c1}" stroke="${c2}" stroke-width=".7"/>`,
      orb: `<circle cx="10" cy="10" r="5.5" fill="${c1}" opacity=".75"/><circle cx="10" cy="10" r="3" fill="${c2}"/>`,
      rune: `<path d="M10 3V17M10 7L14 4M10 7L6 4M10 12L14 15M10 12L6 15" stroke="${c1}" stroke-width="1.8" stroke-linecap="round" fill="none"/><circle cx="10" cy="10" r="1.3" fill="${c2}"/>`,
      note: `<path d="M8 15.5V4.5L15 3V13" stroke="${c1}" stroke-width="1.8" fill="none"/><ellipse cx="6.4" cy="15.4" rx="2.4" ry="1.8" fill="${c1}"/><ellipse cx="13.4" cy="13" rx="2.4" ry="1.8" fill="${c2}"/>`,
      diamond: `<path d="M10 2L16 8L10 18L4 8Z" fill="${c1}"/><path d="M10 2L13 8L10 18L7 8Z" fill="${c2}" opacity=".7"/><path d="M4 8H16" stroke="#fff" stroke-width=".6" opacity=".7"/>`,
      cross: `<path d="M10 1L11.3 8.7L19 10L11.3 11.3L10 19L8.7 11.3L1 10L8.7 8.7Z" fill="${c1}"/><circle cx="10" cy="10" r="1.5" fill="#fff"/>`,
      bubble: `<circle cx="10" cy="10" r="6" fill="${c1}" fill-opacity=".25" stroke="${c1}" stroke-width="1.2"/><circle cx="7.8" cy="7.6" r="1.6" fill="${c2}"/>`,
      leaf: `<path d="M4 16C4 8 9 4 17 3C16 11 12 16 4 16Z" fill="${c1}"/><path d="M4 16L13 7" stroke="${c2}" stroke-width="1"/>`,
      feather: `<path d="M15 3C9 4 5 9 5 16L7 15C8 10 11 6 15 3Z" fill="${c1}"/><path d="M5 16L14 4" stroke="${c2}" stroke-width=".8"/>`,
      pixel: `<rect x="6" y="6" width="8" height="8" fill="${c1}"/><rect x="6" y="6" width="4" height="4" fill="${c2}"/>`,
      moon: `<path d="M13 3A7 7 0 1 0 17 13A5.5 5.5 0 1 1 13 3Z" fill="${c1}"/><circle cx="8" cy="12" r="1" fill="${c2}"/>`,
      skull: `<rect x="5" y="4" width="10" height="9" rx="3" fill="${c1}"/><rect x="7" y="12" width="6" height="4" rx="1" fill="${c1}"/><circle cx="8" cy="9" r="1.6" fill="${c2}"/><circle cx="12" cy="9" r="1.6" fill="${c2}"/>`,
      chain: `<rect x="3" y="7" width="8" height="6" rx="3" fill="none" stroke="${c1}" stroke-width="1.6"/><rect x="9" y="7" width="8" height="6" rx="3" fill="none" stroke="${c2}" stroke-width="1.6"/>`
    };
    return `<svg viewBox="0 0 20 20"><defs><radialGradient id="${g}"><stop offset="0" stop-color="${c1}" stop-opacity=".6"/><stop offset="1" stop-color="${c1}" stop-opacity="0"/></radialGradient></defs><circle cx="10" cy="10" r="10" fill="url(#${g})"/>${S[name] || S.star}</svg>`;
  }
  // Boden-Ring (von oben gesehen), Leuchten ist schon eingebaut
  function auraRingSVG(style, c1, c2) {
    const f = nid('rf');
    let s = `<circle cx="100" cy="100" r="86" fill="none" stroke="${c1}" stroke-width="4"/><circle cx="100" cy="100" r="70" fill="none" stroke="${c2}" stroke-width="1.6" opacity=".8"/>`;
    const pt = (r, a) => [100 + r * Math.cos(a), 100 + r * Math.sin(a)];
    switch (style) {
      case 'runes': for (let i = 0; i < 16; i++) s += `<g transform="rotate(${i * 22.5} 100 100)"><path d="M100 18 V30 M100 22 L105 18 M100 22 L95 18 M100 27 L105 31" stroke="${c2}" stroke-width="2" fill="none" stroke-linecap="round"/></g>`;
        s += `<circle cx="100" cy="100" r="40" fill="none" stroke="${c1}" stroke-width="1.4" stroke-dasharray="4 6"/>`; break;
      case 'hex': {
        const tri = (o) => [0, 1, 2].map(i => pt(68, o + i * 2.0944).map(v => v.toFixed(1)).join(',')).join(' ');
        s += `<polygon points="${tri(-1.5708)}" fill="none" stroke="${c1}" stroke-width="2.4"/><polygon points="${tri(1.5708)}" fill="none" stroke="${c1}" stroke-width="2.4"/>`;
        for (let i = 0; i < 6; i++) { const [x, y] = pt(68, -1.5708 + i * 1.0472); s += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="5" fill="${c2}"/>`; }
        s += `<circle cx="100" cy="100" r="30" fill="none" stroke="${c2}" stroke-width="1.6"/>`; break;
      }
      case 'portal': for (let i = 0; i < 6; i++) s += `<path d="M100 100 Q${pt(60, i * 1.0472 + .6).map(v => v.toFixed(1)).join(' ')} ${pt(86, i * 1.0472 + 1.2).map(v => v.toFixed(1)).join(' ')}" stroke="${i % 2 ? c1 : c2}" stroke-width="3" fill="none" stroke-linecap="round"/>`;
        s += `<circle cx="100" cy="100" r="16" fill="${c1}" opacity=".5"/>`; break;
      case 'spikes': for (let i = 0; i < 16; i++) { const a = i * .3927, [x1, y1] = pt(86, a - .1), [x2, y2] = pt(98, a), [x3, y3] = pt(86, a + .1); s += `<polygon points="${x1.toFixed(1)},${y1.toFixed(1)} ${x2.toFixed(1)},${y2.toFixed(1)} ${x3.toFixed(1)},${y3.toFixed(1)}" fill="${c1}"/>`; }
        s += `<circle cx="100" cy="100" r="50" fill="none" stroke="${c2}" stroke-width="1.4" stroke-dasharray="2 5"/>`; break;
      case 'flame': {
        let d = '';
        for (let i = 0; i <= 48; i++) { const a = i / 48 * 6.2832, r = 84 + (i % 2 ? 12 : 0); const [x, y] = pt(r, a); d += (i ? ' L' : 'M') + x.toFixed(1) + ' ' + y.toFixed(1); }
        s += `<path d="${d}Z" fill="${c1}" opacity=".55"/>`; break;
      }
      case 'stars': for (let i = 0; i < 12; i++) { const [x, y] = pt(86, i * .5236); s += `<path transform="translate(${x.toFixed(1)} ${y.toFixed(1)})" d="M0 -8Q1.5 -1.5 8 0Q1.5 1.5 0 8Q-1.5 1.5 -8 0Q-1.5 -1.5 0 -8Z" fill="${c2}"/>`; } break;
      case 'hearts': for (let i = 0; i < 10; i++) { const [x, y] = pt(86, i * .6283); s += `<path transform="translate(${(x - 6).toFixed(1)} ${(y - 6).toFixed(1)}) scale(.6)" d="M10 16.5C5.5 13.3 3 11 3 8C3 5.8 4.7 4.2 6.7 4.2C8 4.2 9.3 4.9 10 6C10.7 4.9 12 4.2 13.3 4.2C15.3 4.2 17 5.8 17 8C17 11 14.5 13.3 10 16.5Z" fill="${c2}"/>`; } break;
      case 'tech': for (let i = 0; i < 8; i++) s += `<path d="M${pt(78, i * .785).map(v => v.toFixed(1)).join(' ')} A78 78 0 0 1 ${pt(78, i * .785 + .5).map(v => v.toFixed(1)).join(' ')}" stroke="${c2}" stroke-width="6" fill="none"/>`;
        s += `<circle cx="100" cy="100" r="56" fill="none" stroke="${c1}" stroke-width="1" stroke-dasharray="1 4"/>`; break;
      case 'thorns': { let d = ''; for (let i = 0; i <= 40; i++) { const [x, y] = pt(i % 2 ? 78 : 92, i / 40 * 6.2832); d += (i ? ' L' : 'M') + x.toFixed(1) + ' ' + y.toFixed(1); } s += `<path d="${d}" stroke="${c2}" stroke-width="2" fill="none"/>`; break; }
      case 'waves': for (let k = 0; k < 3; k++) s += `<circle cx="100" cy="100" r="${30 + k * 18}" fill="none" stroke="${k % 2 ? c1 : c2}" stroke-width="2" stroke-dasharray="10 6" opacity="${.9 - k * .2}"/>`; break;
    }
    return `<svg viewBox="0 0 200 200"><defs><filter id="${f}" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><g filter="url(#${f})">${s}</g></svg>`;
  }
  // weicher Lichtpunkt (für Säule und Orbs)
  function glowSVG(c1) {
    const g = nid('gl');
    return `<svg viewBox="0 0 64 64"><defs><radialGradient id="${g}"><stop offset="0" stop-color="#ffffff" stop-opacity=".95"/><stop offset=".25" stop-color="${c1}" stop-opacity=".85"/><stop offset="1" stop-color="${c1}" stop-opacity="0"/></radialGradient></defs><circle cx="32" cy="32" r="32" fill="url(#${g})"/></svg>`;
  }
  function auraTileSVG(it) {
    const sp = svgURL(spriteSVG(it.sprite, it.c1, it.c2)), ring = it.ring ? svgURL(auraRingSVG(it.ring, it.c1, it.c2)) : '';
    let s = `<svg viewBox="0 0 100 100" xmlns:xlink="http://www.w3.org/1999/xlink">`;
    if (it.pillar) s += `<rect x="38" y="0" width="24" height="86" fill="${it.c1}" opacity=".18"/><rect x="45" y="0" width="10" height="86" fill="${it.c2}" opacity=".22"/>`;
    if (ring) s += `<image href="${ring}" x="8" y="66" width="84" height="30" preserveAspectRatio="none"/>`;
    const rr = mulberry(it.id.length * 7 + 3);
    for (let i = 0; i < 9; i++) s += `<image href="${sp}" x="${(10 + rr() * 70).toFixed(1)}" y="${(6 + rr() * 64).toFixed(1)}" width="${(9 + rr() * 9).toFixed(1)}" height="${(9 + rr() * 9).toFixed(1)}" opacity="${(.6 + rr() * .4).toFixed(2)}"/>`;
    return s + '</svg>';
  }
  function mulberry(a) { return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  // Aura in der 3D-Vorschau: hinten Ring/Säule, vorne Partikel und Orbs
  function auraLayers(it) {
    const back = document.createElement('div'), front = document.createElement('div');
    back.className = 'ax ax-back'; front.className = 'ax ax-front';
    const ring = it.ring ? svgURL(auraRingSVG(it.ring, it.c1, it.c2)) : null;
    let b = '';
    if (it.pillar) b += `<div class="ax-pillar" style="--c:${it.c1};--c2:${it.c2}"></div>`;
    if (ring) b += `<div class="ax-ring"><img src="${ring}" alt=""></div>`;
    if (ring && it.ring2) b += `<div class="ax-ring ax-ring2"><img src="${ring}" alt=""></div>`;
    back.innerHTML = b;
    const sp = svgURL(spriteSVG(it.sprite, it.c1, it.c2)), rr = mulberry(it.id.length * 13 + 5);
    let f = '';
    const n = Math.min(18, it.count || 14), mode = it.motion || 'rise';
    for (let i = 0; i < n; i++) {
      const t = (2.4 + rr() * 2.2) / (it.speed || 1);
      f += `<img class="ax-pt ${mode}" src="${sp}" alt="" style="--x:${(14 + rr() * 72).toFixed(1)}%;--y:${(mode === 'fall' ? rr() * 30 : 60 + rr() * 35).toFixed(1)}%;--s:${(6.5 + rr() * 6).toFixed(1)}cqw;--t:${t.toFixed(2)}s;--d:-${(rr() * t).toFixed(2)}s;--r:${(rr() * 360 - 180).toFixed(0)}deg;--i:${i}">`;
    }
    if (it.orbs) {
      const g = svgURL(glowSVG(it.c1));
      f += `<div class="ax-orbit">${Array.from({ length: it.orbs }, (_, i) => `<img class="ax-orb" src="${g}" alt="" style="--d:-${(i * 6 / it.orbs).toFixed(2)}s">`).join('')}</div>`;
    }
    front.innerHTML = f;
    return [back, front];
  }

  // ================= v3: Voxel-Halos, Ketten-Halo, Foto-Stirnband =================
  // Teile: spin (dreht sich), orbit (schräg, dreht andersrum), *Glow = leuchtet
  function ringPts(R, n, y, w, h, c, p, list, gap) {
    for (let i = 0; i < n; i++) {
      if (gap && gap(i)) continue;
      const a = i / n * Math.PI * 2, x = Math.cos(a) * R, z = Math.sin(a) * R;
      list.push({ x: x - w / 2, y, z: z - w / 2, w, h, d: w, c: typeof c === 'function' ? c(i) : c, p });
    }
  }
  function haloBoxes(it) {
    const list = [], c1 = it.c1 || '#fbbf24', c2 = it.c2 || '#fff7d6', R = it.r || 4.4, Y = it.y ?? -11.2, st = it.style || 'classic';
    const G = 'spinGlow';
    switch (st) {
      case 'classic':
        ringPts(R, 30, Y, 1, .7, c1, G, list); ringPts(R - .7, 26, Y + .15, .5, .4, c2, G, list); break;
      case 'spiked':
        ringPts(R, 30, Y, 1, .7, c1, G, list);
        for (let i = 0; i < 10; i++) { const a = i / 10 * Math.PI * 2, x = Math.cos(a) * R, z = Math.sin(a) * R; list.push({ x: x - .3, y: Y - 1.6, z: z - .3, w: .6, h: 1.6, d: .6, c: c2, p: G }); list.push({ x: x - .15, y: Y - 2.4, z: z - .15, w: .3, h: .8, d: .3, c: c2, p: G }); }
        break;
      case 'double':
        ringPts(R, 30, Y, .9, .6, c1, G, list);
        ringPts(R + 1.1, 34, Y, .6, .5, c2, 'orbitGlow', list); break;
      case 'broken':
        ringPts(R, 30, Y, 1, .7, c1, G, list, i => i % 6 === 0 || i % 6 === 1);
        for (let i = 0; i < 6; i++) { const a = (i / 6 + .04) * Math.PI * 2; list.push({ x: Math.cos(a) * (R + 1.4) - .3, y: Y - .6 + (i % 2) * 1.2, z: Math.sin(a) * (R + 1.4) - .3, w: .6, h: .6, d: .6, c: c2, p: 'orbitGlow' }); }
        break;
      case 'thorn':
        ringPts(R, 30, Y, .9, .7, c1, 'spin', list);
        for (let i = 0; i < 15; i++) { const a = i / 15 * Math.PI * 2; list.push({ x: Math.cos(a) * (R + .8) - .2, y: Y - (i % 2 ? .9 : .2), z: Math.sin(a) * (R + .8) - .2, w: .4, h: .5, d: .4, c: c2, p: 'spinGlow' }); }
        break;
      case 'saturn':
        for (let i = 0; i < 3; i++) list.push({ x: -1 + i * .2, y: Y - 1.6 + i * .2, z: -1 + i * .2, w: 2 - i * .4, h: 2 - i * .4, d: 2 - i * .4, c: i ? c2 : c1, p: G });
        ringPts(R, 32, Y - .7, .8, .35, c1, 'orbitGlow', list); ringPts(R + .9, 36, Y - .7, .5, .3, c2, 'orbitGlow', list); break;
      case 'crownhalo':
        ringPts(R, 30, Y, 1, .7, c1, G, list);
        for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2, x = Math.cos(a) * R, z = Math.sin(a) * R; list.push({ x: x - .45, y: Y - 1.2, z: z - .45, w: .9, h: 1.2, d: .9, c: c1, p: G }); list.push({ x: x - .3, y: Y - 1.6, z: z - .3, w: .6, h: .5, d: .6, c: c2, p: G }); }
        break;
      case 'chain': {
        // Schwarz-Weiß-Halo mit kreisenden Ketten (anpassbar)
        const ring = it.c1 || '#0a0a0a', edge = it.c2 || '#ffffff', ch = it.chainColor || '#d4d4d8';
        ringPts(R, 30, Y, 1.1, .8, ring, 'spin', list);
        ringPts(R - .75, 28, Y + .25, .35, .35, edge, G, list);
        ringPts(R + .75, 32, Y + .25, .3, .3, edge, G, list);
        if (it.spikes !== false) for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; list.push({ x: Math.cos(a) * R - .2, y: Y - 1.4, z: Math.sin(a) * R - .2, w: .4, h: 1.4, d: .4, c: edge, p: G }); }
        const chains = it.chains ?? 2;
        const chain = (Rc, yc, tilt, part) => {
          const n = Math.round(Rc * 6.4);
          for (let i = 0; i < n; i++) {
            const a = i / n * Math.PI * 2, x = Math.cos(a) * Rc, z0 = Math.sin(a) * Rc;
            const y = yc + z0 * Math.sin(tilt), z = z0 * Math.cos(tilt), flat = i % 2 === 0;
            // Kettenglied: abwechselnd liegend und stehend
            list.push({ x: x - .5, y: y - (flat ? .16 : .42), z: z - .5, w: 1, h: flat ? .32 : .84, d: 1, c: i % 6 === 0 ? edge : ch, p: part });
          }
        };
        if (chains >= 1) chain(6.2, -4, 0, 'orbit');
        if (chains >= 2) chain(5.6, -6, .45, 'spin');
        if (chains >= 3) chain(6.6, -2.5, -.4, 'spin');
        if (it.sparks !== false) for (let i = 0; i < 10; i++) { const a = i / 10 * Math.PI * 2; list.push({ x: Math.cos(a) * 7.2 - .15, y: -4 - 1 + (i % 3), z: Math.sin(a) * 7.2 - .15, w: .3, h: .3, d: .3, c: edge, p: 'orbitGlow' }); }
        break;
      }
    }
    return list;
  }
  // Foto-Stirnband: das Bild als Pixel vorne auf dem Band (36 x 8 Pixel)
  const PB_W = 36, PB_H = 8;
  function photoBandBoxes(it) {
    const list = [], c = it.color || '#111111', y0 = -6.6, H = 2.4, R = 4, T = .5;
    const add = (x, y, z, w, h, d, col, p = 'band') => list.push({ x, y, z, w, h, d, c: col, p });
    add(-4.5, y0, -R - T, 9, H, T, c); add(R, y0, -4, T, H, 8, c); add(-4.5, y0, R, 9, H, T, c); add(-R - T, y0, -4, T, H, 8, c);
    let px = it.px;
    if (!Array.isArray(px)) { px = []; for (let r = 0; r < PB_H; r++) for (let k = 0; k < PB_W; k++) px.push(hslHex(k / PB_W * 300 + r * 6, .8, .5 + (r % 2) * .06)); }
    if (Array.isArray(px) && px.length === PB_W * PB_H) {
      const pw = 9 / PB_W, ph = H / PB_H;
      for (let r = 0; r < PB_H; r++) for (let k = 0; k < PB_W; k++) {
        const col = px[r * PB_W + k];
        if (col) add(-4.5 + k * pw, y0 + r * ph, -R - T - .08, pw, ph, .08, col, it.glowPhoto ? 'glow' : 'band');
      }
    }
    if (it.wrapSides && Array.isArray(px)) {
      // Seiten: Ränder des Bildes weiterführen
      for (let r = 0; r < PB_H; r++) for (let k = 0; k < 8; k++) {
        const L = px[r * PB_W], Rr = px[r * PB_W + PB_W - 1];
        if (L) add(-R - T - .08, y0 + r * (H / PB_H), -4 + k, .08, H / PB_H, 1, L);
        if (Rr) add(R + T, y0 + r * (H / PB_H), -4 + k, .08, H / PB_H, 1, Rr);
      }
    }
    add(.5, y0 - .2, R + T, 1.6, 2.6, .8, shade(c, -.2));
    add(.7, y0 + 2, R + T + .3, .8, 4, .25, c, 'tail'); add(1.6, y0 + 1.7, R + T + .3, .8, 3.4, .25, shade(c, .2), 'tail');
    return list;
  }
  function headBoxesFor(it) {
    if (!it) return null;
    if (it.kind === 'band') return bandBoxes(it);
    if (it.kind === 'pband') return photoBandBoxes(it);
    if (it.kind === 'vhalo') return haloBoxes(it);
    return null;
  }

  // ================= v3: 3D-Schuhe (an den Beinen, gehen beim Laufen mit) =================
  // Koordinaten im Bein: x -2..2, y 0..12 (Fuß unten), vorne = -z
  function shoeBoxes(it) {
    const list = [], add = (x, y, z, w, h, d, c, p = 'shoe') => list.push({ x, y, z, w, h, d, c, p });
    const [c1, c2] = it.colors || ['#451a03', '#92400e'], sole = it.sole || shade(c1, -.5), cuff = it.cuff || shade(c2, .25);
    const G = it.glow || c2, st = it.style || 'boot';
    const low = st === 'sneaker' || st === 'skate' || st === 'ninja';
    const top = low ? 10.2 : 8.4;
    add(-2.25, top, -2.25, 4.5, 11.4 - top, 4.5, c1);
    add(-2.25, 10.2, -2.75, 4.5, 1.2, .5, c2);
    add(-2.3, 11.4, -2.8, 4.6, .75, 5.1, sole);
    if (!low) add(-2.35, top - .3, -2.35, 4.7, .6, 4.7, cuff);
    switch (st) {
      case 'sneaker': case 'skate':
        add(-.9, 9.7, -2.4, 1.8, 1.2, .3, c2); add(-1.2, 10.5, -2.35, 2.4, .2, .1, '#f8fafc'); add(-1.2, 10.9, -2.4, 2.4, .2, .1, '#f8fafc');
        add(-2.3, 10.6, -1.5, .08, .5, 3, it.stripe || c2); add(2.22, 10.6, -1.5, .08, .5, 3, it.stripe || c2);
        if (st === 'skate') for (const x of [-1.7, 1.1]) for (const z of [-2, 1.4]) add(x, 12.1, z, .6, .8, .8, '#111827');
        break;
      case 'rocket':
        add(-1.4, 9.5, 2.25, 2.8, 2.2, .9, '#475569'); add(-.9, 11.7, 2.5, 1.8, .6, .6, G, 'glow'); add(-.6, 12.3, 2.6, 1.2, .7, .4, '#fde047', 'glow');
        add(-2.6, 9, .8, .4, 1.8, 1.4, it.cuff || '#ef4444'); add(2.2, 9, .8, .4, 1.8, 1.4, it.cuff || '#ef4444'); break;
      case 'lava':
        add(-2.3, 9.5, -1, .08, .3, 2.5, G, 'glow'); add(2.22, 10.3, -2, .08, .3, 3, G, 'glow'); add(-1.5, 10.4, -2.8, 3, .25, .08, G, 'glow'); add(-2.3, 11.45, -2.85, 4.6, .15, 5.2, G, 'glow'); break;
      case 'ice':
        for (const [x, z, h] of [[-2.6, -1, 1.6], [-2.6, 1, 1.1], [2.2, -.5, 1.8], [2.2, 1.3, 1.2]]) add(x, top - h + 1, z, .4, h, .5, '#e0f2fe', 'glow');
        add(-2.3, 11.45, -2.85, 4.6, .15, 5.2, G, 'glow'); break;
      case 'gold':
        add(-.4, 10.3, -2.85, .8, .8, .1, '#ef4444'); add(-2.33, 9.6, -.4, .08, .8, .8, '#3b82f6'); add(2.25, 9.6, -.4, .08, .8, .8, '#3b82f6'); break;
      case 'cloud':
        for (const [x, y, z, s] of [[-2.8, 10.6, -2.4, 1.6], [1.4, 10.4, -2.6, 1.7], [-2.9, 10.8, 1, 1.5], [1.6, 10.8, 1.2, 1.5], [-.8, 11.2, -3.2, 1.6], [-.6, 11.5, 2, 1.4]]) add(x, y, z, s, s * .8, s, '#ffffff', 'glow'); break;
      case 'neon':
        add(-2.3, 9, -2.3, .08, 2.4, .3, G, 'glow'); add(2.22, 9, -2.3, .08, 2.4, .3, G, 'glow'); add(-2.3, 11.35, -2.85, 4.6, .12, 5.2, it.sole || '#ec4899', 'glow');
        add(-2.3, 10.6, -1.5, .08, .25, 3.5, G, 'glow'); add(2.22, 10.6, -1.5, .08, .25, 3.5, G, 'glow'); break;
      case 'bunny':
        add(-2.6, 9.2, -3, 5.2, 2.3, 5.4, c1);
        add(-1.6, 6.8, -2.6, .9, 2.6, .5, c1); add(.7, 6.8, -2.6, .9, 2.6, .5, c1); add(-1.4, 7.1, -2.65, .5, 2, .1, '#fbcfe8'); add(.9, 7.1, -2.65, .5, 2, .1, '#fbcfe8');
        add(-1.3, 9.8, -3.05, .5, .5, .1, '#111827'); add(.8, 9.8, -3.05, .5, .5, .1, '#111827'); add(-.3, 10.4, -3.05, .6, .35, .1, '#f472b6'); break;
      case 'frog':
        add(-2.6, 9.4, -3, 5.2, 2.1, 5.4, c1);
        add(-1.9, 8.4, -2.4, 1.3, 1.1, 1.3, c1); add(.6, 8.4, -2.4, 1.3, 1.1, 1.3, c1);
        add(-1.6, 8.6, -2.45, .7, .7, .1, '#ffffff'); add(.9, 8.6, -2.45, .7, .7, .1, '#ffffff'); add(-1.4, 8.8, -2.5, .35, .35, .06, '#111827'); add(1.1, 8.8, -2.5, .35, .35, .06, '#111827');
        add(-1.4, 10.7, -3.05, 2.8, .25, .1, '#14532d'); break;
      case 'heelwings':
        for (const s of [-1, 1]) for (let i = 0; i < 3; i++) add(s < 0 ? -2.7 - i * .1 : 2.25, 8.8 + i * .5, 1.4 + i * .5, .45 + i * .1, .5, 1.6 + i * .6, i % 2 ? '#e2e8f0' : '#ffffff');
        add(-2.3, 11.45, -2.85, 4.6, .15, 5.2, '#fde68a', 'glow'); break;
      case 'ninja':
        add(-.15, 10.2, -2.82, .3, 1.2, .1, shade(c1, -.4)); add(-2.25, 9.7, -2.25, 4.5, .5, 4.5, c2); break;
      case 'void':
        add(-2.3, 9.2, -2.3, .08, 2.2, 4.6, G, 'glow'); add(2.22, 9.2, -2.3, .08, 2.2, 4.6, G, 'glow');
        add(-1.6, 7, 2.3, .4, 1.2, .4, G, 'glow'); add(1.2, 7.3, 2.3, .4, .9, .4, G, 'glow'); break;
      case 'crystal':
        for (const [x, y, z] of [[-2.6, 9.2, -1.6], [2.2, 9.6, -1], [-2.6, 10, 1], [2.2, 9, 1.4], [-.5, 8, 2.3]]) add(x, y, z, .45, .9, .45, G, 'glow');
        break;
    }
    return list;
  }

  // ================= v3: Hochgeladene Bilder vorbereiten =================
  // Bild auf Größe bringen (Daten-URL) – klein halten, damit alles flüssig bleibt
  function loadImageFile(file, maxW, maxH) {
    return new Promise((res, rej) => {
      const r = new FileReader();
      r.onerror = () => rej(new Error('Bild konnte nicht gelesen werden'));
      r.onload = () => {
        const img = new Image();
        img.onerror = () => rej(new Error('Das ist kein Bild (PNG/JPG)'));
        img.onload = () => {
          const k = Math.min(1, maxW / img.width, maxH / img.height);
          const c = document.createElement('canvas');
          c.width = Math.max(1, Math.round(img.width * k)); c.height = Math.max(1, Math.round(img.height * k));
          c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
          res({ url: c.toDataURL('image/png'), canvas: c });
        };
        img.src = r.result;
      };
      r.readAsDataURL(file);
    });
  }
  // Foto in 36x8 Farbpixel umwandeln (Ausschnitt aus der Mitte, Zoom/Verschieben möglich)
  function photoPixels(canvas, zoom = 1, ox = 0, oy = 0) {
    const c = document.createElement('canvas');
    c.width = PB_W; c.height = PB_H;
    const x = c.getContext('2d');
    const aspect = PB_W / PB_H, sw0 = Math.min(canvas.width, canvas.height * aspect), sh0 = sw0 / aspect;
    const sw = sw0 / zoom, sh = sh0 / zoom;
    const sx = (canvas.width - sw) / 2 + ox * (canvas.width - sw) / 2, sy = (canvas.height - sh) / 2 + oy * (canvas.height - sh) / 2;
    x.imageSmoothingQuality = 'high';
    x.drawImage(canvas, sx, sy, sw, sh, 0, 0, PB_W, PB_H);
    const d = x.getImageData(0, 0, PB_W, PB_H).data, out = [];
    for (let i = 0; i < d.length; i += 4) out.push(d[i + 3] < 60 ? null : '#' + [d[i], d[i + 1], d[i + 2]].map(v => v.toString(16).padStart(2, '0')).join(''));
    return out;
  }

  // ================= Anime-Chibi-Plushies (eigene Figuren) =================
  // Teile: body | armR (winkt, Drehpunkt Schulter -3.15/-5.9) | head | eye (blinzelt) | eyeR (rechtes Auge, beim Zwinkern weg) | winkR (Zwinker-Strich)
  function chibiBoxes(it) {
    const list = [], box = (x, y, z, w, h, d, c, p = 'body') => list.push({ x, y, z, w, h, d, c, p });
    const S = it.skin || '#fde4d2', H = it.hair, H2 = shade(H, -.22), HL = shade(H, .3), E = it.eyes || '#3b82f6';
    const T = it.top || '#f8fafc', J = it.jacket, K = it.skirt || J || '#1e293b', R = it.ribbon || '#dc2626';
    const SO = it.socks || '#f8fafc', SH = it.shoes || '#5b3a29', ST = it.hairStyle || 'long', AC = it.acc || '';
    const hd = (x, y, z, w, h, d, c) => box(x, y, z, w, h, d, c, 'head');
    // Beine: sitzend, nach vorne
    for (const x of [-2.3, .3]) {
      box(x, -1.8, -4.2, 2, 1.7, 3, S);
      box(x - .05, -1.85, -5.8, 2.1, 1.8, 1.7, SO);
      box(x - .15, -2.05, -7.2, 2.3, 2.1, 1.5, SH);
      if (it.sockStripe) { box(x - .08, -1.88, -5.4, 2.16, 1.86, .35, it.sockStripe); box(x - .08, -1.88, -4.7, 2.16, 1.86, .25, it.sockStripe); }
      if (it.laces) { box(x + .45, -1.75, -7.26, 1.4, .22, .05, it.laces); box(x + .45, -1.1, -7.26, 1.4, .22, .05, it.laces); box(x + 1, -1.6, -7.27, .3, .6, .05, it.laces); }
      box(x - .15, -.4, -7.25, 2.3, .4, 1.55, shade(SH, -.3));
    }
    // Faltenrock
    const K2 = it.plaid || shade(K, -.18);
    for (let i = 0; i < 6; i++) box(-3.3 + i * 1.1, -2.9, -3.5, 1.1, 2.5, 5.8, i % 2 ? K : K2);
    if (it.plaid) { box(-3.35, -2.1, -3.55, 6.7, .28, 5.9, shade(it.plaid, -.35)); box(-3.35, -1.1, -3.55, 6.7, .2, 5.9, shade(K, .3)); }
    box(-3.3, -3.1, -3.5, 6.6, .3, 5.8, shade(K, -.3));
    if (it.belt) { box(-3.35, -3.3, -3.6, 6.7, .5, 5.95, it.belt); box(-.5, -3.38, -3.68, 1, .66, .1, '#d1d5db'); box(-.25, -3.2, -3.7, .5, .3, .05, it.belt); box(1.6, -2.8, -3.66, .2, 1, .05, '#cbd5e1'); box(1.4, -1.9, -3.68, .6, .6, .06, '#e5e7eb'); }
    // Oberkörper (Bluse + Jacke/Weste)
    if (J) {
      box(-2.6, -6.4, -1.95, 5.2, 3.6, 3.9, J);
      box(-1, -6.4, -2.05, 2, 3.4, .12, T);
      box(-.25, -4.8, -2.12, .5, .5, .08, '#facc15'); box(-.25, -3.7, -2.12, .5, .5, .08, '#facc15');
    } else box(-2.6, -6.4, -1.95, 5.2, 3.6, 3.9, T);
    if (AC === 'hoodie') { box(-2.9, -7.4, 1.4, 5.8, 1.8, 1.6, T); box(-1.8, -4.6, -2.08, 3.6, 1.4, .12, shade(T, -.15)); }
    else if (it.offShoulder) {
      box(-2.65, -6.5, -2, 5.3, .55, 4, S);
      box(-1.6, -6.45, -2.02, .3, .5, .05, T); box(1.3, -6.45, -2.02, .3, .5, .05, T);
      box(-.6, -5.6, -2.03, 1.2, .5, .06, '#cbd5e1'); box(-.2, -5.15, -2.03, .15, .5, .06, '#cbd5e1'); box(.05, -5.15, -2.03, .15, .5, .06, '#cbd5e1');
    } else {
      box(-2.8, -6.8, -2.1, 5.6, .7, 4.2, it.collar || '#f8fafc');
      if (it.sailor) box(-2.8, -6.85, -2.12, 5.6, .18, .1, R);
      // Schleife
      box(-1.4, -6.5, -2.3, 1.1, .9, .25, R); box(.3, -6.5, -2.3, 1.1, .9, .25, R);
      box(-.4, -6.4, -2.35, .8, .7, .3, shade(R, -.2));
      box(-.7, -5.7, -2.25, .5, 1.5, .15, R); box(.2, -5.7, -2.25, .5, 1.6, .15, R);
    }
    if (AC === 'scarf') { box(-3, -7.3, -2.3, 6, 1.3, 4.6, R); box(1, -6.2, -2.5, 1.3, 2.8, .4, R); box(1, -3.6, -2.5, 1.3, .4, .45, shade(R, -.25)); }
    // Arme: links ruhig auf dem Schoß, rechts winkt
    const SL = J || T;
    box(2.5, -6.2, -.7, 1.3, 3, 1.4, SL, 'armL'); box(2.5, -3.5, -.75, 1.3, .5, 1.5, T, 'armL'); box(2.6, -3, -.6, 1.1, 1, 1.2, S, 'armL');
    box(-3.8, -6.2, -.7, 1.3, 3, 1.4, SL, 'armR'); box(-3.8, -3.5, -.75, 1.3, .5, 1.5, T, 'armR'); box(-3.7, -3, -.6, 1.1, 1, 1.2, S, 'armR');
    box(-.8, -7.1, -.8, 1.6, .8, 1.6, S);
    if (it.choker) box(-.9, -7.05, -.9, 1.8, .35, 1.8, it.choker);
    // Kopf (groß, Chibi)
    hd(-4.5, -15, -4, 9, 8.2, 8, S);
    // Augen: groß, glänzend
    for (const [x0, p] of [[-3.4, 'eyeR'], [1.1, 'eye']]) {
      box(x0, -11, -4.08, 2.3, 3, .1, E, p);
      box(x0 + .5, -10.2, -4.12, 1.3, 1.6, .06, shade(E, -.45), p);
      box(x0 + .35, -8.6, -4.12, 1.6, .55, .06, shade(E, .4), p);
      box(x0 + .3, -10.7, -4.17, .75, .75, .05, '#ffffff', p);
      box(x0 + 1.5, -9, -4.17, .4, .4, .05, '#ffffff', p);
      box(x0 - .25, -11.35, -4.12, 2.8, .5, .1, '#1f1525', p);
      box(x0 + (p === 'eye' ? 2.3 : -.45), -11.1, -4.12, .45, .5, .1, '#1f1525', p);
    }
    // Zwinker-Auge (^)
    box(-3.5, -9.5, -4.1, .9, .5, .1, '#1f1525', 'winkR'); box(-2.7, -10, -4.1, .9, .5, .1, '#1f1525', 'winkR');
    box(-1.9, -9.5, -4.1, .9, .5, .1, '#1f1525', 'winkR');
    // Mund + Bäckchen + Augenbrauen
    hd(-.6, -7.9, -4.07, 1.2, .35, .06, '#b4536a'); hd(-.3, -7.6, -4.07, .6, .3, .06, '#e58aa0');
    hd(-4.1, -8.6, -4.06, 1.5, .5, .05, '#f9a8b8'); hd(2.6, -8.6, -4.06, 1.5, .5, .05, '#f9a8b8');
    // Haare: Oberseite, Hinterkopf, Seiten
    hd(-4.9, -15.7, -4.4, 9.8, 1.7, 8.8, H);
    hd(-4.9, -15, 3.4, 9.8, 7.4, 1.5, H);
    hd(-5, -14.4, -4.2, .8, 6.2, 8.2, H); hd(4.2, -14.4, -4.2, .8, 6.2, 8.2, H);
    hd(-3.2, -15.75, -1.8, 6.4, .1, 1.2, HL); hd(-4.95, -12.5, 1, .1, 1, 2.5, HL); hd(4.85, -12.5, 1, .1, 1, 2.5, HL);
    // Pony (Strähnen unterschiedlich lang)
    const len = [2.4, 3.2, 2.2, 3.6, 3.6, 2.2, 3.2, 2.4];
    len.forEach((l, i) => hd(-4.6 + i * 1.15, -14.4, -4.6, 1.15, l, .65, i % 2 ? H : H2));
    // Seitensträhnen vorne
    hd(-4.9, -13, -4.55, 1.2, ST === 'short' ? 4.8 : 6.6, 1, H2); hd(3.7, -13, -4.55, 1.2, ST === 'short' ? 4.8 : 6.6, 1, H2);
    switch (ST) {
      case 'long':
        hd(-4.6, -7.8, 2.9, 9.2, 7, 1.7, H); hd(-4, -1, 3, 8, 1, 1.4, H2);
        hd(-5, -8.6, -2.4, 1.1, 5.6, 1.6, H); hd(3.9, -8.6, -2.4, 1.1, 5.6, 1.6, H);
        hd(-4.8, -3, -2.2, .8, 1.3, 1.2, H2); hd(4, -3, -2.2, .8, 1.3, 1.2, H2); break;
      case 'bob':
        hd(-5.2, -8.4, -3.8, 1.3, 1, 7.8, H2); hd(3.9, -8.4, -3.8, 1.3, 1, 7.8, H2); hd(-4.8, -8.2, 3.2, 9.6, 1, 1.6, H2); break;
      case 'pony':
        hd(-1.1, -14.2, 4.6, 2.2, 1.6, 1, R); hd(-1.4, -13.2, 5.3, 2.8, 7.5, 1.5, H); hd(-.9, -5.8, 5.5, 1.8, 1.6, 1.1, H2); break;
      case 'twin':
        for (const s of [-1, 1]) {
          const x = s < 0 ? -6.7 : 5;
          hd(x, -14, -.8, 1.7, 1, 1.9, R); hd(x - (s < 0 ? .2 : 0), -13, -.9, 1.9, 7.5, 2.1, H); hd(x + (s < 0 ? .2 : 0), -5.6, -.6, 1.5, 2, 1.6, H2);
          if (it.tailBows) {
            const B = it.bowColor || R, bx = s < 0 ? x - .45 : x + 1.7;
            hd(bx, -15, -2, .45, 1.8, 1.6, B); hd(bx, -15, .7, .45, 1.8, 1.6, B);
            hd(bx - (s < 0 ? .1 : 0), -14.5, -.6, .55, .9, 1.4, shade(B, -.25));
            hd(bx, -13.7, -.9, .4, 1.8, .45, B); hd(bx, -13.7, 1, .4, 1.6, .45, B);
          }
        } break;
      case 'bun':
        hd(-4.6, -17.6, -.6, 2.8, 2.5, 2.8, H); hd(1.8, -17.6, -.6, 2.8, 2.5, 2.8, H);
        hd(-4.2, -15.9, -.2, 2, .4, 2, R); hd(2.2, -15.9, -.2, 2, .4, 2, R); break;
      case 'spiky':
        [[-4, 1.6], [-2, 2.4], [0, 2], [2, 2.6], [3.4, 1.5]].forEach(([x, h], i) => hd(x - .7, -15.7 - h, -2 + i % 2 * 1.5, 1.6, h, 1.8, i % 2 ? H : H2)); break;
    }
    // Zubehör
    switch (AC) {
      case 'headphones':
        hd(-5.4, -16.4, -.7, 10.8, .7, 1.4, '#1f2937');
        hd(-5.9, -12.2, -1.5, 1.1, 3, 3, it.accColor || '#38bdf8'); hd(4.8, -12.2, -1.5, 1.1, 3, 3, it.accColor || '#38bdf8'); break;
      case 'bat': hd(2.5, -14.8, -4.85, 1.2, .9, .4, '#111827'); hd(1.6, -15.1, -4.85, 1, .7, .4, '#111827'); hd(3.6, -15.1, -4.85, 1, .7, .4, '#111827'); hd(2.75, -14.6, -4.95, .25, .25, .1, '#c084fc'); hd(3.2, -14.6, -4.95, .25, .25, .1, '#c084fc'); break;
      case 'flower': hd(2.3, -14.9, -4.85, 1.8, 1.8, .4, '#f472b6'); hd(2.9, -14.3, -4.95, .6, .6, .12, '#fde047'); break;
      case 'star': hd(2.4, -14.7, -4.85, 1.6, 1.6, .4, '#fde047'); hd(2.9, -15.2, -4.85, .6, .6, .4, '#fde047'); break;
      case 'snow': hd(2.4, -14.7, -4.85, 1.6, .4, .4, '#e0f2fe'); hd(3, -15.3, -4.85, .4, 1.6, .4, '#e0f2fe'); break;
      case 'bow': hd(-2.6, -16.2, 3.2, 2.1, 1.7, 1, R); hd(.5, -16.2, 3.2, 2.1, 1.7, 1, R); hd(-.5, -15.9, 3.1, 1, 1.1, 1.2, shade(R, -.25)); break;
      case 'catears':
        hd(-4.3, -17.3, -.8, 2.2, 1.7, 1.6, H); hd(2.1, -17.3, -.8, 2.2, 1.7, 1.6, H);
        hd(-3.8, -16.9, -.85, 1.2, 1.1, .1, '#fbcfe8'); hd(2.6, -16.9, -.85, 1.2, 1.1, .1, '#fbcfe8'); break;
      case 'angel':
        hd(-2.6, -18.4, -2.6, 5.2, .4, .5, '#fde68a'); hd(-2.6, -18.4, 2.1, 5.2, .4, .5, '#fde68a'); hd(-2.6, -18.4, -2.6, .5, .4, 5.2, '#fde68a'); hd(2.1, -18.4, -2.6, .5, .4, 5.2, '#fde68a');
        for (const sd of [-1, 1]) for (let i = 0; i < 3; i++) box(sd < 0 ? -1.2 - 1.3 * (i + 1) : .9 + 1.3 * i, -7 + i * .6, 2, 1.3, 2.4 - i * .4, .4, i % 2 ? '#f1f5f9' : '#ffffff');
        break;
      case 'devil':
        hd(-3.7, -17, -1, 1, 1.4, 1, '#dc2626'); hd(2.7, -17, -1, 1, 1.4, 1, '#dc2626'); hd(-3.5, -17.8, -.8, .6, .8, .6, '#991b1b'); hd(2.9, -17.8, -.8, .6, .8, .6, '#991b1b');
        box(-.3, -2.5, 2.3, .6, .6, 2.4, '#111827'); box(-.4, -3.4, 4.5, .8, 1.2, .6, '#111827'); box(-.6, -4.2, 4.5, 1.2, .8, .6, '#dc2626'); break;
      case 'foxears':
        hd(-4.4, -17.6, -.8, 2.3, 2.2, 1.4, H); hd(2.1, -17.6, -.8, 2.3, 2.2, 1.4, H); hd(-3.9, -17.1, -.85, 1.3, 1.4, .1, '#fff7ed'); hd(2.6, -17.1, -.85, 1.3, 1.4, .1, '#fff7ed');
        box(-1, -3.6, 2.4, 2, 2, 2.6, H); box(-.8, -5.4, 4.6, 1.6, 2, 1.4, H); box(-.6, -6.4, 5.2, 1.2, 1.2, 1, '#fff7ed'); break;
      case 'witch':
        hd(-5.6, -16.3, -5, 11.2, .6, 10, '#1e1b4b'); hd(-3.6, -19, -3, 7.2, 2.8, 6, '#1e1b4b'); hd(-2.2, -21, -1.6, 4.4, 2.2, 4, '#1e1b4b'); hd(-1, -22.6, -.4, 2, 1.8, 2, '#1e1b4b');
        hd(-3.65, -16.9, -3.05, 7.3, .6, 6.1, '#a855f7'); hd(1.6, -17.1, -3.15, .9, .9, .1, '#facc15'); break;
      case 'crown':
        hd(-2.4, -16.8, -2.4, 4.8, 1.2, 4.8, '#facc15'); for (const [x, z] of [[-2.4, -2.4], [1.8, -2.4], [-2.4, 1.8], [1.8, 1.8], [-.3, -2.4]]) hd(x, -17.6, z, .6, .8, .6, '#facc15');
        hd(-.35, -16.5, -2.5, .7, .7, .1, '#ef4444'); break;
      case 'bunnyears':
        hd(-2.8, -20.4, -.6, 1.4, 4.6, 1, '#ffffff'); hd(1.4, -20.4, -.6, 1.4, 4.6, 1, '#ffffff'); hd(-2.5, -19.8, -.65, .8, 3.6, .1, '#fbcfe8'); hd(1.7, -19.8, -.65, .8, 3.6, .1, '#fbcfe8'); break;
      case 'horns': hd(-3.6, -17, -1, 1, 1.5, 1, '#fef3c7'); hd(2.6, -17, -1, 1, 1.5, 1, '#fef3c7'); hd(-3.4, -17.8, -.8, .6, .8, .6, '#fef3c7'); hd(2.8, -17.8, -.8, .6, .8, .6, '#fef3c7'); break;
    }
    return list;
  }

  // ================= 3D-Helme (gleicher Stil wie die Flügel, Kopf-Koordinaten) =================
  function helmetBoxes(it) {
    const list = [], add = (x, y, z, w, h, d, c, p = 'helm') => list.push({ x, y, z, w, h, d, c, p });
    const c1 = it.c1, c2 = it.c2, G = it.glow, O = 4.6, T = .6, st = it.style;
    // Schale
    add(-O, -8.8, -O, 2 * O, .8, 2 * O, c1);
    add(-O, -8, -O, T, 7.2, 2 * O, c1); add(O - T, -8, -O, T, 7.2, 2 * O, c1);
    add(-O + T, -8, O - T, 2 * O - 2 * T, 7.2, T, c1);
    add(-O + T, -8, -O, 2 * O - 2 * T, 2.4, T, c2);
    add(-O + T, -5.6, -O, 1.5, 4.6, T, c1); add(O - T - 1.5, -5.6, -O, 1.5, 4.6, T, c1);
    // Kante unten
    add(-O - .05, -1.1, -O - .05, 2 * O + .1, .4, 2 * O + .1, c2);
    if (it.visor) { add(-2.5, -5.6, -O + .1, 5, 3.6, .2, '#070a12'); add(-2.5, -4.6, -O + .05, 5, .5, .12, G, 'glow'); }
    switch (st) {
      case 'frost':
        [[-3.6, 1.6], [-2.2, 2.6], [-.6, 3.8], [1, 2.6], [2.4, 1.6]].forEach(([x, h]) => { add(x, -8.8 - h, -4.2, 1.2, h, 1.2, '#e0f2fe'); add(x + .3, -8.8 - h - .6, -3.9, .6, .6, .6, G, 'glow'); });
        for (const s of [-1, 1]) for (let i = 0; i < 3; i++) add(s < 0 ? -O - .9 - i * .4 : O - .1, -7.5 + i * .3, 1 + i * 1.2, 1 + i * .4, .7, .8, i % 2 ? '#7dd3fc' : '#e0f2fe');
        add(-O - .05, -6, -3.4, .1, .4, 6.8, G, 'glow'); add(O - .05, -6, -3.4, .1, .4, 6.8, G, 'glow'); break;
      case 'inferno':
        for (const s of [-1, 1]) {
          const x = s < 0 ? -O - 1.4 : O;
          add(x, -8, -1, 1.4, 1.4, 1.6, '#292524'); add(x + s * .8, -9.6, -.8, 1.2, 1.8, 1.3, '#1c1917');
          add(x + s * 1.3, -11.2, -.5, 1, 1.8, 1, '#44403c'); add(x + s * 1.5, -12.4, -.3, .7, 1.3, .7, G, 'glow');
        }
        add(-O - .05, -6.5, -2, .1, .35, 3.5, G, 'glow'); add(-O - .05, -6.3, 1.2, .1, 1.8, .35, G, 'glow');
        add(O - .05, -6.5, -1.5, .1, .35, 3.5, G, 'glow'); add(O - .05, -5, 1.6, .1, 2, .35, G, 'glow');
        add(-3.5, -8.85, -2, 7, .1, .35, G, 'glow'); add(-.2, -8.85, -4, .4, .1, 6, '#fbbf24', 'glow'); break;
      case 'void':
        [[-3.2, 2], [-1.5, 3], [0, 4.4], [1.5, 3], [3.2, 2]].forEach(([x, h]) => add(x - .35, -8.8 - h, -4.3, .7, h, .7, '#1e0b3a'));
        add(-.35, -13.6, -4.3, .7, .7, .7, G, 'glow');
        add(-2.2, -4.7, -O - .03, 1.3, .7, .1, G, 'glow'); add(.9, -4.7, -O - .03, 1.3, .7, .1, G, 'glow');
        add(-O - .05, -7.6, -3, .1, .3, 6, G, 'glow'); add(O - .05, -7.6, -3, .1, .3, 6, G, 'glow'); break;
      case 'seraph':
        add(-.45, -10.2, -3.6, .9, 1.4, 7.2, c2);
        for (const s of [-1, 1]) for (let i = 0; i < 4; i++) add(s < 0 ? -O - .5 : O, -6.8 - i * 1.05, -.5 + i * .6, .5, 1, 3 + i * 1.3, i % 2 ? '#fef3c7' : '#ffffff');
        add(-3.2, -7.95, -O - .08, 6.4, .5, .1, G, 'glow'); break;
      case 'marble':
        add(-O - .05, -7, -3.5, .1, .35, 4.5, c2); add(-O - .05, -6.7, .8, .1, 2.5, .35, c2); add(-O - .05, -4.4, .8, .1, .35, 3, c2);
        add(O - .05, -6.2, -2.5, .1, .35, 5, c2); add(O - .05, -6, 2.3, .1, 3, .35, c2);
        add(-2, -8.85, -2.6, 3.6, .1, .35, c2); add(1.2, -8.85, -2.6, .35, .1, 5, c2);
        add(-.4, -10.4, -3, .8, 1.6, 6.4, '#ffffff'); add(-.42, -10.5, -3, .84, .3, 6.4, c2); break;
      case 'aurora':
        for (let i = 0; i < 9; i++) add(-.7, -8.85, -O + i * 1.02, 1.4, .1, 1.02, hslHex(150 + i * 17, .85, .55), 'glow');
        for (let i = 0; i < 7; i++) add(-O - .05, -7.4, -3.5 + i, .1, .35, 1, hslHex(150 + i * 20, .85, .55), 'glow');
        for (let i = 0; i < 7; i++) add(O - .05, -7.4, -3.5 + i, .1, .35, 1, hslHex(150 + i * 20, .85, .55), 'glow'); break;
      case 'knight':
        add(-.5, -10.8, -2, 1, 2, 4.6, '#dc2626'); add(-.5, -9.6, 2.6, 1, 2.6, 1.4, '#b91c1c');
        add(-.4, -5.6, -O - .05, .8, 4.4, .2, c2); break;
      case 'neon':
        add(-O - .05, -8.85, -O - .05, 2 * O + .1, .12, .3, G, 'glow'); add(-O - .05, -8.85, O - .25, 2 * O + .1, .12, .3, G, 'glow');
        add(-O - .05, -8.85, -O, .3, .12, 2 * O, G, 'glow'); add(O - .25, -8.85, -O, .3, .12, 2 * O, G, 'glow');
        add(-O - .05, -5, -3, .1, .3, 6, G, 'glow'); add(O - .05, -5, -3, .1, .3, 6, G, 'glow');
        add(-O - .6, -6.4, -.2, .6, 2.8, .4, '#111827'); add(-O - .6, -9, -.15, .25, 2.6, .3, G, 'glow'); break;
    }
    return list;
  }

  // Würfel-Modell als kleines Vorschaubild (Schrägansicht)
  function boxesSVG(list, glow) {
    const k = .32, boxes = list.filter(b => b.p !== 'winkR');
    let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    const poly = [];
    for (const b of boxes) {
      const zf = b.z, zb = b.z + b.d, X = b.x, Y = b.y, W = b.w, Hh = b.h;
      const f = [[X + zf * k, Y - zf * k], [X + W + zf * k, Y - zf * k], [X + W + zf * k, Y + Hh - zf * k], [X + zf * k, Y + Hh - zf * k]];
      const top = [[X + zf * k, Y - zf * k], [X + W + zf * k, Y - zf * k], [X + W + zb * k, Y - zb * k], [X + zb * k, Y - zb * k]];
      const side = [[X + W + zf * k, Y - zf * k], [X + W + zb * k, Y - zb * k], [X + W + zb * k, Y + Hh - zb * k], [X + W + zf * k, Y + Hh - zf * k]];
      for (const [px, py] of [...f, ...top, ...side]) { x0 = Math.min(x0, px); y0 = Math.min(y0, py); x1 = Math.max(x1, px); y1 = Math.max(y1, py); }
      poly.push({ b, key: zf + zb, f, top, side });
    }
    poly.sort((a, b) => b.key - a.key);
    const pts = (a) => a.map(([x, y]) => `${x.toFixed(2)},${y.toFixed(2)}`).join(' ');
    const sz = Math.max(x1 - x0, y1 - y0) * 1.08, cx = (x0 + x1) / 2, cy = (y0 + y1) / 2, id = nid('bx');
    let s = '';
    for (const { b, f, top, side } of poly) {
      const gl = b.p === 'glow' ? ` filter="url(#${id})"` : '';
      s += `<g${gl}><polygon points="${pts(top)}" fill="${shade(b.c, .14)}"/><polygon points="${pts(side)}" fill="${shade(b.c, -.22)}"/><polygon points="${pts(f)}" fill="${b.c}"/></g>`;
    }
    return `<svg viewBox="${(cx - sz / 2).toFixed(2)} ${(cy - sz / 2).toFixed(2)} ${sz.toFixed(2)} ${sz.toFixed(2)}"><defs><filter id="${id}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation=".35" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>${s}</svg>`;
  }
  // Höhe, auf der ein Plushie auf dem Kopf sitzt (oben auf dem Helm, vordere Zacken ausgenommen)
  function petHeadTop(helm) {
    if (!helm) return -8.05;
    let top = -8.9;
    for (const b of helmetBoxes(helm)) if (Math.abs(b.x + b.w / 2) < 2.5 && b.z + b.d > -3.4 && b.y < top) top = b.y;
    return top - .05;
  }
  // Bänder über dem Helm: Würfel um die Kopfmitte vergrößern
  function scaleBoxes(list, s) {
    if (s === 1) return list;
    return list.map(b => ({ ...b, x: b.x * s, y: -4 + (b.y + 4) * s, z: b.z * s, w: b.w * s, h: b.h * s, d: b.d * s }));
  }

  // ================= 3D-Plushies aus Würfeln =================
  // Pixel-Einheiten, Ursprung unten in der Mitte, y nach unten (wie Minecraft-Modelle), vorne = -z.
  // p: 'body' | 'head' (wackelt mit) | 'eye' (blinzelt)
  function plushBoxes(it) {
    if (it.type === 'chibi') return chibiBoxes(it);
    const B = it.body, L = it.belly || shade(B, .55), D = shade(B, -.35), list = [];
    const box = (x, y, z, w, h, d, c, p = 'body') => list.push({ x, y, z, w, h, d, c, p });
    const T = it.type;
    // Körper
    if (T !== 'ghost') {
      box(-3, -5, -2.5, 6, 5, 5, B);
      box(-2, -4, -2.7, 4, 3, .2, L);
      box(-4, -4.5, -1, 1, 3, 2, T === 'panda' ? '#1f2937' : B);
      box(3, -4.5, -1, 1, 3, 2, T === 'panda' ? '#1f2937' : B);
      const foot = T === 'penguin' ? '#f97316' : T === 'panda' ? '#1f2937' : D;
      box(-2.5, -1, -3, 2, 1, 2, foot); box(.5, -1, -3, 2, 1, 2, foot);
    } else {
      box(-3.5, -6, -3, 7, 6, 6, '#f1f5f9');
      box(-3.5, -1, -3, 1.5, 1, 6, '#e2e8f0'); box(-.75, -1, -3, 1.5, 1, 6, '#e2e8f0'); box(2, -1, -3, 1.5, 1, 6, '#e2e8f0');
    }
    // Kopf
    const HB = T === 'ghost' ? '#f1f5f9' : B;
    box(-4, -12, -3.5, 8, 7, 7, HB, 'head');
    // Gesicht
    if (T === 'penguin') box(-3, -11, -3.7, 6, 5.5, .2, '#f8fafc', 'head');
    if (T === 'panda') { box(-3.2, -10, -3.7, 2.2, 2.6, .2, '#1f2937', 'head'); box(1, -10, -3.7, 2.2, 2.6, .2, '#1f2937', 'head'); }
    const ey = T === 'frog' ? -14 : -9.5;
    if (T === 'frog') { box(-3.6, -14.5, -2, 2.6, 2.6, 2.6, B, 'head'); box(1, -14.5, -2, 2.6, 2.6, 2.6, B, 'head'); }
    const ez = T === 'frog' ? -2.2 : -3.7;
    box(-2.5, ey, ez, 1, 1.6, .2, '#1a1a2e', 'eye'); box(1.5, ey, ez, 1, 1.6, .2, '#1a1a2e', 'eye');
    box(-2.2, ey + .1, ez - .05, .4, .4, .1, '#ffffff', 'eye'); box(1.8, ey + .1, ez - .05, .4, .4, .1, '#ffffff', 'eye');
    const blush = T === 'ghost' ? '#93c5fd' : '#f9a8d4';
    box(-3.6, -7.2, -3.65, 1.1, .6, .1, blush, 'head'); box(2.5, -7.2, -3.65, 1.1, .6, .1, blush, 'head');
    // Typ-Details
    switch (T) {
      case 'fox':
        box(-4, -14.5, -1, 2.2, 2.5, 2, B, 'head'); box(1.8, -14.5, -1, 2.2, 2.5, 2, B, 'head');
        box(-4, -15, -1, 1.2, .6, 2, '#292524', 'head'); box(2.8, -15, -1, 1.2, .6, 2, '#292524', 'head');
        box(-1.6, -7.2, -4.5, 3.2, 1.8, 1, '#fff7ed', 'head'); box(-.5, -7.3, -4.6, 1, .6, .1, '#292524', 'head');
        box(2, -4.5, 2.5, 2, 2, 4, B); box(2, -4.5, 6.5, 2, 2, 1.2, '#fff7ed'); break;
      case 'axolotl':
        for (const sx of [-1, 1]) for (let i = 0; i < 3; i++) box(sx < 0 ? -6 : 4, -11.5 + i * 1.6, -.5, 2, .9, 1, '#ec4899', 'head');
        break;
      case 'dragon':
        box(-3, -14, -1, 1, 2, 1, '#fef3c7', 'head'); box(2, -14, -1, 1, 2, 1, '#fef3c7', 'head');
        box(-.5, -13, 0, 1, 1, 3, '#8b5cf6', 'head');
        box(-6, -6, 2.6, 3, 4, .3, '#8b5cf6'); box(3, -6, 2.6, 3, 4, .3, '#8b5cf6');
        box(-1, -2, 2.5, 2, 1.5, 4, B); break;
      case 'penguin':
        box(-.8, -7.6, -4.3, 1.6, .9, .8, '#f97316', 'head'); break;
      case 'frog':
        box(-2.5, -6.6, -3.65, 5, .4, .1, D, 'head'); break;
      case 'bear':
        box(-4, -13.5, -.75, 2, 2, 1.5, B, 'head'); box(2, -13.5, -.75, 2, 2, 1.5, B, 'head');
        box(-1.5, -7.2, -4.2, 3, 1.8, .6, L, 'head'); box(-.6, -7.4, -4.3, 1.2, .6, .1, '#292524', 'head'); break;
      case 'bunny':
        box(-3, -18, -.6, 1.6, 6, 1.2, B, 'head'); box(1.4, -18, -.6, 1.6, 6, 1.2, B, 'head');
        box(-2.7, -17.4, -.7, 1, 4.8, .1, '#fbcfe8', 'head'); box(1.7, -17.4, -.7, 1, 4.8, .1, '#fbcfe8', 'head');
        box(-.4, -7.4, -3.75, .8, .5, .1, '#f472b6', 'head'); break;
      case 'panda':
        box(-4, -13.5, -.75, 2, 2, 1.5, '#1f2937', 'head'); box(2, -13.5, -.75, 2, 2, 1.5, '#1f2937', 'head');
        box(-.5, -7.4, -3.75, 1, .6, .1, '#1f2937', 'head'); break;
      case 'bee':
        box(-3.05, -3.6, -2.55, 6.1, .9, 5.1, '#1f2937'); box(-3.05, -1.8, -2.55, 6.1, .9, 5.1, '#1f2937');
        box(-5, -7, 2.5, 3, 2.5, .2, '#e0f2fe'); box(2, -7, 2.5, 3, 2.5, .2, '#e0f2fe');
        box(-2, -14, -.25, .5, 2, .5, '#1f2937', 'head'); box(1.5, -14, -.25, .5, 2, .5, '#1f2937', 'head'); break;
      case 'shark':
        box(-.5, -15, -.5, 1, 3, 3, B, 'head');
        box(-5.5, -4, -.5, 1.5, .8, 2, B); box(4, -4, -.5, 1.5, .8, 2, B);
        box(-1.5, -6.6, -3.65, 3, .5, .1, '#ffffff', 'head'); break;
      case 'sigi':
        box(-.25, -14.5, -.25, .5, 2.5, .5, D, 'head'); box(-.8, -15.6, -.8, 1.6, 1.6, 1.6, '#fde047', 'head'); break;
    }
    if (!['penguin', 'fox', 'bear', 'frog', 'shark', 'ghost'].includes(T)) box(-.6, -6.6, -3.65, 1.2, .4, .1, '#1f2937', 'head');
    return list;
  }

  // ================= Katalog =================
  const COSMETICS = {
    wings: {
      label: 'Flügel', icon: '🕊️', items: [
        { id: 'custom', name: '✎ Eigene Flügel', rarity: 'mythic', custom: true, style: 'feather', colors: ['#7c3aed', '#e9d5ff'], glow: '#c084fc' },
        { id: 'aurora', name: 'Aurora-Flügel', rarity: 'mythic', style: 'aurora', colors: ['#22c55e', '#06b6d4', '#a855f7'], glow: '#67e8f9', flap: 2.2 },
        { id: 'seraph', name: 'Seraph-Flügel', rarity: 'mythic', style: 'seraph', colors: ['#fffbeb', '#fde68a'], glow: '#fbbf24', flap: 2.4 },
        { id: 'marble', name: 'Marmor-Sternenflügel', rarity: 'mythic', style: 'marble', colors: ['#000000', '#141418'], glow: 'rgba(255,255,255,.45)', flap: 2.4 },
        { id: 'voiddragon', name: 'Void-Drachenflügel', rarity: 'mythic', style: 'frostdragon', colors: ['#05010d', '#1e0b3a'], glow: '#a855f7', fold: true, vein: '#a855f7', vein2: '#c084fc', edge: '#6b21a8', spike: '#e9d5ff', core: '#faf5ff' },
        { id: 'infernodragon', name: 'Inferno-Drachenflügel', rarity: 'mythic', style: 'frostdragon', colors: ['#0c0402', '#3b0a04'], glow: '#f97316', fold: true, vein: '#f97316', vein2: '#fbbf24', edge: '#7c2d12', spike: '#fed7aa', core: '#fff7ed' },
        { id: 'toxicdragon', name: 'Gift-Drachenflügel', rarity: 'legendary', style: 'frostdragon', colors: ['#020a03', '#0b2b10'], glow: '#84cc16', fold: true, vein: '#84cc16', vein2: '#bef264', edge: '#365314', spike: '#ecfccb', core: '#f7fee7' },
        { id: 'frostdragon', name: 'Frostdrachen-Flügel', rarity: 'mythic', style: 'frostdragon', colors: ['#020617', '#0c1a3a'], glow: '#38bdf8', fold: true },
        { id: 'starfeather', name: 'Sternenfeder-Flügel', rarity: 'mythic', style: 'starfeather', colors: ['#000000', '#16161d'], glow: 'rgba(255,255,255,.55)', flap: 2.2 },
        { id: 'phoenix', name: 'Phönixflügel', rarity: 'mythic', style: 'phoenix', colors: ['#b91c1c', '#fbbf24'], glow: '#f97316' },
        { id: 'galaxy', name: 'Galaxieflügel', rarity: 'mythic', style: 'galaxy', colors: ['#1e1b4b', '#a855f7'], glow: '#8b5cf6' },
        { id: 'dragon', name: 'Drachenflügel', rarity: 'legendary', style: 'membrane', colors: ['#450a0a', '#dc2626'], glow: '#f97316' },
        { id: 'mecha', name: 'Mecha-Flügel', rarity: 'legendary', style: 'mecha', glow: '#22d3ee', flap: 2.6 },
        { id: 'angel', name: 'Engelsflügel', rarity: 'epic', style: 'feather', colors: ['#cbd5e1', '#ffffff'], glow: '#fef3c7' },
        { id: 'demon', name: 'Dämonenflügel', rarity: 'epic', style: 'membrane', colors: ['#0f0a1e', '#6d28d9'], glow: '#a855f7' },
        { id: 'crystal', name: 'Kristallflügel', rarity: 'rare', style: 'crystal', colors: ['#e0f2fe', '#38bdf8'], glow: '#7dd3fc' },
        { id: 'butterfly', name: 'Schmetterling', rarity: 'rare', style: 'butterfly', colors: ['#06b6d4', '#ec4899'] },
        { id: 'raven', name: 'Rabenflügel', rarity: 'common', style: 'feather', colors: ['#0b0b0f', '#374151'] }
      ]
    },
    cape: {
      label: 'Umhänge', icon: '🧣', items: [
        { id: 'capeimg', name: '✎ Bild-Umhang (PNG)', rarity: 'mythic', custom: 'capeimg', style: 'image', bg: '#111827', borderColor: '#a855f7', borderW: 3, borderGlow: true, zoom: 100, ox: 0, oy: 0 },
        { id: 'custom', name: '✎ Eigener Umhang', rarity: 'mythic', custom: true, style: 'custom', c1: '#7c3aed', c2: '#1e1b4b', border: '#fbbf24', pattern: 'stars', emblem: 'Σ' },
        { id: 'aurora', name: 'Aurora-Umhang', rarity: 'mythic', style: 'aurora' },
        { id: 'galaxy', name: 'Galaxie-Umhang', rarity: 'mythic', style: 'galaxy' },
        { id: 'scales', name: 'Drachenschuppen', rarity: 'legendary', style: 'scales' },
        { id: 'sigma', name: 'Baddy-Umhang', rarity: 'legendary', style: 'sigma' },
        { id: 'lava', name: 'Lava-Umhang', rarity: 'legendary', style: 'lava' },
        { id: 'storm', name: 'Gewitter-Umhang', rarity: 'epic', style: 'storm' },
        { id: 'rainbow', name: 'Regenbogen', rarity: 'epic', style: 'rainbow' },
        { id: 'sakura', name: 'Kirschblüte', rarity: 'rare', style: 'sakura' },
        { id: 'ocean', name: 'Ozean', rarity: 'rare', style: 'ocean' },
        { id: 'classic', name: 'Klassisch Rot', rarity: 'common', style: 'classic' }
      ]
    },
    head: {
      label: 'Kopf', icon: '👑', items: [
        { id: 'custom', name: '✎ Eigenes Stirnband', rarity: 'mythic', custom: true, kind: 'band', color: '#7c3aed', color2: '#c4b5fd', pattern: 'stripes', emblem: 'Σ' },
        { id: 'photoband', name: '✎ Foto-Stirnband', rarity: 'mythic', custom: 'photoband', kind: 'pband', color: '#111111' },
        { id: 'chainhalo', name: '✎ Ketten-Halo (S/W)', rarity: 'mythic', custom: 'chainhalo', kind: 'vhalo', style: 'chain', c1: '#0a0a0a', c2: '#ffffff', chainColor: '#d4d4d8', chains: 2, orbitY: -4 },
        { id: 'darkhalo', name: 'Void-Halo', rarity: 'mythic', kind: 'vhalo', style: 'spiked', c1: '#7e22ce', c2: '#e9d5ff' },
        { id: 'halo_saturn', name: 'Saturn-Halo', rarity: 'mythic', kind: 'vhalo', style: 'saturn', c1: '#f59e0b', c2: '#fde68a', orbitY: -10.5 },
        { id: 'halo_double', name: 'Doppel-Halo', rarity: 'mythic', kind: 'vhalo', style: 'double', c1: '#fbbf24', c2: '#ffffff', orbitY: -11 },
        { id: 'halo_broken', name: 'Zerbrochener Halo', rarity: 'legendary', kind: 'vhalo', style: 'broken', c1: '#e5e7eb', c2: '#a5b4fc', orbitY: -11 },
        { id: 'halo_thorn', name: 'Dornen-Halo', rarity: 'legendary', kind: 'vhalo', style: 'thorn', c1: '#450a0a', c2: '#ef4444' },
        { id: 'halo_crown', name: 'Kronen-Halo', rarity: 'legendary', kind: 'vhalo', style: 'crownhalo', c1: '#facc15', c2: '#fff7ed' },
        { id: 'halo_ice', name: 'Frost-Halo', rarity: 'legendary', kind: 'vhalo', style: 'spiked', c1: '#38bdf8', c2: '#f0f9ff' },
        { id: 'halo_blood', name: 'Blutmond-Halo', rarity: 'epic', kind: 'vhalo', style: 'double', c1: '#dc2626', c2: '#fecaca', orbitY: -11 },
        { id: 'halo_neon', name: 'Neon-Halo', rarity: 'epic', kind: 'vhalo', style: 'classic', c1: '#e879f9', c2: '#22d3ee' },
        { id: 'halo_emerald', name: 'Smaragd-Halo', rarity: 'epic', kind: 'vhalo', style: 'broken', c1: '#10b981', c2: '#d1fae5', orbitY: -11 },
        { id: 'halo', name: 'Heiligenschein', rarity: 'rare', kind: 'vhalo', style: 'classic', c1: '#fbbf24', c2: '#fff7d6' },
        { id: 'band_gradient', name: 'Farbverlauf-Stirnband', rarity: 'epic', kind: 'band', color: '#06b6d4', color2: '#a855f7', pattern: 'gradient' },
        { id: 'band_zigzag', name: 'Zickzack-Stirnband', rarity: 'epic', kind: 'band', color: '#111827', color2: '#facc15', pattern: 'zigzag' },
        { id: 'band_heart', name: 'Herz-Stirnband', rarity: 'rare', kind: 'band', color: '#fda4af', color2: '#e11d48', pattern: 'dots', emblem: '♥' },
        { id: 'band_flag', name: 'Schwarz-Rot-Gold', rarity: 'rare', kind: 'band', color: '#000000', color2: '#dd0000', color3: '#ffce00', pattern: 'tri' },
        { id: 'band_mono2', name: 'S/W-Streifen', rarity: 'rare', kind: 'band', color: '#0a0a0a', color2: '#fafafa', pattern: 'stripes', glow: null },
        { id: 'band_rainbow', name: 'Regenbogen-Stirnband', rarity: 'legendary', kind: 'band', color: '#ef4444', pattern: 'rainbow', emblem: '★' },
        { id: 'band_gold', name: 'Gold-Stirnband', rarity: 'legendary', kind: 'band', color: '#eab308', color2: '#a16207', gem: '#ef4444' },
        { id: 'band_flame', name: 'Flammen-Stirnband', rarity: 'epic', kind: 'band', color: '#f97316', color2: '#dc2626', pattern: 'stripes' },
        { id: 'band_galaxy', name: 'Galaxie-Stirnband', rarity: 'epic', kind: 'band', color: '#1e1b4b', color2: '#e9d5ff', pattern: 'dots' },
        { id: 'band_sakura', name: 'Kirschblüten-Stirnband', rarity: 'rare', kind: 'band', color: '#f9a8d4', color2: '#ffffff', pattern: 'dots', emblem: '♥' },
        { id: 'band_mono', name: 'Schachbrett-Stirnband', rarity: 'rare', kind: 'band', color: '#111111', color2: '#f5f5f5', pattern: 'checker' },
        { id: 'band_sigma', name: 'Baddy-Stirnband', rarity: 'legendary', kind: 'band', color: '#7c3aed', color2: '#4c1d95', text: 'Σ', emblem: 'Σ', glow: '#c084fc' },
        { id: 'crown', name: 'Königskrone', rarity: 'legendary', kind: 'crown' },
        { id: 'dragonhorns', name: 'Drachenhörner', rarity: 'legendary', kind: 'horns', colors: ['#1c1917', '#57534e'], glow: '#f97316' },
        { id: 'icecrown', name: 'Eiskrone', rarity: 'epic', kind: 'crown', colors: ['#f0f9ff', '#7dd3fc', '#0369a1'], gem: '#a855f7', gem2: '#e0f2fe', glow: '#7dd3fc' },
        { id: 'wizard', name: 'Zauberhut', rarity: 'epic', kind: 'wizard' },
        { id: 'band_neon', name: 'Neon-Stirnband', rarity: 'rare', kind: 'band', color: '#06b6d4', glow: '#22d3ee' },
        { id: 'headset', name: 'Gamer-Headset', rarity: 'rare', kind: 'headset' },
        { id: 'horns', name: 'Teufelshörner', rarity: 'rare', kind: 'horns', colors: ['#7f1d1d', '#ef4444'] },
        { id: 'band_ninja', name: 'Ninja-Stirnband', rarity: 'common', kind: 'band', color: '#dc2626' },
        { id: 'band_sportx', name: 'Sport-Stirnband Blau', rarity: 'common', kind: 'band', color: '#f8fafc', color2: '#2563eb', pattern: 'stripes' }
      ]
    },
    helmet: {
      label: 'Helme', icon: '⛑️', items: [
        { id: 'voidhelm', name: 'Void-Helm', rarity: 'mythic', style: 'void', c1: '#0b0614', c2: '#3b0764', glow: '#a855f7', visor: true },
        { id: 'infernohelm', name: 'Inferno-Helm', rarity: 'mythic', style: 'inferno', c1: '#1c0a05', c2: '#7c2d12', glow: '#f97316', visor: true },
        { id: 'frosthelm', name: 'Frostdrachen-Helm', rarity: 'legendary', style: 'frost', c1: '#dbeafe', c2: '#7dd3fc', glow: '#38bdf8', visor: true },
        { id: 'aurorahelm', name: 'Polarlicht-Helm', rarity: 'legendary', style: 'aurora', c1: '#0f172a', c2: '#1e293b', glow: '#34d399', visor: true },
        { id: 'seraphhelm', name: 'Seraph-Helm', rarity: 'legendary', style: 'seraph', c1: '#f8fafc', c2: '#fbbf24', glow: '#fde68a' },
        { id: 'marblehelm', name: 'Marmor-Helm', rarity: 'epic', style: 'marble', c1: '#f5f5f4', c2: '#d4a017', glow: '#fde68a' },
        { id: 'neonhelm', name: 'Neon-Cyber-Helm', rarity: 'epic', style: 'neon', c1: '#111827', c2: '#1f2937', glow: '#22d3ee', visor: true },
        { id: 'knighthelm', name: 'Ritterhelm', rarity: 'rare', style: 'knight', c1: '#9ca3af', c2: '#6b7280', glow: '#e5e7eb', visor: true }
      ]
    },
    aura: {
      label: 'Auren', icon: '✨', items: [
        { id: 'void', name: 'Void-Portal', rarity: 'mythic', ring: 'portal', ring2: true, sprite: 'orb', motion: 'spiral', c1: '#a855f7', c2: '#1e0b3a', pillar: true, orbs: 3, count: 16 },
        { id: 'runes', name: 'Runenkreis', rarity: 'mythic', ring: 'runes', ring2: true, sprite: 'rune', motion: 'rise', c1: '#c084fc', c2: '#f5d0fe', orbs: 2 },
        { id: 'inferno', name: 'Inferno', rarity: 'mythic', ring: 'flame', sprite: 'flame', motion: 'rise', c1: '#f97316', c2: '#fde047', pillar: true, count: 18, speed: 1.3 },
        { id: 'mono', name: 'Schwarz-Weiß-Ketten', rarity: 'mythic', ring: 'thorns', ring2: true, sprite: 'chain', motion: 'orbit', c1: '#ffffff', c2: '#52525b', orbs: 4, count: 14 },
        { id: 'galaxy', name: 'Galaxie', rarity: 'mythic', ring: 'stars', ring2: true, sprite: 'star', motion: 'spiral', c1: '#818cf8', c2: '#f0abfc', orbs: 3, count: 18 },
        { id: 'angel', name: 'Himmelslicht', rarity: 'mythic', ring: 'spikes', sprite: 'feather', motion: 'fall', c1: '#fde68a', c2: '#ffffff', pillar: true, count: 14 },
        { id: 'storm', name: 'Gewitter', rarity: 'legendary', ring: 'spikes', sprite: 'bolt', motion: 'rise', c1: '#facc15', c2: '#fef9c3', orbs: 2, speed: 1.6 },
        { id: 'frost', name: 'Frostwirbel', rarity: 'legendary', ring: 'hex', sprite: 'snow', motion: 'spiral', c1: '#7dd3fc', c2: '#f0f9ff', pillar: true },
        { id: 'blood', name: 'Blutmond', rarity: 'legendary', ring: 'hex', ring2: true, sprite: 'moon', motion: 'orbit', c1: '#dc2626', c2: '#fecaca', orbs: 3 },
        { id: 'emerald', name: 'Smaragd-Magie', rarity: 'legendary', ring: 'hex', sprite: 'diamond', motion: 'rise', c1: '#10b981', c2: '#a7f3d0', orbs: 2 },
        { id: 'sun', name: 'Sonnenkönig', rarity: 'legendary', ring: 'spikes', ring2: true, sprite: 'cross', motion: 'rise', c1: '#f59e0b', c2: '#fff7ed', pillar: true },
        { id: 'neon', name: 'Neon-Grid', rarity: 'legendary', ring: 'tech', ring2: true, sprite: 'pixel', motion: 'rise', c1: '#e879f9', c2: '#22d3ee', speed: 1.4 },
        { id: 'toxic', name: 'Giftnebel', rarity: 'epic', ring: 'waves', sprite: 'bubble', motion: 'rise', c1: '#84cc16', c2: '#ecfccb', orbs: 2 },
        { id: 'ocean', name: 'Tiefsee', rarity: 'epic', ring: 'waves', sprite: 'bubble', motion: 'rise', c1: '#0ea5e9', c2: '#e0f2fe' },
        { id: 'shadow', name: 'Schattenseelen', rarity: 'epic', ring: 'portal', sprite: 'skull', motion: 'spiral', c1: '#6b7280', c2: '#f4f4f5', pillar: true },
        { id: 'music', name: 'Musik', rarity: 'epic', ring: 'double', sprite: 'note', motion: 'orbit', c1: '#f472b6', c2: '#a5f3fc' },
        { id: 'stardust', name: 'Sternenstaub', rarity: 'epic', ring: 'stars', sprite: 'star', motion: 'rise', c1: '#fde68a', c2: '#ffffff' },
        { id: 'gold', name: 'Goldregen', rarity: 'epic', ring: 'double', sprite: 'diamond', motion: 'fall', c1: '#facc15', c2: '#fef3c7' },
        { id: 'sakura', name: 'Kirschblüten', rarity: 'rare', ring: 'hearts', sprite: 'petal', motion: 'fall', c1: '#f9a8d4', c2: '#fdf2f8' },
        { id: 'hearts', name: 'Herzen', rarity: 'rare', ring: 'hearts', sprite: 'heart', motion: 'rise', c1: '#f43f5e', c2: '#fecdd3' },
        { id: 'nature', name: 'Waldgeist', rarity: 'rare', ring: 'double', sprite: 'leaf', motion: 'fall', c1: '#22c55e', c2: '#bbf7d0' },
        { id: 'snow', name: 'Schneesturm', rarity: 'rare', ring: '', sprite: 'snow', motion: 'fall', c1: '#e0f2fe', c2: '#ffffff', count: 18 },
        { id: 'pixel', name: 'Pixel-Regenbogen', rarity: 'rare', ring: 'tech', sprite: 'pixel', motion: 'rise', c1: '#f43f5e', c2: '#38bdf8' },
        { id: 'flames', name: 'Kleine Flammen', rarity: 'common', ring: '', sprite: 'flame', motion: 'rise', c1: '#f97316', c2: '#fde047' }
      ]
    },
    feet: {
      label: 'Schuhe', icon: '👟', items: [
        { id: 'rocket', name: 'Raketenschuhe', rarity: 'mythic', style: 'rocket', colors: ['#334155', '#cbd5e1'], cuff: '#ef4444', glow: '#f97316', fx: 'jet' },
        { id: 'void', name: 'Void-Stiefel', rarity: 'mythic', style: 'void', colors: ['#0b0614', '#1e0b3a'], glow: '#a855f7' },
        { id: 'fireboots', name: 'Lava-Stiefel', rarity: 'legendary', style: 'lava', colors: ['#1c1917', '#292524'], glow: '#f97316', fx: 'fire' },
        { id: 'iceboots', name: 'Eisstiefel', rarity: 'legendary', style: 'ice', colors: ['#0369a1', '#bae6fd'], cuff: '#f0f9ff', glow: '#7dd3fc', fx: 'ice' },
        { id: 'heelwings', name: 'Flügelschuhe', rarity: 'legendary', style: 'heelwings', colors: ['#f8fafc', '#e2e8f0'], cuff: '#fbbf24', sole: '#d4a017' },
        { id: 'crystal', name: 'Kristallstiefel', rarity: 'legendary', style: 'crystal', colors: ['#312e81', '#6366f1'], glow: '#c4b5fd' },
        { id: 'goldboots', name: 'Goldstiefel', rarity: 'epic', style: 'gold', colors: ['#a16207', '#fde047'], cuff: '#fef3c7', fx: 'gold' },
        { id: 'neon', name: 'Neon-Sneaker', rarity: 'epic', style: 'neon', colors: ['#020617', '#1e293b'], glow: '#22d3ee', sole: '#ec4899', fx: 'neon' },
        { id: 'skate', name: 'Rollschuhe', rarity: 'epic', style: 'skate', colors: ['#f8fafc', '#ef4444'], sole: '#e5e7eb', stripe: '#ef4444' },
        { id: 'bunny', name: 'Hasen-Pantoffeln', rarity: 'epic', style: 'bunny', colors: ['#fce7f3', '#fbcfe8'], sole: '#f9a8d4' },
        { id: 'frog', name: 'Frosch-Pantoffeln', rarity: 'rare', style: 'frog', colors: ['#4ade80', '#22c55e'], sole: '#166534' },
        { id: 'cloud', name: 'Wolkenschuhe', rarity: 'rare', style: 'cloud', colors: ['#e2e8f0', '#ffffff'], sole: '#cbd5e1', fx: 'cloud' },
        { id: 'street', name: 'Street-Sneaker', rarity: 'rare', style: 'sneaker', colors: ['#f8fafc', '#111827'], sole: '#f8fafc', stripe: '#dc2626' },
        { id: 'ninja', name: 'Ninja-Tabi', rarity: 'rare', style: 'ninja', colors: ['#18181b', '#3f3f46'], sole: '#0a0a0a' },
        { id: 'leather', name: 'Lederstiefel', rarity: 'common', style: 'boot', colors: ['#451a03', '#92400e'] }
      ]
    },
    pet: {
      label: 'Plushies', icon: '🧸', items: [
        { id: 'chibi_akira', name: 'Akira (Engel)', rarity: 'mythic', type: 'chibi', hair: '#f8fafc', eyes: '#f59e0b', hairStyle: 'long', jacket: '#f1f5f9', skirt: '#e2e8f0', ribbon: '#fbbf24', acc: 'angel', shoes: '#f8fafc' },
        { id: 'chibi_kuro', name: 'Kuro (Teufelchen)', rarity: 'mythic', type: 'chibi', hair: '#111827', eyes: '#ef4444', hairStyle: 'bob', jacket: '#7f1d1d', skirt: '#111827', ribbon: '#111827', acc: 'devil', socks: '#111827', shoes: '#450a0a' },
        { id: 'chibi_momo', name: 'Momo (Fuchsgeist)', rarity: 'mythic', type: 'chibi', hair: '#fb923c', eyes: '#b45309', hairStyle: 'twin', top: '#ffffff', skirt: '#dc2626', ribbon: '#dc2626', sailor: true, collar: '#dc2626', acc: 'foxears' },
        { id: 'chibi_lila', name: 'Lila (Hexe)', rarity: 'legendary', type: 'chibi', hair: '#7c3aed', eyes: '#22c55e', hairStyle: 'long', jacket: '#1e1b4b', skirt: '#312e81', ribbon: '#a855f7', acc: 'witch', socks: '#312e81', sockStripe: '#a855f7', shoes: '#111827' },
        { id: 'chibi_haru', name: 'Haru (Prinz)', rarity: 'legendary', type: 'chibi', hair: '#fde047', eyes: '#2563eb', hairStyle: 'short', jacket: '#1e3a8a', skirt: '#1e3a8a', ribbon: '#facc15', acc: 'crown', shoes: '#111827' },
        { id: 'chibi_usagi', name: 'Usagi (Häschen)', rarity: 'epic', type: 'chibi', hair: '#fbcfe8', eyes: '#db2777', hairStyle: 'bun', top: '#ffffff', skirt: '#f9a8d4', ribbon: '#f472b6', acc: 'bunnyears' },
        { id: 'chibi_nyx', name: 'Nyx (Anime)', rarity: 'mythic', type: 'chibi', hair: '#dc2626', eyes: '#3b82f6', hairStyle: 'bun', top: '#111827', offShoulder: true, choker: '#111827', skirt: '#7f1d1d', plaid: '#1f1f2e', belt: '#18181b', socks: '#f8fafc', sockStripe: '#111827', shoes: '#111827', laces: '#d1d5db', acc: 'bat', ribbon: '#111827' },
        { id: 'chibi_mira', name: 'Mira (Anime)', rarity: 'mythic', type: 'chibi', hair: '#1f1b2e', eyes: '#e11d48', hairStyle: 'long', jacket: '#1e293b', skirt: '#4c1d95', ribbon: '#e11d48', acc: 'bow' },
        { id: 'chibi_yuki', name: 'Yuki (Anime)', rarity: 'mythic', type: 'chibi', hair: '#f1f5f9', eyes: '#38bdf8', hairStyle: 'long', jacket: '#bae6fd', skirt: '#0369a1', ribbon: '#0ea5e9', acc: 'snow', socks: '#e0f2fe', shoes: '#334155' },
        { id: 'chibi_luna', name: 'Luna (Anime)', rarity: 'legendary', type: 'chibi', hair: '#7c3aed', eyes: '#f59e0b', hairStyle: 'long', jacket: '#1e1b4b', skirt: '#312e81', ribbon: '#facc15', acc: 'star' },
        { id: 'chibi_hana', name: 'Hana (Anime)', rarity: 'legendary', type: 'chibi', hair: '#f9a8d4', eyes: '#16a34a', hairStyle: 'bob', top: '#ffffff', skirt: '#db2777', ribbon: '#db2777', sailor: true, collar: '#fbcfe8', acc: 'flower' },
        { id: 'chibi_aki', name: 'Aki (Anime)', rarity: 'legendary', type: 'chibi', hair: '#7c4a2d', eyes: '#d97706', hairStyle: 'twin', jacket: '#7f1d1d', skirt: '#3f3f46', ribbon: '#fbbf24', acc: '' },
        { id: 'chibi_kiko', name: 'Kiko (Anime)', rarity: 'epic', type: 'chibi', hair: '#fde047', eyes: '#8b5cf6', hairStyle: 'bun', top: '#ffffff', skirt: '#1e3a8a', ribbon: '#dc2626', sailor: true, collar: '#1e3a8a', acc: '' },
        { id: 'chibi_yuzu', name: 'Yuzu (Anime)', rarity: 'epic', type: 'chibi', hair: '#dc2626', eyes: '#3b82f6', hairStyle: 'twin', tailBows: true, bowColor: '#111827', top: '#ef4444', collar: '#f8fafc', skirt: '#1f2937', ribbon: '#111827', acc: '' },
        { id: 'chibi_sora', name: 'Sora (Anime)', rarity: 'epic', type: 'chibi', hair: '#cbd5e1', eyes: '#2563eb', hairStyle: 'short', top: '#3b82f6', skirt: '#1e293b', acc: 'hoodie', ribbon: '#3b82f6', shoes: '#f8fafc' },
        { id: 'chibi_nori', name: 'Nori (Anime)', rarity: 'rare', type: 'chibi', hair: '#4ade80', eyes: '#facc15', hairStyle: 'short', top: '#a3a3a3', skirt: '#404040', acc: 'catears', ribbon: '#facc15' },
        { id: 'chibi_kai', name: 'Kai (Anime)', rarity: 'rare', type: 'chibi', hair: '#1e3a8a', eyes: '#94a3b8', hairStyle: 'spiky', jacket: '#111827', skirt: '#111827', ribbon: '#dc2626', acc: 'scarf' },
        { id: 'chibi_rin', name: 'Rin (Anime)', rarity: 'rare', type: 'chibi', hair: '#a16207', eyes: '#f43f5e', hairStyle: 'bob', jacket: '#14532d', skirt: '#166534', ribbon: '#fde047', acc: 'horns' },
        { id: 'chibi_tomo', name: 'Tomo (Anime)', rarity: 'common', type: 'chibi', hair: '#292524', eyes: '#0d9488', hairStyle: 'short', top: '#f8fafc', skirt: '#0f172a', acc: 'headphones', accColor: '#f43f5e', ribbon: '#0f172a' },
        { id: 'sigi', name: 'Sigi (Maskottchen)', rarity: 'mythic', type: 'sigi', body: '#7c3aed', belly: '#c4b5fd' },
        { id: 'dragon', name: 'Mini-Drache', rarity: 'legendary', type: 'dragon', body: '#10b981', belly: '#d1fae5' },
        { id: 'axolotl', name: 'Axolotl', rarity: 'epic', type: 'axolotl', body: '#f9a8d4', belly: '#fce7f3' },
        { id: 'panda', name: 'Panda', rarity: 'epic', type: 'panda', body: '#f8fafc', belly: '#ffffff' },
        { id: 'shark', name: 'Hai', rarity: 'epic', type: 'shark', body: '#60a5fa', belly: '#f8fafc' },
        { id: 'fox', name: 'Fuchs', rarity: 'rare', type: 'fox', body: '#f97316', belly: '#fff7ed' },
        { id: 'ghost', name: 'Geist', rarity: 'rare', type: 'ghost', body: '#f1f5f9' },
        { id: 'bunny', name: 'Hase', rarity: 'rare', type: 'bunny', body: '#f1f5f9', belly: '#ffffff' },
        { id: 'bee', name: 'Biene', rarity: 'rare', type: 'bee', body: '#facc15', belly: '#fef9c3' },
        { id: 'penguin', name: 'Pinguin', rarity: 'common', type: 'penguin', body: '#1f2937', belly: '#f8fafc' },
        { id: 'frog', name: 'Frosch', rarity: 'common', type: 'frog', body: '#22c55e', belly: '#bbf7d0' },
        { id: 'bear', name: 'Teddy', rarity: 'common', type: 'bear', body: '#a16207', belly: '#fde68a' }
      ]
    }
  };

  // ---------- 100+ Flügel: jeder Stil in vielen Farbwelten ----------
  (function moreWings() {
    const PAL = [
      ['blut', 'Blut', ['#2a0505', '#b91c1c', '#f87171'], '#ef4444'],
      ['ozean', 'Ozean', ['#04213a', '#0284c7', '#7dd3fc'], '#38bdf8'],
      ['smaragd', 'Smaragd', ['#022c22', '#059669', '#6ee7b7'], '#34d399'],
      ['gold', 'Gold', ['#422006', '#ca8a04', '#fde68a'], '#facc15'],
      ['rose', 'Rosé', ['#4a0d2a', '#db2777', '#fbcfe8'], '#f472b6'],
      ['amethyst', 'Amethyst', ['#1e0638', '#7c3aed', '#ddd6fe'], '#a78bfa'],
      ['eis', 'Eis', ['#0c1a2e', '#93c5fd', '#f0f9ff'], '#bae6fd'],
      ['schatten', 'Schatten', ['#000000', '#1f1f23', '#71717a'], '#ffffff'],
      ['sunset', 'Sonnenuntergang', ['#3b0764', '#e11d48', '#fb923c'], '#fdba74'],
      ['neon', 'Neon', ['#0a0014', '#d946ef', '#22d3ee'], '#e879f9'],
      ['toxic', 'Toxic', ['#0a1a02', '#65a30d', '#d9f99d'], '#a3e635'],
      ['lava', 'Lava', ['#1c0701', '#ea580c', '#fde047'], '#f97316'],
      ['mitternacht', 'Mitternacht', ['#020617', '#1e3a8a', '#6366f1'], '#818cf8'],
      ['kirsch', 'Kirschblüte', ['#3f0d1f', '#f9a8d4', '#fff1f2'], '#fbcfe8'],
      ['schnee', 'Schneeweiß', ['#94a3b8', '#e2e8f0', '#ffffff'], '#ffffff'],
      ['kupfer', 'Kupfer', ['#1c0a02', '#b45309', '#fcd34d'], '#f59e0b']
    ];
    const STYLES = [
      ['feather', 'Federflügel', 'epic', ['blut', 'ozean', 'smaragd', 'gold', 'rose', 'amethyst', 'schatten', 'sunset', 'kirsch', 'kupfer']],
      ['phoenix', 'Phönixflügel', 'mythic', ['ozean', 'smaragd', 'amethyst', 'neon', 'toxic', 'eis', 'schatten', 'rose', 'mitternacht']],
      ['galaxy', 'Galaxieflügel', 'legendary', ['blut', 'ozean', 'smaragd', 'gold', 'rose', 'sunset', 'neon', 'toxic', 'schatten']],
      ['membrane', 'Drachenflügel', 'legendary', ['ozean', 'smaragd', 'gold', 'amethyst', 'eis', 'schatten', 'neon', 'toxic', 'kupfer']],
      ['frostdragon', 'Wyvern-Flügel', 'mythic', ['blut', 'ozean', 'gold', 'rose', 'schatten', 'neon', 'lava', 'mitternacht', 'kirsch', 'schnee']],
      ['mecha', 'Mecha-Flügel', 'legendary', ['blut', 'smaragd', 'gold', 'rose', 'amethyst', 'neon', 'toxic', 'lava', 'schnee']],
      ['crystal', 'Kristallflügel', 'rare', ['blut', 'smaragd', 'gold', 'rose', 'amethyst', 'schatten', 'sunset', 'neon', 'toxic']],
      ['starfeather', 'Sternenfeder-Flügel', 'mythic', ['blut', 'ozean', 'smaragd', 'gold', 'amethyst', 'mitternacht', 'rose', 'schnee']],
      ['marble', 'Marmorflügel', 'mythic', ['blut', 'ozean', 'gold', 'amethyst', 'schnee', 'smaragd', 'rose', 'mitternacht']],
      ['aurora', 'Aurora-Flügel', 'mythic', ['blut', 'gold', 'rose', 'sunset', 'neon', 'eis', 'schatten', 'lava', 'kirsch']],
      ['seraph', 'Seraph-Flügel', 'mythic', ['ozean', 'smaragd', 'rose', 'amethyst', 'schatten', 'eis', 'blut', 'schnee']],
      ['butterfly', 'Schmetterling', 'rare', ['blut', 'ozean', 'gold', 'amethyst', 'sunset', 'neon', 'toxic', 'kirsch', 'mitternacht']]
    ];
    const P = Object.fromEntries(PAL.map(p => [p[0], p]));
    const list = COSMETICS.wings.items, have = new Set(list.map(i => i.id));
    for (const [style, label, rarity, pals] of STYLES) {
      for (const pid of pals) {
        const [, pname, cols, glow] = P[pid], id = `${style}_${pid}`;
        if (have.has(id)) continue;
        const it = { id, name: `${pname}-${label}`, rarity, style, colors: style === 'aurora' ? cols : [cols[0], cols[1]], glow };
        if (style === 'marble' || style === 'starfeather') it.colors = [cols[0], shade(cols[0], .08)];
        if (style === 'frostdragon') Object.assign(it, { colors: [cols[0], shade(cols[1], -.55)], fold: true, vein: glow, vein2: shade(glow, .3), edge: shade(cols[1], -.2), spike: cols[2], core: '#ffffff' });
        if (style === 'mecha') it.glow = cols[2] === '#ffffff' ? '#e2e8f0' : glow;
        list.push(it);
      }
    }
  })();

  function svgFor(cat, item) {
    item = resolve(cat, item);
    if (cat === 'wings') return wingsSVG(item);
    if (cat === 'cape') return capeSVG(item);
    if (cat === 'head') { const hb = item.kind === 'vhalo' || item.kind === 'pband' ? headBoxesFor(item) : null; return hb ? boxesSVG(hb) : headSVG(item); }
    if (cat === 'feet') return boxesSVG(shoeBoxes(item));
    if (cat === 'aura') return auraTileSVG(item);
    if (cat === 'pet') return plushSVG(item);
    if (cat === 'helmet') return boxesSVG([{ x: -4, y: -8, z: -4, w: 8, h: 8, d: 8, c: '#2b3040', p: 'helm' }, { x: -2.6, y: -5, z: -4.05, w: 1.2, h: 1, d: .1, c: '#5b6275' }, { x: 1.4, y: -5, z: -4.05, w: 1.2, h: 1, d: .1, c: '#5b6275' }, ...helmetBoxes(item)]);
    return '';
  }

  // ================= Quests (Belohnungen = exklusive Cosmetics) =================
  const QUESTS = [
    { id: 'walk1', name: 'Wanderer', desc: 'Laufe 5.000 Blöcke', stat: 'walk', goal: 5000, reward: ['feet', 'q_wander'] },
    { id: 'jump1', name: 'Flummi', desc: 'Springe 2.000 Mal', stat: 'jump', goal: 2000, reward: ['feet', 'q_spring'] },
    { id: 'mine1', name: 'Bergarbeiter', desc: 'Baue 1.000 Blöcke ab', stat: 'mine', goal: 1000, reward: ['head', 'q_miner'] },
    { id: 'hit1', name: 'Kämpfer', desc: 'Triff 500 Mal Gegner', stat: 'hit', goal: 500, reward: ['cape', 'q_warrior'] },
    { id: 'emote1', name: 'Showtime', desc: 'Spiele 100 Emotes ab', stat: 'emote', goal: 100, reward: ['aura', 'q_disco'] },
    { id: 'swim1', name: 'Delfin', desc: 'Schwimme 2.000 Blöcke', stat: 'swim', goal: 2000, reward: ['wings', 'q_ocean'] },
    { id: 'server1', name: 'Entdecker', desc: 'Betrete 10 Mal einen Server', stat: 'server', goal: 10, reward: ['feet', 'q_explorer'] },
    { id: 'play1', name: 'Stammspieler', desc: 'Spiele 10 Stunden', stat: 'play', goal: 600, reward: ['helmet', 'q_veteran'] },
    { id: 'mine2', name: 'Tunnel-König', desc: 'Baue 10.000 Blöcke ab', stat: 'mine', goal: 10000, reward: ['aura', 'q_diamond'] },
    { id: 'fly1', name: 'Himmelsstürmer', desc: 'Fliege 10.000 Blöcke mit Elytren', stat: 'fly', goal: 10000, reward: ['head', 'q_sky'] },
    { id: 'walk2', name: 'Weltenbummler', desc: 'Laufe 50.000 Blöcke', stat: 'walk', goal: 50000, reward: ['wings', 'q_globe'] },
    { id: 'all', name: 'Baddy-Legende', desc: 'Schaffe alle anderen Quests', stat: 'quests', goal: 11, reward: ['wings', 'q_legend'] }
  ];
  // Tägliche Quests: jeden Tag 3 zufällige, jede gibt einen ⭐ Stern
  const DAILY = [
    { id: 'd_walk', desc: 'Laufe 1.000 Blöcke', stat: 'walk', goal: 1000 },
    { id: 'd_mine', desc: 'Baue 200 Blöcke ab', stat: 'mine', goal: 200 },
    { id: 'd_jump', desc: 'Springe 150 Mal', stat: 'jump', goal: 150 },
    { id: 'd_hit', desc: 'Triff 50 Mal Gegner', stat: 'hit', goal: 50 },
    { id: 'd_emote', desc: 'Spiele 5 Emotes ab', stat: 'emote', goal: 5 },
    { id: 'd_play', desc: 'Spiele 30 Minuten', stat: 'play', goal: 30 },
    { id: 'd_swim', desc: 'Schwimme 200 Blöcke', stat: 'swim', goal: 200 },
    { id: 'd_sprint', desc: 'Sprinte 1.500 Blöcke', stat: 'sprint', goal: 1500 }
  ];
  const STAR_REWARDS = [[5, 'aura', 'q_star5'], [15, 'wings', 'q_star15'], [30, 'pet', 'chibi_qstar']];
  (function addQuestRewards() {
    const R = {
      feet: [{ id: 'q_wander', name: '🏆 Wanderstiefel', rarity: 'legendary', style: 'boot', colors: ['#3f6212', '#65a30d'], cuff: '#facc15', quest: 'walk1' },
        { id: 'q_spring', name: '🏆 Sprungfedern', rarity: 'legendary', style: 'skate', colors: ['#facc15', '#f97316'], sole: '#111827', stripe: '#f97316', quest: 'jump1' },
        { id: 'q_explorer', name: '🏆 Entdecker-Sneaker', rarity: 'mythic', style: 'neon', colors: ['#022c22', '#064e3b'], glow: '#34d399', sole: '#a3e635', quest: 'server1' }],
      head: [{ id: 'q_miner', name: '🏆 Diamant-Krone', rarity: 'mythic', kind: 'vhalo', style: 'crownhalo', c1: '#22d3ee', c2: '#ecfeff', quest: 'mine1' },
        { id: 'q_sky', name: '🏆 Himmelsring', rarity: 'mythic', kind: 'vhalo', style: 'saturn', c1: '#38bdf8', c2: '#f0f9ff', orbitY: -10.5, quest: 'fly1' }],
      cape: [{ id: 'q_warrior', name: '🏆 Kriegerumhang', rarity: 'mythic', style: 'custom', c1: '#7f1d1d', c2: '#1c1917', border: '#f59e0b', pattern: 'stripes', emblem: '★', quest: 'hit1' }],
      aura: [{ id: 'q_disco', name: '🏆 Disco', rarity: 'mythic', ring: 'tech', ring2: true, sprite: 'note', motion: 'orbit', c1: '#f472b6', c2: '#22d3ee', orbs: 4, quest: 'emote1' },
        { id: 'q_diamond', name: '🏆 Diamantsturm', rarity: 'mythic', ring: 'hex', ring2: true, sprite: 'diamond', motion: 'spiral', c1: '#22d3ee', c2: '#ecfeff', pillar: true, orbs: 3, quest: 'mine2' },
        { id: 'q_star5', name: '⭐ Sternenregen', rarity: 'legendary', ring: 'stars', sprite: 'star', motion: 'fall', c1: '#facc15', c2: '#fff7ed', stars: 5 }],
      wings: [{ id: 'q_ocean', name: '🏆 Delfinflügel', rarity: 'mythic', style: 'crystal', colors: ['#0c4a6e', '#38bdf8'], glow: '#7dd3fc', quest: 'swim1' },
        { id: 'q_globe', name: '🏆 Weltenbummler-Flügel', rarity: 'mythic', style: 'aurora', colors: ['#0ea5e9', '#22c55e', '#facc15'], glow: '#a7f3d0', quest: 'walk2' },
        { id: 'q_legend', name: '🏆 Baddy-Legende', rarity: 'mythic', style: 'seraph', colors: ['#0a0a0a', '#fbbf24'], glow: '#fde68a', quest: 'all' },
        { id: 'q_star15', name: '⭐ Sternenkönig-Flügel', rarity: 'mythic', style: 'starfeather', colors: ['#1c1402', '#2a1f05'], glow: '#facc15', stars: 15 }],
      helmet: [{ id: 'q_veteran', name: '🏆 Veteranenhelm', rarity: 'mythic', style: 'knight', c1: '#facc15', c2: '#a16207', glow: '#fde68a', visor: true, quest: 'play1' }],
      pet: [{ id: 'chibi_qstar', name: '⭐ Stella (30 Sterne)', rarity: 'mythic', type: 'chibi', hair: '#fde047', eyes: '#06b6d4', hairStyle: 'twin', jacket: '#1e3a8a', skirt: '#1e3a8a', ribbon: '#facc15', acc: 'star', stars: 30 }]
    };
    for (const [cat, items] of Object.entries(R)) COSMETICS[cat].items.unshift(...items);
  })();
  let UNLOCK = { done: [], stars: 0 }, ALL_FREE = false;
  function setUnlocks(u) { UNLOCK = { done: u?.done || [], stars: u?.stars || 0 }; }
  function setAllFree(v) { ALL_FREE = !!v; }
  function isLocked(item) {
    if (!item || ALL_FREE) return false;
    if (item.quest) return !UNLOCK.done.includes(item.quest);
    if (item.stars) return UNLOCK.stars < item.stars;
    return false;
  }
  // ---------- Bild-Cache: jedes SVG wird nur EINMAL in ein Bild umgewandelt (spart extrem viel Leistung) ----------
  const IMG_VER = 'v30';
  const IMG = new Map(), waiting = new Map(), queue = [];
  let busy = false;
  function hashStr(str) { let h = 0; for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) | 0; return (h >>> 0).toString(36); }
  async function rasterSVG(svg, w, h, type = 'image/png', q) {
    const src = svg.replace('<svg ', `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" `);
    const img = new Image();
    img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(src);
    await img.decode();
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    c.getContext('2d').drawImage(img, 0, 0, w, h);
    return c.toDataURL(type, q);
  }
  function svgRatio(svg) {
    const m = /viewBox="([\d.\-]+) ([\d.\-]+) ([\d.]+) ([\d.]+)"/.exec(svg);
    return m ? +m[4] / +m[3] : 1;
  }
  function pump() {
    if (busy || !queue.length) return;
    busy = true;
    const job = queue.shift();
    let svg;
    try { svg = job.svg(); } catch { busy = false; return setTimeout(pump, 0); }
    const h = Math.max(8, Math.round(job.w * svgRatio(svg)));
    rasterSVG(svg, job.w, h, 'image/webp', .92).then(url => {
      IMG.set(job.key, url);
      try { localStorage.setItem('sx:' + job.key, url); } catch { }
      (waiting.get(job.key) || []).forEach(f => { try { f(url); } catch { } });
    }).catch(() => { }).finally(() => { waiting.delete(job.key); busy = false; setTimeout(pump, 0); });
  }
  function cachedImage(key, svgFn, w, cb) {
    key = IMG_VER + ':' + key;
    let url = IMG.get(key);
    if (!url) { try { url = localStorage.getItem('sx:' + key); if (url) IMG.set(key, url); } catch { } }
    if (url) return url;
    if (cb) {
      if (!waiting.has(key)) { waiting.set(key, []); queue.push({ key, svg: svgFn, w }); setTimeout(pump, 0); }
      waiting.get(key).push(cb);
    }
    return null;
  }
  const itemKey = (cat, item) => `${cat}:${item.id}:${hashStr(JSON.stringify(item))}`;
  // alte Cache-Einträge aufräumen
  try { for (let i = localStorage.length - 1; i >= 0; i--) { const k = localStorage.key(i); if (k && k.startsWith('sx:') && !k.startsWith('sx:' + IMG_VER)) localStorage.removeItem(k); } } catch { }

  function tile(cat, item) {
    const key = itemKey(cat, item), w = cat === 'wings' ? 240 : 180;
    const url = cachedImage(key, () => cat === 'aura' ? auraTileSVG(item) : svgFor(cat, item), w, (u) => {
      document.querySelectorAll('img.tile-img').forEach(i => { if (i.dataset.k === key) i.src = u; });
    });
    return `<img class="tile-img" data-k="${key}" ${url ? `src="${url}"` : ''} alt="" draggable="false">`;
  }

  // ================= Standard-Skin (eigene Figur, 64x64) =================
  let defaultSkinUrl = null;
  function defaultSkin() {
    if (defaultSkinUrl) return defaultSkinUrl;
    const c = document.createElement('canvas');
    c.width = 64; c.height = 64;
    const x = c.getContext('2d');
    const R = (a, b, w, h, col) => { x.fillStyle = col; x.fillRect(a, b, w, h); };
    const skin = '#d9a57c', hair = '#3b2614', hood = '#6d28d9', hood2 = '#8b5cf6', pants = '#272b38', shoe = '#14161d', L = '#e9d5ff';
    R(0, 0, 32, 16, skin); R(8, 0, 8, 8, hair); R(24, 8, 8, 8, hair);
    R(0, 8, 8, 3, hair); R(16, 8, 8, 3, hair); R(8, 8, 8, 2, hair); R(8, 10, 1, 2, hair); R(15, 10, 1, 2, hair);
    R(9, 12, 2, 1, '#fff'); R(13, 12, 2, 1, '#fff'); R(10, 12, 1, 1, '#2e1065'); R(13, 12, 1, 1, '#2e1065'); R(11, 14, 2, 1, '#9a6a4a');
    R(16, 16, 24, 16, hood); R(20, 20, 8, 1, hood2);
    R(22, 23, 3, 1, L); R(22, 24, 1, 1, L); R(25, 24, 1, 1, L); R(22, 25, 3, 1, L); R(22, 26, 1, 1, L); R(25, 26, 1, 1, L); R(22, 27, 3, 1, L); // B für Baddy
    for (const [ax, ay] of [[40, 16], [32, 48]]) { R(ax, ay, 16, 16, skin); R(ax, ay + 4, 16, 4, hood2); R(ax + 4, ay, 4, 4, hood2); }
    for (const [lx, ly] of [[0, 16], [16, 48]]) { R(lx, ly, 16, 16, pants); R(lx, ly + 13, 16, 3, shoe); R(lx + 8, ly, 4, 4, shoe); }
    return (defaultSkinUrl = c.toDataURL());
  }

  // ================= 3D-Figur aus CSS-Würfeln =================
  const P = (n) => `calc(${n} * var(--px))`;
  function face(url, texH, fx, fy, fw, fh, transform, pos) {
    const f = document.createElement('div');
    f.className = 'f3';
    f.style.cssText = `width:${P(fw)};height:${P(fh)};${pos || ''}transform:${transform};` +
      `background-image:url("${url}");background-size:${P(64)} ${P(texH)};background-position:${P(-fx)} ${P(-fy)};`;
    return f;
  }
  // MC-Box: UV (u,v), Maße w×h×d, Mittelpunkt (cx,cy) in Texeln
  function box(url, texH, u, v, w, h, d, cx, cy, cls, grow) {
    const b = document.createElement('div');
    b.className = `part ${cls || ''}`;
    b.style.cssText = `left:${P(cx - w / 2)};top:${P(cy - h / 2)};width:${P(w)};height:${P(h)};`;
    const inner = document.createElement('div');
    inner.className = 'part-in';
    if (grow) inner.style.transform = `scale3d(${(w + grow) / w},${(h + grow) / h},${(d + grow) / d})`;
    const hz = P(d / 2), hw = P(w / 2), hh = P(h / 2);
    inner.append(
      face(url, texH, u + d, v + d, w, h, `translateZ(${hz})`),
      face(url, texH, u + 2 * d + w, v + d, w, h, `rotateY(180deg) translateZ(${hz})`),
      face(url, texH, u, v + d, d, h, `rotateY(-90deg) translateZ(${hw})`, `left:${P((w - d) / 2)};`),
      face(url, texH, u + d + w, v + d, d, h, `rotateY(90deg) translateZ(${hw})`, `left:${P((w - d) / 2)};`),
      face(url, texH, u + d, v, w, d, `rotateX(90deg) translateZ(${hh})`, `top:${P((h - d) / 2)};`),
      face(url, texH, u + d + w, v, w, d, `rotateX(-90deg) translateZ(${hh})`, `top:${P((h - d) / 2)};`)
    );
    b.appendChild(inner);
    return b;
  }
  function limb(url, texH, base, over, w, cx, cy, cls, legacy) {
    const g = document.createElement('div');
    g.className = `limb ${cls}`;
    g.style.cssText = `left:${P(cx)};top:${P(cy - 6)};`;
    g.appendChild(box(url, texH, base[0], base[1], w, 12, 4, 0, 6));
    if (over && !legacy) g.appendChild(box(url, texH, over[0], over[1], w, 12, 4, 0, 6, 'overlay', .5));
    return g;
  }
  function plane(html, x, y, w, transform, cls, origin) {
    const d = document.createElement('div');
    d.className = `cplane ${cls || ''}`;
    d.style.cssText = `left:${P(x - 8)};top:${P(y)};width:${P(w)};transform:${transform};${origin ? `transform-origin:${origin};` : ''}`;
    d.innerHTML = html;
    return d;
  }
  const HEAD_POS = {
    band: { x: 3.6, y: 1.4, w: 13 }, halo: { x: 2.5, y: -4.2, w: 11 }, crown: { x: 4.2, y: -3.4, w: 7.6 },
    horns: { x: 2, y: -3.6, w: 12 }, headset: { x: 2.6, y: -1, w: 10.8 }, wizard: { x: 2.8, y: -7.6, w: 10.4 }
  };
  let CUSTOM = {};
  let WS = 1, PS = 1, PSPOT = 'left';
  function setCustom(c) {
    CUSTOM = c || {};
    WS = Math.min(2.4, Math.max(.6, (+CUSTOM.wingScale || 100) / 100));
    PS = Math.min(1.6, Math.max(.5, (+CUSTOM.petScale || 100) / 100));
    PSPOT = ['left', 'right', 'head'].includes(CUSTOM.petSpot) ? CUSTOM.petSpot : 'left';
  }
  function resolve(cat, item) {
    if (!item || !item.custom) return item;
    return { ...item, ...(CUSTOM[item.custom === true ? cat : item.custom] || {}) };
  }
  const findItem = (cat, id) => resolve(cat, COSMETICS[cat]?.items.find(i => i.id === id));

  function cosmeticPlanes(model, head, equipped) {
    for (const [cat, id] of Object.entries(equipped)) {
      const item = findItem(cat, id);
      if (!item || cat === 'aura') continue;
      if (cat === 'wings') {
        for (const side of [1, -1]) {
          const wrap = document.createElement('div');
          wrap.className = `cplane wing-half ${side > 0 ? 'wr' : 'wl'}`;
          wrap.style.cssText = `left:${P(side > 0 ? 0 : -14)};top:${P(5.5)};width:${P(14)};height:${P(16.8)};` +
            `transform-origin:${side > 0 ? 'left' : 'right'} ${P(6.3)};`;
          const inner = document.createElement('div');
          inner.style.cssText = `position:absolute;top:0;width:${P(28)};left:${P(side > 0 ? -14 : 0)};`;
          const wkey = itemKey('wings', item) + ':big';
          const wurl = cachedImage(wkey, () => svgFor('wings', item), 560, (u) => { inner.innerHTML = `<img src="${u}" style="width:100%;display:block" draggable="false">`; });
          inner.innerHTML = wurl ? `<img src="${wurl}" style="width:100%;display:block" draggable="false">` : svgFor('wings', item);
          wrap.appendChild(inner);
          model.appendChild(wrap);
        }
      } else if (cat === 'cape') {
        const ckey = itemKey('cape', item) + ':big';
        const capeHTML = (u) => `<img src="${u}" style="width:100%;display:block" draggable="false">`;
        const curl = cachedImage(ckey, () => svgFor('cape', item), 270, (u) => { const cs = model.querySelector('.cape-sway'); if (cs) cs.innerHTML = capeHTML(u); });
        model.appendChild(plane(`<div class="cape-sway">${curl ? capeHTML(curl) : svgFor('cape', item)}</div>`, 3.5, 8, 9,
          `translateZ(${P(-2.8)}) rotateY(180deg)`, 'cape3d', 'top center'));
      } else if (cat === 'head') {
        const p = HEAD_POS[item.kind];
        const hb = headBoxesFor(item);
        if (hb) {
          const hs = equipped.helmet && findItem('helmet', equipped.helmet) ? 1.2 : 1;
          const tails = document.createElement('div');
          tails.className = 'band-tails';
          tails.style.transformOrigin = `${P(1.4 * hs)} ${P(-4 - .7 * hs)} ${P(-4.9 * hs)}`;
          const spin = document.createElement('div'); spin.className = 'hspin';
          const orbit = document.createElement('div'); orbit.className = 'horbit';
          orbit.style.transformOrigin = `0 ${P(-4 + ((item.orbitY ?? -4) + 4) * hs)} 0`;
          const orbitIn = document.createElement('div'); orbitIn.className = 'horbit-in';
          orbit.appendChild(orbitIn);
          for (const b of scaleBoxes(hb, hs)) {
            const p0 = b.p || '';
            (p0 === 'tail' ? tails : p0.startsWith('spin') ? spin : p0.startsWith('orbit') ? orbitIn : head).appendChild(colorBox(b));
          }
          head.append(tails, spin, orbit);
        } else {
          head.appendChild(plane(svgFor('head', item), p.x, p.y - 8, p.w, 'none'));
          head.appendChild(plane(svgFor('head', item), p.x, p.y - 8, p.w, 'rotateY(90deg)'));
        }
      } else if (cat === 'helmet') {
        for (const b of helmetBoxes(item)) head.appendChild(colorBox(b));
      } else if (cat === 'feet') {
        // Schuhe hängen jetzt direkt an den Beinen und laufen mit (vorher schwebten sie)
        for (const leg of model.querySelectorAll('.leg-r, .leg-l')) for (const b of shoeBoxes(item)) leg.appendChild(colorBox(b));
      } else if (cat === 'pet') {
        const pl = plush3D(item);
        if (PSPOT === 'head') {
          const top = petHeadTop(equipped.helmet && findItem('helmet', equipped.helmet));
          pl.style.left = P(0); pl.style.top = P(top); pl.style.setProperty('--pry', '0deg');
          pl.style.transform = `translateZ(${P(-1.2)}) scale3d(${.5 * PS},${.5 * PS},${.5 * PS})`;
          head.appendChild(pl);
        } else {
          if (PSPOT === 'right') { pl.style.left = P(-6); pl.style.setProperty('--pry', '20deg'); }
          model.appendChild(pl);
        }
      }
    }
  }


  // farbiger Würfel aus 6 Flächen (für 3D-Plushies)
  const SHADES = new Map();
  function faceCol(c, l) {
    const k = c + l;
    let v = SHADES.get(k);
    if (!v) { v = l === 1 ? c : shade(c, l > 1 ? (l - 1) * 1.2 : (l - 1) * .9); SHADES.set(k, v); }
    return v;
  }
  function colorBox(b) {
    const el = document.createElement('div');
    const glow = b.p === 'glow' || (b.p && b.p.endsWith('Glow'));
    el.className = `cbox${['eye', 'eyeR', 'winkR'].includes(b.p) ? ' ' + b.p : ''}`;
    el.style.cssText = `left:${P(b.x)};top:${P(b.y)};width:${P(b.w)};height:${P(b.h)};transform:translateZ(${P(-(b.z + b.d / 2))});`;
    const hd = P(b.d / 2), hw = P(b.w / 2), hh = P(b.h / 2);
    const thinZ = b.d <= .16, thinX = b.w <= .16, thinY = b.h <= .16;
    const faces = [
      [b.w, b.h, `translateZ(${hd})`, '', 1, thinX || thinY],
      [b.w, b.h, `rotateY(180deg) translateZ(${hd})`, '', .8, thinX || thinY],
      [b.d, b.h, `rotateY(-90deg) translateZ(${hw})`, `left:${P((b.w - b.d) / 2)};`, .72, thinZ || thinY],
      [b.d, b.h, `rotateY(90deg) translateZ(${hw})`, `left:${P((b.w - b.d) / 2)};`, .72, thinZ || thinY],
      [b.w, b.d, `rotateX(90deg) translateZ(${hh})`, `top:${P((b.h - b.d) / 2)};`, 1.12, thinZ || thinX],
      [b.w, b.d, `rotateX(-90deg) translateZ(${hh})`, `top:${P((b.h - b.d) / 2)};`, .55, thinZ || thinX]
    ];
    let html = '';
    for (const [w, h, tr, pos, light, skip] of faces) {
      if (skip) continue;
      html += `<div class="cf" style="width:${P(w)};height:${P(h)};${pos}transform:${tr};background:${glow ? b.c : faceCol(b.c, light)}"></div>`;
    }
    el.innerHTML = html;
    if (glow) el.classList.add('glow');
    return el;
  }
  function plush3D(item) {
    // sitzt auf der linken Schulter (Betrachter rechts), halb so groß
    const wrap = document.createElement('div');
    wrap.className = 'plush3d';
    wrap.style.cssText = `left:${P(6)};top:${P(8)};transform:scale3d(${.5 * PS},${.5 * PS},${.5 * PS});`;
    const hop = document.createElement('div');
    hop.className = 'plush-hop';
    const head = document.createElement('div');
    head.className = 'plush-head';
    head.style.transformOrigin = `0 ${P(-5)} 0`;
    const arm = document.createElement('div');
    arm.className = 'plush-wave';
    arm.style.transformOrigin = `${P(-3.15)} ${P(-5.9)} 0`;
    for (const b of plushBoxes(item)) (b.p === 'body' || b.p === 'armL' ? hop : b.p === 'armR' ? arm : head).appendChild(colorBox(b));
    hop.appendChild(arm);
    hop.appendChild(head);
    wrap.appendChild(hop);
    return wrap;
  }
  // ================= Bühne =================
  function buildStage(stage, { skin, equipped = {}, spin = false, view = 'front', interactive = false }) {
    stage.innerHTML = '';
    const url = skin?.img?.src || defaultSkin();
    const legacy = skin?.img?.height === 32;
    const texH = legacy ? 32 : 64, aw = skin?.slim ? 3 : 4;
    const rot = document.createElement('div');
    rot.className = `rot3d${spin ? ' spin' : ''}`;
    rot.style.setProperty('--ry', view === 'back' ? '180deg' : '-20deg');
    const model = document.createElement('div');
    model.className = 'model3d walk';
    model.style.setProperty('--ws', WS);

    const head = document.createElement('div');
    head.className = 'limb head3d';
    head.style.cssText = `left:${P(0)};top:${P(8)};`;
    head.appendChild(box(url, texH, 0, 0, 8, 8, 8, 0, -4));
    head.appendChild(box(url, texH, 32, 0, 8, 8, 8, 0, -4, 'overlay', 1));
    model.appendChild(head);

    model.appendChild(box(url, texH, 16, 16, 8, 12, 4, 0, 14));
    if (!legacy) model.appendChild(box(url, texH, 16, 32, 8, 12, 4, 0, 14, 'overlay', .5));
    model.appendChild(limb(url, texH, [40, 16], [40, 32], aw, -4 - aw / 2, 14, 'arm-r', legacy));
    model.appendChild(limb(url, texH, legacy ? [40, 16] : [32, 48], [48, 48], aw, 4 + aw / 2, 14, 'arm-l', legacy));
    model.appendChild(limb(url, texH, [0, 16], [0, 32], 4, -2, 26, 'leg-r', legacy));
    model.appendChild(limb(url, texH, legacy ? [0, 16] : [16, 48], [0, 48], 4, 2, 26, 'leg-l', legacy));

    cosmeticPlanes(model, head, equipped);
    rot.appendChild(model);
    stage.appendChild(rot);

    const aura = equipped.aura && findItem('aura', equipped.aura);
    if (aura) {
      const [back, front] = auraLayers(aura);
      stage.insertBefore(back, rot);
      stage.appendChild(front);
    }
    if (interactive) {
      let drag = null, ry = view === 'back' ? 180 : -20;
      stage.onpointerdown = (e) => { drag = { x: e.clientX, ry }; stage.setPointerCapture(e.pointerId); rot.classList.add('dragging'); };
      stage.onpointermove = (e) => { if (!drag) return; ry = drag.ry + (e.clientX - drag.x) * .8; rot.style.setProperty('--ry', `${ry}deg`); };
      stage.onpointerup = stage.onpointercancel = () => { drag = null; rot.classList.remove('dragging'); };
      stage.turn = () => { ry += 180; rot.style.setProperty('--ry', `${ry}deg`); };
    }
    if (document.body.classList.contains('no-anim')) stage.querySelectorAll('svg').forEach(s => s.pauseAnimations?.());
  }

  window.SIGMA = { setAllFree, QUESTS, DAILY, STAR_REWARDS, setUnlocks, isLocked, auraRingSVG, spriteSVG, glowSVG, shoeBoxes, headBoxesFor, loadImageFile, photoPixels, PB_W, PB_H, THEMES, RARITY, COSMETICS, tile, buildStage, findItem, svgFor, plushBoxes, bandBoxes, helmetBoxes, chibiBoxes, petHeadTop, setCustom, resolve, SHAPES, ringSVG };
})();
