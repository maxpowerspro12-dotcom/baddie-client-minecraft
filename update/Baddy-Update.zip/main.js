const { app, BrowserWindow, ipcMain, dialog, shell, net } = require('electron');
const path = require('path');
const fs = require('fs');
const fsp = fs.promises;
const os = require('os');
const { execFile } = require('child_process');
const { Client } = require('minecraft-launcher-core');
const { Auth } = require('msmc');

const ROOT = path.join(app.getPath('appData'), '.sigmaclient');
const SETTINGS_FILE = path.join(ROOT, 'settings.json');
const RUNTIMES = path.join(ROOT, 'runtimes');
const CACHE = path.join(ROOT, 'cache');
const UA = 'SigmaClient/1.2.0 (Minecraft launcher)';
const MANIFEST_URL = 'https://piston-meta.mojang.com/mc/game/version_manifest_v2.json';
const CF_API = 'https://api.curseforge.com/v1';
const CF_GAME = 432, CF_CLASS_MODS = 6, CF_FABRIC = 4;

const DEFAULT_SETTINGS = {
  ram: 4, javaMode: 'auto', javaPath: '', lastVersion: null, lastLoader: 'fabric', account: null,
  appearance: {}, cosmetics: {}, width: 1280, height: 720, fullscreen: false, jvmArgs: '',
  onLaunch: 'open', showSnapshots: false, cfKey: '', modSource: 'modrinth', perfJvm: true
};
const SETTABLE = ['ram', 'javaMode', 'javaPath', 'lastVersion', 'lastLoader', 'width', 'height', 'fullscreen',
  'jvmArgs', 'onLaunch', 'showSnapshots', 'cfKey', 'modSource', 'perfJvm', 'secretUnlock'];

let win;
let cachedAuth = null;
let gameRunning = false;

// ---------- Hilfsfunktionen ----------
async function readJSON(file, fallback) {
  for (const f of [file, file + '.bak']) {
    try { return JSON.parse(await fsp.readFile(f, 'utf8')); } catch { }
  }
  return fallback;
}
// Sicher schreiben: erst in eine Temp-Datei, dann umbenennen (kein halb geschriebenes JSON bei Absturz/Herunterfahren)
async function writeJSON(file, data) {
  await fsp.mkdir(path.dirname(file), { recursive: true });
  const tmp = file + '.tmp';
  await fsp.writeFile(tmp, JSON.stringify(data, null, 2));
  try { await fsp.copyFile(file, file + '.bak'); } catch { }
  await fsp.rename(tmp, file);
}
// Netzwerk über Chromium (nutzt Windows-Zertifikate und Proxy-Einstellungen)
async function request(url, headers = {}) {
  let res;
  try { res = await net.fetch(url, { headers: { 'User-Agent': UA, ...headers } }); }
  catch (e) { throw new Error(`Keine Verbindung zu ${new URL(url).host} (${e.message})`); }
  return res;
}
async function getJSON(url, headers) {
  const res = await request(url, headers);
  if (res.status === 403 && url.startsWith(CF_API)) throw new Error('CurseForge-API-Schlüssel ungültig');
  if (!res.ok) throw new Error(`${new URL(url).host} antwortet mit Fehler ${res.status}`);
  return res.json();
}
async function download(url, dest, label) {
  const res = await request(url);
  if (!res.ok) throw new Error(`Download fehlgeschlagen (${res.status})`);
  await fsp.mkdir(path.dirname(dest), { recursive: true });
  const total = Number(res.headers.get('content-length')) || 0;
  const tmp = dest + '.part';
  const out = fs.createWriteStream(tmp);
  const reader = res.body.getReader();
  let got = 0, last = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!out.write(Buffer.from(value))) await new Promise(r => out.once('drain', r));
      got += value.length;
      if (label && total && Date.now() - last > 150) {
        last = Date.now();
        send('launch:progress', { type: label, task: Math.round(got / 1048576), total: Math.round(total / 1048576) });
      }
    }
  } finally { await new Promise(r => out.end(r)); }
  await fsp.rename(tmp, dest);
}
// Das Microsoft-Konto liegt in einer eigenen Datei, damit normale Einstellungen es nie überschreiben können
const ACCOUNT_FILE = path.join(ROOT, 'account.json');
let settingsCache = null, accountCache;
let saveQueue = Promise.resolve();
async function loadAccount() {
  if (accountCache === undefined) {
    accountCache = await readJSON(ACCOUNT_FILE, null);
    if (!accountCache) {
      // Umzug aus älteren Versionen (Konto stand in settings.json)
      const old = (await readJSON(SETTINGS_FILE, {})).account;
      accountCache = old || null;
      if (old) await writeJSON(ACCOUNT_FILE, old);
    }
  }
  return accountCache;
}
async function readSettings() {
  if (!settingsCache) {
    const raw = await readJSON(SETTINGS_FILE, {});
    delete raw.account;
    settingsCache = { ...DEFAULT_SETTINGS, ...raw };
  }
  return { ...settingsCache, account: await loadAccount() };
}
// Alle Speichervorgänge nacheinander (vorher konnten sich zwei gleichzeitige gegenseitig überschreiben)
function saveSettings(patch) {
  const job = saveQueue.then(async () => {
    await readSettings();
    if ('account' in patch) {
      accountCache = patch.account || null;
      if (accountCache) await writeJSON(ACCOUNT_FILE, accountCache);
      else { await fsp.rm(ACCOUNT_FILE, { force: true }); await fsp.rm(ACCOUNT_FILE + '.bak', { force: true }); }
    }
    const { account, ...rest } = patch;
    settingsCache = { ...settingsCache, ...rest };
    const { account: _a, ...toWrite } = settingsCache;
    await writeJSON(SETTINGS_FILE, toWrite);
    return { ...settingsCache, account: accountCache };
  });
  saveQueue = job.catch(() => { });
  return job;
}
function safeName(file) {
  if (typeof file !== 'string' || path.basename(file) !== file) throw new Error('Ungültiger Dateiname');
  return file;
}
function run(cmd, args) {
  return new Promise((res, rej) => execFile(cmd, args, { windowsHide: true }, (e, out, err) => e ? rej(new Error(err || e.message)) : res(out)));
}
const instanceDir = (mc, loader) => path.join(ROOT, 'instances', `${mc}-${loader}`);
const modsDir = (mc, loader) => path.join(instanceDir(mc, loader), 'mods');
const metaFile = (mc, loader) => path.join(instanceDir(mc, loader), 'sigma-mods.json');
const send = (ch, data) => { if (win && !win.isDestroyed()) win.webContents.send(ch, data); };

// ---------- Fenster ----------
function createWindow() {
  win = new BrowserWindow({
    width: 1240, height: 780, minWidth: 980, minHeight: 620,
    frame: false, backgroundColor: '#0b0c10', title: 'Baddy Client', icon: path.join(__dirname, 'src', 'icon.ico'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: false }
  });
  const wc = win.webContents;
  wc.on('preload-error', (_, file, err) => {
    dialog.showErrorBox('Baddy Client – Fehler beim Laden', `${path.basename(file)}:\n${err?.stack || err}`);
  });
  wc.on('render-process-gone', (_, d) => dialog.showErrorBox('Baddy Client – Absturz', `Das Fenster ist abgestürzt (${d.reason}).`));
  wc.on('before-input-event', (_, input) => {
    if (input.type === 'keyDown' && input.key === 'F12') wc.toggleDevTools();
  });
  win.loadFile(path.join(__dirname, 'src', 'index.html'));
}
process.on('uncaughtException', (e) => dialog.showErrorBox('Baddy Client – Fehler', e?.stack || String(e)));
app.whenReady().then(async () => {
  app.setAppUserModelId('de.sigmaclient.launcher');
  // Auch die Microsoft-Anmeldung (msmc) über Chromium-Netzwerk laufen lassen:
  // nutzt Windows-Zertifikate, funktioniert also auch mit Antivirus-Webschutz
  globalThis.fetch = (input, init) => net.fetch(input, init);
  await fsp.mkdir(ROOT, { recursive: true });
  createWindow();
});
app.on('window-all-closed', () => app.quit());

ipcMain.handle('win:minimize', () => win.minimize());
ipcMain.handle('win:close', () => win.close());
ipcMain.handle('app:openFolder', async (_, which) => {
  const dir = which === 'runtimes' ? RUNTIMES : ROOT;
  await fsp.mkdir(dir, { recursive: true });
  shell.openPath(dir);
});
ipcMain.handle('app:openExternal', (_, url) => {
  if (typeof url === 'string' && /^https:\/\//.test(url)) shell.openExternal(url);
});
// ---------- Kleine Updates direkt von GitHub (ohne Neuinstallation) ----------
// Im Repository liegt ein Ordner "update" mit update.json + Baddy-Update.zip.
const PKG = require('./package.json');
const UPDATE_BASE = PKG.baddy?.github ? `https://raw.githubusercontent.com/${PKG.baddy.github}/${PKG.baddy.branch || 'main'}/update/` : null;
function newerVersion(a, b) {
  const pa = String(a).split('.').map(n => parseInt(n, 10) || 0), pb = String(b).split('.').map(n => parseInt(n, 10) || 0);
  for (let i = 0; i < 3; i++) { if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0); }
  return false;
}
ipcMain.handle('update:check', async () => {
  if (!UPDATE_BASE) return null;
  try {
    const r = await net.fetch(UPDATE_BASE + 'update.json?t=' + Date.now(), { cache: 'no-store' });
    if (!r.ok) return null;
    const j = await r.json();
    return j && j.version && newerVersion(j.version, app.getVersion()) ? { version: j.version, notes: String(j.notes || '').slice(0, 600) } : null;
  } catch { return null; }
});
ipcMain.handle('update:install', async () => {
  if (!UPDATE_BASE) throw new Error('Keine Update-Adresse eingestellt');
  const tmp = path.join(app.getPath('temp'), 'baddy-update');
  await fsp.rm(tmp, { recursive: true, force: true });
  await fsp.mkdir(tmp, { recursive: true });
  const zip = path.join(tmp, 'update.zip');
  const r = await net.fetch(UPDATE_BASE + 'Baddy-Update.zip?t=' + Date.now(), { cache: 'no-store' });
  if (!r.ok) throw new Error(`Update konnte nicht geladen werden (${r.status})`);
  await fsp.writeFile(zip, Buffer.from(await r.arrayBuffer()));
  const out = path.join(tmp, 'files');
  await run('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', `Expand-Archive -LiteralPath '${zip.replace(/'/g, "''")}' -DestinationPath '${out.replace(/'/g, "''")}' -Force`]);
  if (!fs.existsSync(path.join(out, 'main.js')) || !fs.existsSync(path.join(out, 'package.json'))) throw new Error('Das Update-Paket ist unvollständig');
  // neue Programmdateien über die alten kopieren (Konto, Einstellungen, Mods und Welten bleiben unberührt)
  await fsp.cp(out, __dirname, { recursive: true, force: true });
  setTimeout(() => { app.relaunch(); app.exit(0); }, 400);
  return true;
});

ipcMain.handle('app:info', () => ({
  version: app.getVersion(), electron: process.versions.electron,
  totalRam: Math.max(2, Math.floor(os.totalmem() / 1073741824)), root: ROOT
}));
ipcMain.handle('app:diagnose', async () => {
  const s = await readSettings();
  const checks = [
    ['Minecraft-Versionen (Mojang)', MANIFEST_URL],
    ['Fabric', 'https://meta.fabricmc.net/v2/versions/loader'],
    ['Modrinth', 'https://api.modrinth.com/v2/tag/loader'],
    ['Java-Downloads (Adoptium)', 'https://api.adoptium.net/v3/info/available_releases'],
    ['Microsoft-Login', 'https://login.live.com/']
  ];
  if (s.cfKey) checks.push(['CurseForge', `${CF_API}/games/${CF_GAME}`, { 'x-api-key': s.cfKey }]);
  return Promise.all(checks.map(async ([name, url, headers]) => {
    const t = Date.now();
    try {
      const res = await request(url, headers);
      if (res.status === 403 && headers) throw new Error('API-Schlüssel ungültig');
      if (res.status >= 500) throw new Error(`Serverfehler ${res.status}`);
      return { name, ok: true, ms: Date.now() - t };
    } catch (e) { return { name, ok: false, error: e.message }; }
  }));
});

// ---------- Einstellungen ----------
ipcMain.handle('settings:get', async () => {
  const { account, ...rest } = await readSettings();
  return rest;
});
ipcMain.handle('settings:set', async (_, patch) => {
  const allowed = {};
  for (const k of SETTABLE) if (k in patch) allowed[k] = patch[k];
  for (const k of ['appearance', 'cosmetics', 'themeColors', 'cosmeticsCustom', 'menu']) {
    if (patch[k] && typeof patch[k] === 'object' && !Array.isArray(patch[k])) allowed[k] = patch[k];
  }
  await saveSettings(allowed);
});
ipcMain.handle('settings:browseJava', async () => {
  const r = await dialog.showOpenDialog(win, {
    title: 'java.exe auswählen', properties: ['openFile'],
    filters: [{ name: 'Java', extensions: ['exe'] }]
  });
  if (r.canceled || !r.filePaths[0]) return null;
  await saveSettings({ javaPath: r.filePaths[0], javaMode: 'custom' });
  return r.filePaths[0];
});

// ---------- Versionen ----------
async function loadManifest() {
  const file = path.join(CACHE, 'manifest.json');
  try {
    const m = await getJSON(MANIFEST_URL);
    await writeJSON(file, m);
    return m;
  } catch (e) {
    const cached = await readJSON(file, null);
    if (cached) return cached;
    throw e;
  }
}
ipcMain.handle('versions:list', async () => {
  const manifest = await loadManifest();
  const file = path.join(CACHE, 'fabric-games.json');
  let fabric = null;
  try {
    fabric = (await getJSON('https://meta.fabricmc.net/v2/versions/game')).map(v => v.version);
    await writeJSON(file, fabric);
  } catch { fabric = await readJSON(file, null); }
  return {
    versions: manifest.versions.map(v => ({ id: v.id, type: v.type })),
    latest: manifest.latest,
    fabric: fabric || [],
    fabricOk: !!fabric
  };
});
async function versionInfo(mc) {
  const file = path.join(ROOT, 'versions', mc, `${mc}.json`);
  const local = await readJSON(file, null);
  if (local) return local;
  const v = (await loadManifest()).versions.find(x => x.id === mc);
  if (!v) throw new Error(`Minecraft ${mc} gibt es nicht`);
  const json = await getJSON(v.url);
  await writeJSON(file, json);
  return json;
}

// ---------- Java automatisch ----------
async function findJava(dir) {
  for (const e of await fsp.readdir(dir, { withFileTypes: true }).catch(() => [])) {
    if (!e.isDirectory()) continue;
    const p = path.join(dir, e.name, 'bin', 'javaw.exe');
    if (fs.existsSync(p)) return p;
  }
  return null;
}
async function ensureJava(major) {
  const dir = path.join(RUNTIMES, `java-${major}`);
  const have = await findJava(dir);
  if (have) return have;
  const arch = process.arch === 'arm64' ? 'aarch64' : 'x64';
  const zip = path.join(RUNTIMES, `java-${major}.zip`);
  send('launch:log', `[Java] Lade Java ${major} herunter…\n`);
  let ok = false, lastErr;
  for (const kind of ['jre', 'jdk']) {
    try {
      await download(`https://api.adoptium.net/v3/binary/latest/${major}/ga/windows/${arch}/${kind}/hotspot/normal/eclipse`, zip, `Java ${major} (MB)`);
      ok = true; break;
    } catch (e) { lastErr = e; }
  }
  if (!ok) throw new Error(`Java ${major} konnte nicht heruntergeladen werden: ${lastErr.message}`);
  send('launch:progress', { type: `Java ${major} entpacken`, task: 0, total: 0 });
  await fsp.rm(dir, { recursive: true, force: true });
  await fsp.mkdir(dir, { recursive: true });
  try { await run('tar', ['-xf', zip, '-C', dir]); }
  catch {
    await run('powershell', ['-NoProfile', '-Command', `Expand-Archive -LiteralPath '${zip}' -DestinationPath '${dir}' -Force`]);
  }
  await fsp.rm(zip, { force: true });
  const p = await findJava(dir);
  if (!p) throw new Error('Java-Installation unvollständig');
  send('launch:log', `[Java] Java ${major} bereit: ${p}\n`);
  return p;
}

// ---------- Microsoft-Login ----------
ipcMain.handle('auth:status', async () => {
  const s = await readSettings();
  return s.account ? { name: s.account.name, uuid: s.account.uuid } : null;
});
ipcMain.handle('auth:login', async () => {
  const xbox = await new Auth('select_account').launch('electron');
  const mc = await xbox.getMinecraft();
  if (!mc.profile) throw new Error('Dieses Konto besitzt kein Minecraft: Java Edition');
  cachedAuth = mc.mclc();
  cachedAt = Date.now();
  await saveSettings({ account: { refresh: xbox.save(), name: mc.profile.name, uuid: mc.profile.id } });
  return { name: mc.profile.name, uuid: mc.profile.id };
});
ipcMain.handle('auth:logout', async () => {
  cachedAuth = null;
  await saveSettings({ account: null });
});
let cachedAt = 0, authInFlight = null;
// Nie zwei Erneuerungen gleichzeitig (der alte Refresh-Token wird dabei ungültig -> sonst Abmeldung)
function getAuth() {
  if (cachedAuth && Date.now() - cachedAt < 12 * 3600 * 1000) return Promise.resolve(cachedAuth);
  if (!authInFlight) authInFlight = getAuthInner().finally(() => { authInFlight = null; });
  return authInFlight;
}
async function getAuthInner() {
  // Minecraft-Zugang gilt 24 h – nach 12 h sicherheitshalber erneuern
  if (cachedAuth && Date.now() - cachedAt < 12 * 3600 * 1000) return cachedAuth;
  const s = await readSettings();
  if (!s.account?.refresh) throw new Error('Bitte zuerst mit Microsoft anmelden');
  let lastErr;
  for (let i = 0; i < 2; i++) {
    try {
      const xbox = await new Auth('select_account').refresh(s.account.refresh);
      const mc = await xbox.getMinecraft();
      cachedAuth = mc.mclc();
      cachedAt = Date.now();
      await saveSettings({ account: { ...s.account, refresh: xbox.save(), name: mc.profile?.name || s.account.name } });
      return cachedAuth;
    } catch (e) { lastErr = e; }
  }
  const msg = String(lastErr?.message || lastErr?.ts || lastErr || '');
  send('launch:log', `[Login] Erneuern fehlgeschlagen: ${msg}\n`);
  // Nur bei wirklich ungültiger Anmeldung abmelden (Microsoft sagt "invalid_grant") – sonst bleibt das Konto gespeichert
  if (/invalid_grant|AADSTS70000|AADSTS70008|token.*revoked/i.test(msg)) {
    await saveSettings({ account: null });
    send('auth:expired');
    throw new Error('Deine Microsoft-Anmeldung ist abgelaufen – bitte neu anmelden');
  }
  throw new Error('Microsoft-Anmeldung konnte gerade nicht erneuert werden. Prüf dein Internet und versuch es nochmal – dein Konto bleibt gespeichert.');
}

// ---------- Quests: Fortschritt aus allen Spiel-Ordnern zusammenführen ----------
ipcMain.handle('quests:get', async () => {
  const out = { stats: {}, done: [], stars: 0, daily: null };
  const dirs = await fsp.readdir(path.join(ROOT, 'instances')).catch(() => []);
  for (const d of dirs) {
    const q = await readJSON(path.join(ROOT, 'instances', d, 'config', 'sigma-quests.json'), null);
    if (!q) continue;
    for (const [k, v] of Object.entries(q.stats || {})) out.stats[k] = Math.max(out.stats[k] || 0, Number(v) || 0);
    for (const id of q.done || []) if (!out.done.includes(id)) out.done.push(id);
    out.stars = Math.max(out.stars, Number(q.stars) || 0);
    if (q.daily && (!out.daily || String(q.daily.date) > String(out.daily.date))) out.daily = q.daily;
  }
  return out;
});

// ---------- Installierte Mods ----------
ipcMain.handle('mods:list', async (_, mc, loader) => {
  const dir = modsDir(mc, loader);
  await fsp.mkdir(dir, { recursive: true });
  const meta = await readJSON(metaFile(mc, loader), {});
  const files = (await fsp.readdir(dir)).filter(f => /\.jar(\.disabled)?$/i.test(f));
  return files.map(f => {
    const base = f.replace(/\.disabled$/i, '');
    const m = meta[base] || {};
    return {
      file: f, enabled: !/\.disabled$/i.test(f),
      title: m.title || base.replace(/\.jar$/i, ''), icon: m.icon || null,
      projectId: m.projectId || null, source: m.source || (m.projectId ? 'modrinth' : 'file')
    };
  }).sort((a, b) => a.title.localeCompare(b.title));
});
ipcMain.handle('mods:toggle', async (_, mc, loader, file) => {
  safeName(file);
  const dir = modsDir(mc, loader);
  const target = /\.disabled$/i.test(file) ? file.replace(/\.disabled$/i, '') : file + '.disabled';
  await fsp.rename(path.join(dir, file), path.join(dir, target));
});
ipcMain.handle('mods:delete', async (_, mc, loader, file) => {
  safeName(file);
  await fsp.unlink(path.join(modsDir(mc, loader), file));
  const mf = metaFile(mc, loader);
  const meta = await readJSON(mf, {});
  delete meta[file.replace(/\.disabled$/i, '')];
  await writeJSON(mf, meta);
});
async function addPaths(mc, loader, paths) {
  const dir = modsDir(mc, loader);
  await fsp.mkdir(dir, { recursive: true });
  let n = 0;
  for (const p of paths) {
    if (!/\.jar$/i.test(p)) continue;
    await fsp.copyFile(p, path.join(dir, path.basename(p)));
    n++;
  }
  return n;
}
ipcMain.handle('mods:addPaths', (_, mc, loader, paths) => addPaths(mc, loader, paths));
ipcMain.handle('mods:addFiles', async (_, mc, loader) => {
  const r = await dialog.showOpenDialog(win, {
    title: 'Mods hinzufügen', properties: ['openFile', 'multiSelections'],
    filters: [{ name: 'Minecraft-Mods', extensions: ['jar'] }]
  });
  if (r.canceled) return 0;
  return addPaths(mc, loader, r.filePaths);
});
ipcMain.handle('mods:openFolder', async (_, mc, loader) => {
  const dir = modsDir(mc, loader);
  await fsp.mkdir(dir, { recursive: true });
  shell.openPath(dir);
});
async function rememberMod(mc, loader, fileName, info) {
  const mf = metaFile(mc, loader);
  const meta = await readJSON(mf, {});
  meta[fileName] = info;
  await writeJSON(mf, meta);
}
async function alreadyInstalled(mc, loader, projectId) {
  return Object.values(await readJSON(metaFile(mc, loader), {})).some(m => m.projectId === projectId);
}

// ---------- Mod-Browser: Modrinth ----------
const MR_SORT = { relevance: 'relevance', downloads: 'downloads', newest: 'newest', updated: 'updated' };
async function modrinthSearch({ query, mc, category, sort, offset }) {
  const facets = [[`categories:fabric`], [`versions:${mc}`], ['project_type:mod'], ['client_side:required', 'client_side:optional']];
  if (category) facets.push([`categories:${category}`]);
  const params = new URLSearchParams({
    query: query || '', facets: JSON.stringify(facets), limit: '30', offset: String(offset || 0),
    index: MR_SORT[sort] || (query ? 'relevance' : 'downloads')
  });
  const r = await getJSON(`https://api.modrinth.com/v2/search?${params}`);
  return {
    total: r.total_hits,
    hits: r.hits.map(h => ({
      source: 'modrinth', id: h.project_id, title: h.title, description: h.description, icon: h.icon_url,
      downloads: h.downloads, author: h.author, url: `https://modrinth.com/mod/${h.slug}`, canInstall: true
    }))
  };
}
async function installFromModrinth(projectId, mc, loader, seen) {
  if (seen.has(projectId)) return [];
  seen.add(projectId);
  if (await alreadyInstalled(mc, loader, projectId)) return [];
  const q = `loaders=${encodeURIComponent(JSON.stringify([loader]))}&game_versions=${encodeURIComponent(JSON.stringify([mc]))}`;
  const versions = await getJSON(`https://api.modrinth.com/v2/project/${encodeURIComponent(projectId)}/version?${q}`);
  if (!versions.length) throw new Error(`Keine Version für Minecraft ${mc} verfügbar`);
  const v = versions.find(x => x.version_type === 'release') || versions[0];
  const file = v.files.find(f => f.primary) || v.files[0];
  const project = await getJSON(`https://api.modrinth.com/v2/project/${encodeURIComponent(projectId)}`);
  const fileName = path.basename(file.filename);
  await download(file.url, path.join(modsDir(mc, loader), fileName));
  await rememberMod(mc, loader, fileName, { source: 'modrinth', projectId, title: project.title, icon: project.icon_url });

  const installed = [project.title];
  for (const d of v.dependencies || []) {
    if (d.dependency_type === 'required' && d.project_id) {
      try { installed.push(...await installFromModrinth(d.project_id, mc, loader, seen)); }
      catch (e) { send('launch:log', `[Mods] Abhängigkeit ${d.project_id} übersprungen: ${e.message}\n`); }
    }
  }
  return installed;
}

// ---------- Mod-Browser: CurseForge ----------
async function cf(pathAndQuery) {
  const s = await readSettings();
  if (!s.cfKey) throw new Error('CF_NO_KEY');
  return getJSON(CF_API + pathAndQuery, { 'x-api-key': s.cfKey, Accept: 'application/json' });
}
const CF_SORT = { relevance: 2, downloads: 6, newest: 11, updated: 3 };
async function curseforgeSearch({ query, mc, category, sort, offset }) {
  const p = new URLSearchParams({
    gameId: CF_GAME, classId: CF_CLASS_MODS, gameVersion: mc, modLoaderType: CF_FABRIC,
    sortField: CF_SORT[sort] || 2, sortOrder: 'desc', pageSize: 30, index: offset || 0
  });
  if (query) p.set('searchFilter', query);
  if (category) p.set('categoryId', category);
  const r = await cf(`/mods/search?${p}`);
  return {
    total: Math.min(r.pagination?.totalCount || 0, 10000),
    hits: r.data.map(m => ({
      source: 'curseforge', id: String(m.id), title: m.name, description: m.summary,
      icon: m.logo?.thumbnailUrl || m.logo?.url || null, downloads: m.downloadCount,
      author: m.authors?.[0]?.name || '', url: m.links?.websiteUrl || `https://www.curseforge.com/minecraft/mc-mods/${m.slug}`,
      canInstall: m.allowModDistribution !== false
    }))
  };
}
async function installFromCurseForge(modId, mc, loader, seen) {
  const key = `cf:${modId}`;
  if (seen.has(key)) return [];
  seen.add(key);
  if (await alreadyInstalled(mc, loader, key)) return [];
  const files = (await cf(`/mods/${encodeURIComponent(modId)}/files?gameVersion=${encodeURIComponent(mc)}&modLoaderType=${CF_FABRIC}&pageSize=50`)).data;
  if (!files.length) throw new Error(`Keine Version für Minecraft ${mc} verfügbar`);
  const f = files.find(x => x.releaseType === 1) || files[0];
  const mod = (await cf(`/mods/${encodeURIComponent(modId)}`)).data;
  if (!f.downloadUrl) throw new Error(`${mod.name}: Der Autor erlaubt keine Downloads über andere Launcher`);
  const fileName = path.basename(f.fileName);
  await download(f.downloadUrl, path.join(modsDir(mc, loader), fileName));
  await rememberMod(mc, loader, fileName, { source: 'curseforge', projectId: key, title: mod.name, icon: mod.logo?.thumbnailUrl || null });

  const installed = [mod.name];
  for (const d of f.dependencies || []) {
    if (d.relationType === 3) {
      try { installed.push(...await installFromCurseForge(String(d.modId), mc, loader, seen)); }
      catch (e) { send('launch:log', `[Mods] Abhängigkeit ${d.modId} übersprungen: ${e.message}\n`); }
    }
  }
  return installed;
}

// ---------- Mod-Browser: Schnittstelle ----------
const categoryCache = {};
const MR_CAT_DE = {
  adventure: 'Abenteuer', cursed: 'Verflucht', decoration: 'Deko', economy: 'Wirtschaft', equipment: 'Ausrüstung',
  food: 'Essen', 'game-mechanics': 'Spielmechanik', library: 'Bibliothek', magic: 'Magie', management: 'Verwaltung',
  minigame: 'Minispiele', mobs: 'Mobs', optimization: 'Performance', social: 'Sozial', storage: 'Lager',
  technology: 'Technik', transportation: 'Transport', utility: 'Nützliches', worldgen: 'Weltgenerierung'
};
ipcMain.handle('browse:categories', async (_, source) => {
  if (categoryCache[source]) return categoryCache[source];
  let list;
  if (source === 'curseforge') {
    const r = await cf(`/categories?gameId=${CF_GAME}&classId=${CF_CLASS_MODS}`);
    list = r.data.filter(c => !c.isClass).map(c => ({ id: String(c.id), name: c.name }));
  } else {
    const r = await getJSON('https://api.modrinth.com/v2/tag/category');
    list = r.filter(c => c.project_type === 'mod' && c.header === 'categories')
      .map(c => ({ id: c.name, name: MR_CAT_DE[c.name] || c.name[0].toUpperCase() + c.name.slice(1) }));
  }
  list.sort((a, b) => a.name.localeCompare(b.name));
  return (categoryCache[source] = list);
});
ipcMain.handle('browse:search', async (_, opts) => {
  if (opts.loader !== 'fabric') throw new Error('Mods brauchen den Fabric-Loader – wähle unter „Spielen" Fabric aus');
  return opts.source === 'curseforge' ? curseforgeSearch(opts) : modrinthSearch(opts);
});
ipcMain.handle('browse:install', async (_, { source, id, mc, loader }) => {
  if (loader !== 'fabric') throw new Error('Mods brauchen den Fabric-Loader');
  return source === 'curseforge'
    ? installFromCurseForge(String(id), mc, loader, new Set())
    : installFromModrinth(id, mc, loader, new Set());
});

// ---------- Skin des Kontos ----------
ipcMain.handle('skin:get', async () => {
  const s = await readSettings();
  const uuid = s.account?.uuid;
  if (!uuid) return null;
  const cacheFile = path.join(CACHE, `skin-${uuid}.json`);
  try {
    const prof = await getJSON(`https://sessionserver.mojang.com/session/minecraft/profile/${encodeURIComponent(uuid)}`);
    const prop = (prof.properties || []).find(p => p.name === 'textures');
    const tex = prop ? JSON.parse(Buffer.from(prop.value, 'base64').toString('utf8')) : {};
    const skin = tex.textures?.SKIN;
    if (!skin?.url) { await writeJSON(cacheFile, null); return null; }
    const res = await request(skin.url.replace(/^http:/, 'https:'));
    if (!res.ok) throw new Error('Skin-Download fehlgeschlagen');
    const out = { data: 'data:image/png;base64,' + Buffer.from(await res.arrayBuffer()).toString('base64'), slim: skin.metadata?.model === 'slim' };
    await writeJSON(cacheFile, out);
    return out;
  } catch {
    return readJSON(cacheFile, null);
  }
});

// ---------- Import aus Lunar / Minecraft ----------
async function listJars(dir, depth = 1) {
  const out = [];
  for (const e of await fsp.readdir(dir, { withFileTypes: true }).catch(() => [])) {
    const p = path.join(dir, e.name);
    if (e.isFile() && /\.jar$/i.test(e.name)) out.push({ file: e.name, path: p });
    else if (e.isDirectory() && depth > 0) out.push(...await listJars(p, depth - 1));
  }
  return out;
}
const countEntries = async (dir) => (await fsp.readdir(dir).catch(() => [])).length;
async function describeSource(dir, label) {
  const info = {
    label, path: dir,
    options: fs.existsSync(path.join(dir, 'options.txt')),
    servers: fs.existsSync(path.join(dir, 'servers.dat')),
    resourcepacks: await countEntries(path.join(dir, 'resourcepacks')),
    shaderpacks: await countEntries(path.join(dir, 'shaderpacks')),
    saves: (await fsp.readdir(path.join(dir, 'saves'), { withFileTypes: true }).catch(() => []))
      .filter(e => e.isDirectory()).map(e => e.name),
    mods: await listJars(path.join(dir, 'mods'))
  };
  const any = info.options || info.servers || info.resourcepacks || info.shaderpacks || info.saves.length || info.mods.length;
  return any ? info : null;
}
const SKIP_DIRS = new Set(['assets', 'libraries', 'natives', 'jre', 'logs', 'cache', 'licenses', 'textures', 'crash-reports', 'screenshots', 'saves', 'resourcepacks', 'shaderpacks', 'mods', 'config']);
async function findGameDirs(base, depth, out) {
  if (depth < 0 || out.length >= 25) return;
  for (const e of await fsp.readdir(base, { withFileTypes: true }).catch(() => [])) {
    if (!e.isDirectory() || SKIP_DIRS.has(e.name.toLowerCase())) continue;
    const p = path.join(base, e.name);
    if (['options.txt', 'servers.dat', 'mods', 'saves'].some(f => fs.existsSync(path.join(p, f)))) out.push(p);
    await findGameDirs(p, depth - 1, out);
  }
}
ipcMain.handle('import:scan', async () => {
  const sources = [];
  const mcDir = path.join(app.getPath('appData'), '.minecraft');
  const main = await describeSource(mcDir, 'Minecraft / Lunar (.minecraft)');
  if (main) sources.push(main);
  const lunarRoot = path.join(os.homedir(), '.lunarclient');
  const dirs = [];
  await findGameDirs(lunarRoot, 5, dirs);
  for (const d of dirs) {
    const s = await describeSource(d, `Lunar Client: ${path.relative(lunarRoot, d)}`);
    if (s) sources.push(s);
  }
  return sources;
});
ipcMain.handle('import:pick', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Ordner mit deinen Minecraft-Daten auswählen', properties: ['openDirectory'] });
  if (r.canceled || !r.filePaths[0]) return null;
  return (await describeSource(r.filePaths[0], r.filePaths[0])) || { error: 'In diesem Ordner wurde nichts zum Übernehmen gefunden.' };
});
ipcMain.handle('import:run', async (_, { source, mc, loader, what }) => {
  const st = await fsp.stat(source).catch(() => null);
  if (!st?.isDirectory()) throw new Error('Quellordner nicht gefunden');
  const dest = instanceDir(mc, loader);
  await fsp.mkdir(dest, { recursive: true });
  const done = [];
  const copyOne = async (name) => {
    const from = path.join(source, name), to = path.join(dest, name);
    if (!fs.existsSync(from)) return false;
    if (fs.existsSync(to)) await fsp.copyFile(to, to + '.vor-import');
    await fsp.copyFile(from, to);
    return true;
  };
  if (what.options && await copyOne('options.txt')) {
    for (const extra of ['optionsof.txt', 'optionsshaders.txt']) await copyOne(extra).catch(() => {});
    done.push('Einstellungen');
  }
  if (what.servers && await copyOne('servers.dat')) done.push('Serverliste');
  for (const [folder, label] of [['resourcepacks', 'Texturepacks'], ['shaderpacks', 'Shader']]) {
    const from = path.join(source, folder);
    if (what[folder] && fs.existsSync(from)) {
      await fsp.cp(from, path.join(dest, folder), { recursive: true, force: false, errorOnExist: false });
      done.push(label);
    }
  }
  let worlds = 0;
  for (const name of what.saves || []) {
    safeName(name);
    const from = path.join(source, 'saves', name);
    if (!fs.existsSync(from)) continue;
    let target = path.join(dest, 'saves', name), i = 2;
    while (fs.existsSync(target)) target = path.join(dest, 'saves', `${name} (${i++})`);
    await fsp.cp(from, target, { recursive: true });
    worlds++;
  }
  if (worlds) done.push(`${worlds} Welt${worlds > 1 ? 'en' : ''}`);
  const jars = (what.mods || []).filter(p => typeof p === 'string' && /\.jar$/i.test(p) && fs.existsSync(p));
  if (jars.length) done.push(`${await addPaths(mc, loader, jars)} Mod(s)`);
  return done;
});


// ---------- Mods vor dem Start prüfen ----------
// 1) Im Spiel (Baddy-Menü) zum Ausschalten markierte Mods
// 2) Mods, die nur in Feather oder Lunar laufen und das Spiel abstürzen lassen
const CLIENT_ONLY = [/^net\/digitalingot\/feather\//, /^com\/moonsworth\//, /^gg\/essential\/loader\/stage0\/EssentialSetupPreLaunch/];
async function jarEntries(file) {
  try { return (await run('tar', ['-tf', file])).split(/\r?\n/); } catch { return []; }
}
async function applyModChanges(mc, loader) {
  const dir = modsDir(mc, loader);
  const cfg = path.join(instanceDir(mc, loader), 'config', 'sigma-disabled-mods.json');
  const changes = await readJSON(cfg, null);
  const off = [];
  for (const f of changes?.disable || []) {
    try {
      safeName(f);
      if (fs.existsSync(path.join(dir, f))) { await fsp.rename(path.join(dir, f), path.join(dir, f + '.disabled')); off.push(f); }
    } catch { /* Datei fehlt oder ist gesperrt */ }
  }
  if (changes) await writeJSON(cfg, { disable: [] });

  const cacheFile = path.join(CACHE, 'jar-check.json');
  const cache = await readJSON(cacheFile, {});
  const bad = [];
  for (const f of (await fsp.readdir(dir).catch(() => [])).filter(n => /\.jar$/i.test(n))) {
    if (/^sigma-cosmetics|^fabric-api/i.test(f)) continue;
    const full = path.join(dir, f);
    const st = await fsp.stat(full);
    const key = `${f}:${st.size}:${st.mtimeMs}`;
    if (!(key in cache)) cache[key] = (await jarEntries(full)).some(e => CLIENT_ONLY.some(rx => rx.test(e)));
    if (cache[key]) {
      await fsp.rename(full, full + '.disabled');
      bad.push(f);
    }
  }
  await writeJSON(cacheFile, cache);
  if (off.length) send('launch:log', `[Mods] Im Spiel ausgeschaltet: ${off.join(', ')}\n`);
  if (bad.length) send('mods:autoDisabled', bad);
}

// ---------- Spiel starten ----------
// Mitgelieferte Baddy-Mod (aus dem Download-Paket) automatisch einsetzen + Fabric API laden.
// So brauchen Leute, die den Client von der Website laden, kein MOD-BAUEN.bat.
async function ensureBaddyMod(gameDir, mc) {
  const modsDir = path.join(gameDir, 'mods');
  await fsp.mkdir(modsDir, { recursive: true });
  const bundleDir = path.join(__dirname, 'mod');
  const bundled = (await fsp.readdir(bundleDir).catch(() => [])).find(f => /^sigma-cosmetics-.*\.jar$/i.test(f));
  const present = (await fsp.readdir(modsDir)).filter(f => /^sigma-cosmetics-.*\.jar(\.disabled)?$/i.test(f));
  if (bundled) {
    const src = path.join(bundleDir, bundled), dst = path.join(modsDir, bundled);
    const srcStat = await fsp.stat(src);
    const newer = !present.length || (await Promise.all(present.map(f => fsp.stat(path.join(modsDir, f))))).every(st => st.mtimeMs < srcStat.mtimeMs);
    if (newer) {
      for (const f of present) await fsp.rm(path.join(modsDir, f), { force: true });
      await fsp.copyFile(src, dst);
      send('launch:log', `[Baddy] Mod ${bundled} eingesetzt\n`);
    }
  }
  const files = await fsp.readdir(modsDir);
  if ((bundled || present.length) && !files.some(f => /^fabric-api.*\.jar$/i.test(f))) {
    send('launch:progress', { type: 'Fabric API', task: 0, total: 0 });
    const q = `game_versions=${encodeURIComponent(JSON.stringify([mc]))}&loaders=${encodeURIComponent('["fabric"]')}`;
    const vers = await getJSON(`https://api.modrinth.com/v2/project/fabric-api/version?${q}`);
    const file = vers?.[0]?.files?.find(f => f.primary) || vers?.[0]?.files?.[0];
    if (file) {
      const res = await net.fetch(file.url);
      if (!res.ok) throw new Error('Fabric API konnte nicht geladen werden');
      await fsp.writeFile(path.join(modsDir, file.filename), Buffer.from(await res.arrayBuffer()));
    }
  }
}

ipcMain.handle('game:launch', async (_, { mc, loader, extras = {} }) => {
  if (gameRunning) throw new Error('Minecraft läuft bereits');
  gameRunning = true;
  try {
    const auth = await getAuth();
    const s = await readSettings();
    send('launch:progress', { type: 'Versionsdaten', task: 0, total: 0 });
    const info = await versionInfo(mc);
    const version = { number: mc, type: info.type || 'release' };

    let javaPath;
    if (s.javaMode === 'custom' && s.javaPath) javaPath = s.javaPath;
    else if (s.javaMode !== 'system') javaPath = await ensureJava(info.javaVersion?.majorVersion || 8);

    if (loader === 'fabric') {
      send('launch:progress', { type: 'Fabric', task: 0, total: 0 });
      const loaders = await getJSON(`https://meta.fabricmc.net/v2/versions/loader/${encodeURIComponent(mc)}`);
      const pick = loaders.find(l => l.loader.stable) || loaders[0];
      if (!pick) throw new Error(`Fabric unterstützt Minecraft ${mc} (noch) nicht`);
      const id = `fabric-loader-${pick.loader.version}-${mc}`;
      const vjson = path.join(ROOT, 'versions', id, `${id}.json`);
      if (!fs.existsSync(vjson)) {
        await writeJSON(vjson, await getJSON(`https://meta.fabricmc.net/v2/versions/loader/${encodeURIComponent(mc)}/${encodeURIComponent(pick.loader.version)}/profile/json`));
      }
      version.custom = id;
    }

    const gameDir = instanceDir(mc, loader);
    await fsp.mkdir(gameDir, { recursive: true });
    if (mc === '1.21.11' && loader === 'fabric') await ensureBaddyMod(gameDir, mc);
    await applyModChanges(mc, loader);
    await writeJSON(path.join(gameDir, 'config', 'sigma-cosmetics.json'), {
      version: 1, player: s.account?.uuid || null, equipped: s.cosmetics || {}, theme: s.themeColors || null,
      headBoxes: Array.isArray(extras.headBoxes) ? extras.headBoxes : null, headGlow: !!extras.headGlow,
      helmBoxes: Array.isArray(extras.helmBoxes) ? extras.helmBoxes : null,
      feetBoxes: Array.isArray(extras.feetBoxes) ? extras.feetBoxes : null,
      headOrbitY: Number.isFinite(Number(extras.headOrbitY)) ? Number(extras.headOrbitY) : -4,
      wingFold: !!extras.wingFold, capeGlow: !!extras.capeGlow,
      auraFx: extras.auraFx && typeof extras.auraFx === 'object' ? extras.auraFx : null,
      quests: !!(s.quests ?? true),
      questDefs: Array.isArray(extras.questDefs) ? extras.questDefs.slice(0, 40) : [],
      dailyPool: Array.isArray(extras.dailyPool) ? extras.dailyPool.slice(0, 20) : [],
      menu: s.menu && typeof s.menu === 'object' ? s.menu : null,
      wingScale: Math.min(2.4, Math.max(0.6, Number(extras.wingScale) || 1)),
      petHeadTop: Number.isFinite(Number(extras.petHeadTop)) ? Number(extras.petHeadTop) : -8.05,
      petScale: Math.min(1.6, Math.max(0.5, (Number(s.cosmeticsCustom?.petScale) || 100) / 100)),
      petSpot: ['left', 'right', 'head'].includes(s.cosmeticsCustom?.petSpot) ? s.cosmeticsCustom.petSpot : 'left'
    });
    // Texturen der angelegten Flügel/Umhänge (inkl. selbst gestalteter) für die Mod ablegen
    const texDir = path.join(gameDir, 'config', 'sigma-tex');
    await fsp.rm(texDir, { recursive: true, force: true });
    await fsp.mkdir(texDir, { recursive: true });
    for (const [k, v] of Object.entries(extras.textures || {})) {
      if (!['wings', 'cape', 'aura_ring', 'aura_sprite', 'aura_glow'].includes(k) || typeof v !== 'string') continue;
      const m = v.match(/^data:image\/png;base64,(.+)$/);
      if (m) await fsp.writeFile(path.join(texDir, `${k}.png`), Buffer.from(m[1], 'base64'));
    }

    const launcher = new Client();
    let started = false;
    launcher.on('progress', e => send('launch:progress', e));
    launcher.on('download-status', e => send('launch:progress', { type: e.type, task: e.current, total: e.total }));
    launcher.on('debug', d => send('launch:log', `[Launcher] ${d}\n`));
    launcher.on('data', d => {
      if (!started) {
        started = true;
        send('launch:started');
        if (s.onLaunch === 'minimize') win.minimize();
        if (s.onLaunch === 'hide') win.hide();
      }
      send('launch:log', String(d));
    });
    launcher.on('close', code => {
      gameRunning = false;
      if (s.onLaunch === 'hide' && win && !win.isDestroyed()) win.show();
      send('launch:closed', code);
    });

    const ram = Math.max(1, Number(s.ram) || 4);
    const proc = await launcher.launch({
      authorization: auth,
      root: ROOT,
      version,
      memory: { max: `${ram}G`, min: `${Math.min(ram, 1)}G` },
      javaPath,
      // Windows-Zertifikate nutzen, damit Skins & Co. auch mit Antivirus-Webschutz laden
      customArgs: [
        ...(/trustStore/.test(s.jvmArgs || '') ? [] : ['-Djavax.net.ssl.trustStoreType=Windows-ROOT']),
        // Optimierte Speicherverwaltung (weniger Ruckler)
        ...(s.perfJvm && !/UseG1GC|UseZGC/.test(s.jvmArgs || '') ? ['-XX:+UseG1GC', '-XX:+ParallelRefProcEnabled', '-XX:MaxGCPauseMillis=200',
          '-XX:+UnlockExperimentalVMOptions', '-XX:+DisableExplicitGC', '-XX:G1NewSizePercent=30', '-XX:G1MaxNewSizePercent=40',
          '-XX:G1HeapRegionSize=8M', '-XX:G1ReservePercent=20', '-XX:+AlwaysPreTouch'] : []),
        ...String(s.jvmArgs || '').split(/\s+/).filter(Boolean)
      ],
      window: s.fullscreen ? { fullscreen: true } : { width: Number(s.width) || 1280, height: Number(s.height) || 720 },
      overrides: { gameDirectory: gameDir, detached: false }
    });
    if (!proc) throw new Error('Start fehlgeschlagen – siehe Spiel-Log');
    return true;
  } catch (e) {
    gameRunning = false;
    throw e;
  }
});
