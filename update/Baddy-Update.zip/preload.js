const { contextBridge, ipcRenderer, webUtils } = require('electron');

const inv = (ch) => (...args) => ipcRenderer.invoke(ch, ...args);

contextBridge.exposeInMainWorld('api', {
  win: { minimize: inv('win:minimize'), close: inv('win:close') },
  app: { info: inv('app:info'), diagnose: inv('app:diagnose'), openFolder: inv('app:openFolder'), openExternal: inv('app:openExternal') },
  settings: { get: inv('settings:get'), set: inv('settings:set'), browseJava: inv('settings:browseJava') },
  versions: { list: inv('versions:list') },
  auth: { status: inv('auth:status'), login: inv('auth:login'), logout: inv('auth:logout') },
  quests: { get: inv('quests:get') },
  update: { check: inv('update:check'), install: inv('update:install') },
  mods: {
    list: inv('mods:list'), toggle: inv('mods:toggle'), remove: inv('mods:delete'),
    addFiles: inv('mods:addFiles'), addPaths: inv('mods:addPaths'), openFolder: inv('mods:openFolder')
  },
  browse: { search: inv('browse:search'), categories: inv('browse:categories'), install: inv('browse:install') },
  game: { launch: inv('game:launch') },
  skin: { get: inv('skin:get') },
  importer: { scan: inv('import:scan'), pick: inv('import:pick'), run: inv('import:run') },
  pathForFile: (file) => webUtils.getPathForFile(file),
  on: (channel, cb) => {
    const allowed = ['launch:progress', 'launch:log', 'launch:started', 'launch:closed', 'auth:expired', 'mods:autoDisabled'];
    if (allowed.includes(channel)) ipcRenderer.on(channel, (_, data) => cb(data));
  }
});
