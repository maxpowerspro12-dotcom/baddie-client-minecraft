// Zeigt Fehler direkt im Fenster an, damit man sie sehen und melden kann
(() => {
  function show(msg) {
    let box = document.getElementById('fatal');
    if (!box) {
      box = document.createElement('div');
      box.id = 'fatal';
      box.style.cssText = 'position:fixed;left:16px;right:16px;bottom:16px;z-index:9999;background:#3b0d0d;color:#fff;' +
        'border:1px solid #ef4444;border-radius:10px;padding:12px 16px;font:13px/1.45 Consolas,monospace;' +
        'white-space:pre-wrap;user-select:text;max-height:40vh;overflow:auto;box-shadow:0 10px 30px rgba(0,0,0,.5)';
      const head = document.createElement('b');
      head.textContent = 'Fehler im Baddy Client – bitte Screenshot an Claude schicken:';
      head.style.display = 'block';
      box.appendChild(head);
      (document.body || document.documentElement).appendChild(box);
    }
    const line = document.createElement('div');
    line.textContent = '⚠ ' + msg;
    box.appendChild(line);
  }
  window.sigmaShowError = show;
  window.addEventListener('error', (e) => show(`${e.message} (${String(e.filename || '').split('/').pop()}:${e.lineno})`));
  window.addEventListener('unhandledrejection', (e) => show(String(e.reason?.message || e.reason)));
  window.addEventListener('DOMContentLoaded', () => {
    if (!window.api) show('Die Verbindung zum Launcher fehlt (preload.js wurde nicht geladen).');
  });
})();
