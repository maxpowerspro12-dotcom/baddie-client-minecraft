// "api" kommt aus preload.js (window.api) und darf hier nicht neu deklariert werden
const { THEMES, RARITY, COSMETICS, tile, buildStage, findItem, svgFor, bandBoxes, helmetBoxes, petHeadTop, setCustom } = window.SIGMA;
const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

const DEFAULT_LOOK = { theme: 'sigma', accent: null, bg: 'glow', radius: 'round', font: 'normal', anim: true, showSkin: true, style: 'solid', family: 'segoe', blur: 18 };
const DEFAULT_MENU = { layout: 'left', bg: 'panorama', glass: true, clock: true, tips: true, radius: 10 };
const FONTS = { segoe: '"Segoe UI", system-ui, sans-serif', variable: '"Segoe UI Variable Display", "Segoe UI", sans-serif', bahn: 'Bahnschrift, "Segoe UI", sans-serif', trebuchet: '"Trebuchet MS", "Segoe UI", sans-serif', verdana: 'Verdana, "Segoe UI", sans-serif', georgia: 'Georgia, serif', mono: 'Consolas, "Cascadia Mono", monospace', comic: '"Comic Sans MS", "Segoe UI", sans-serif' };
const state = {
  s: {}, info: {}, versions: null, account: null,
  look: { ...DEFAULT_LOOK }, cosmetics: {}, cosTab: 'wings', cosView: 'front', skin: null, imports: []
};
const browser = {
  source: 'modrinth', offset: 0, total: 0, hits: [], selected: new Map(), installed: new Set(),
  busy: false, timer: null, reqId: 0
};

// ---------- Hilfen ----------
function toast(msg, type = '') {
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.textContent = msg;
  $('#toasts').appendChild(t);
  setTimeout(() => t.remove(), 5000);
}
const errMsg = (e) => {
  const m = String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
  return m === 'CF_NO_KEY' ? 'Für CurseForge brauchst du einen API-Schlüssel (Einstellungen → Mods)' : m;
};
const current = () => ({ mc: $('#version').value, loader: $('#loader').value });
const fmt = (n) => n >= 1e6 ? (n / 1e6).toFixed(1).replace('.', ',') + ' Mio.' : n >= 1e3 ? Math.round(n / 1e3) + 'k' : String(n);
function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}
function iconEl(url, title) {
  if (url) { const i = document.createElement('img'); i.src = url; i.alt = ''; i.loading = 'lazy'; return i; }
  return el('div', 'ph', (title || '?')[0].toUpperCase());
}
const SOURCE_NAME = { modrinth: 'Modrinth', curseforge: 'CurseForge', file: 'Datei' };

// ---------- Fenster & Navigation ----------
$('#btn-min').onclick = () => api.win.minimize();
$('#btn-close').onclick = () => api.win.close();
function showPage(name) {
  $$('.nav-item').forEach(x => x.classList.toggle('active', x.dataset.page === name));
  $$('.page').forEach(p => p.classList.toggle('active', p.id === `page-${name}`));
  if (name === 'mods') refreshMods();
  if (name === 'cosmetics') renderCosmetics();
  if (name === 'quests') loadQuests();
}
$$('.nav-item').forEach(b => b.onclick = () => showPage(b.dataset.page));
$('#goto-cosmetics').onclick = () => showPage('cosmetics');
function showSettings(tab) {
  $$('.set-tab').forEach(x => x.classList.toggle('active', x.dataset.set === tab));
  $$('.set-panel').forEach(p => p.classList.toggle('active', p.id === `set-${tab}`));
}
$$('.set-tab').forEach(b => b.onclick = () => showSettings(b.dataset.set));

// ---------- Aussehen ----------
function mixHex(a, b, t) {
  const pa = [1, 3, 5].map(i => parseInt(a.slice(i, i + 2), 16)), pb = [1, 3, 5].map(i => parseInt(b.slice(i, i + 2), 16));
  return '#' + pa.map((v, i) => Math.round(v + (pb[i] - v) * t).toString(16).padStart(2, '0')).join('');
}
const lum = (h) => { const [r, g, b] = [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16)); return (r * 299 + g * 587 + b * 114) / 1000; };
/** Komplette Farbpalette aus Vorlage + eigenen Farben – wird für Launcher UND Spiel benutzt. */
function palette() {
  const L = state.look, c = L.custom || {};
  const t = THEMES.find(x => x.id === L.theme) || THEMES[0];
  const p = { ...t };
  if (c.bg) { p.bg = c.bg; p.bg2 = mixHex(c.bg, lum(c.bg) > 140 ? '#000000' : '#ffffff', .035); }
  if (c.panel || c.bg) {
    const base = c.panel || mixHex(p.bg, lum(p.bg) > 140 ? '#000000' : '#ffffff', .07);
    p.panel = base; p.panel2 = mixHex(base, lum(base) > 140 ? '#000000' : '#ffffff', .06);
    p.line = mixHex(base, lum(base) > 140 ? '#000000' : '#ffffff', .14);
  }
  if (c.text) p.text = c.text;
  if (c.text || c.bg) p.muted = mixHex(p.text, p.bg, .45);
  if (L.accent) { p.accent = L.accent; p.accent2 = mixHex(L.accent, '#ffffff', .4); }
  if (c.accent2) p.accent2 = c.accent2;
  p.onAccent = lum(p.accent) > 160 ? '#111111' : '#ffffff';
  return p;
}
function applyLook() {
  const L = state.look, t = palette();
  const root = document.documentElement.style;
  const vars = {
    '--bg': t.bg, '--bg-2': t.bg2, '--panel': t.panel, '--panel-2': t.panel2, '--line': t.line,
    '--text': t.text, '--muted': t.muted, '--accent': t.accent, '--accent-2': t.accent2, '--on-accent': t.onAccent
  };
  for (const [k, v] of Object.entries(vars)) root.setProperty(k, v);
  root.setProperty('--fs', { small: '13px', normal: '14px', large: '15.5px' }[L.font] || '14px');
  document.body.dataset.bg = L.bg;
  document.body.dataset.style = L.style || 'solid';
  root.setProperty('--font', FONTS[L.family] || FONTS.segoe);
  root.setProperty('--blur', (L.blur || 18) + 'px');
  document.body.dataset.radius = L.radius;
  document.body.classList.toggle('no-anim', !L.anim);
  document.body.classList.toggle('hide-skin', !L.showSkin);
}
function themeColors() {
  const t = palette();
  return { bg: t.bg, bg2: t.bg2, panel: t.panel, line: t.line, text: t.text, muted: t.muted, accent: t.accent, accent2: t.accent2, onAccent: t.onAccent };
}
function saveLook(patch) {
  Object.assign(state.look, patch);
  applyLook();
  renderThemes();
  api.settings.set({ appearance: state.look, themeColors: themeColors() });
}
function renderThemes() {
  const grid = $('#theme-grid');
  grid.innerHTML = '';
  for (const t of THEMES) {
    const b = el('button', `theme${state.look.theme === t.id ? ' on' : ''}`);
    const sw = el('div', 'sw');
    sw.style.background = `linear-gradient(135deg, ${t.bg2}, ${t.panel2})`;
    for (const c of [t.accent, t.accent2, t.text]) { const i = el('i'); i.style.background = c; sw.appendChild(i); }
    const name = el('span', 'tn', t.name);
    name.style.background = t.panel; name.style.color = t.text;
    b.append(sw, name);
    b.onclick = () => saveLook({ theme: t.id, accent: null, custom: {} });
    grid.appendChild(b);
  }
  const t = palette();
  $('#accent').value = t.accent;
  for (const key of ['bg', 'panel', 'text', 'accent2']) $(`#c-${key}`).value = t[key];
}
function initLookControls() {
  const L = state.look;
  $('#bg-style').value = L.bg;
  $('#radius').value = L.radius;
  $('#font-size').value = L.font;
  $('#anim').checked = L.anim;
  $('#show-skin').checked = L.showSkin;
  $('#accent').oninput = () => { state.look.accent = $('#accent').value; applyLook(); };
  $('#accent').onchange = () => saveLook({ accent: $('#accent').value });
  $('#accent-reset').onclick = () => saveLook({ accent: null });
  for (const key of ['bg', 'panel', 'text', 'accent2']) {
    const inp = $(`#c-${key}`);
    inp.oninput = () => { state.look.custom = { ...(state.look.custom || {}), [key]: inp.value }; applyLook(); };
    inp.onchange = () => saveLook({ custom: { ...(state.look.custom || {}), [key]: inp.value } });
  }
  $('#custom-reset').onclick = () => saveLook({ custom: {}, accent: null });
  $('#bg-style').onchange = () => saveLook({ bg: $('#bg-style').value });
  $('#radius').onchange = () => saveLook({ radius: $('#radius').value });
  $('#font-size').onchange = () => saveLook({ font: $('#font-size').value });
  $('#anim').onchange = () => saveLook({ anim: $('#anim').checked });
  $('#show-skin').onchange = () => saveLook({ showSkin: $('#show-skin').checked });
  $('#ui-style').value = L.style || 'solid';
  $('#font-family').value = L.family || 'segoe';
  $('#glass-blur').value = L.blur || 18;
  $('#ui-style').onchange = () => saveLook({ style: $('#ui-style').value });
  $('#font-family').onchange = () => saveLook({ family: $('#font-family').value });
  $('#glass-blur').oninput = () => { state.look.blur = +$('#glass-blur').value; applyLook(); };
  $('#glass-blur').onchange = () => saveLook({ blur: +$('#glass-blur').value });
  initMenuDesign();
  renderThemes();
}

// Hauptmenü im Spiel gestalten (mit kleiner Vorschau)
function initMenuDesign() {
  const M = { ...DEFAULT_MENU, ...(state.s.menu || {}) };
  state.menu = M;
  $('#menu-layout').value = M.layout; $('#menu-bg').value = M.bg; $('#menu-glass').checked = M.glass;
  $('#menu-clock').checked = M.clock; $('#menu-tips').checked = M.tips; $('#menu-radius').value = M.radius;
  const save = () => { api.settings.set({ menu: state.menu }); renderMenuPreview(); };
  $('#menu-layout').onchange = () => { state.menu.layout = $('#menu-layout').value; save(); };
  $('#menu-bg').onchange = () => { state.menu.bg = $('#menu-bg').value; save(); };
  $('#menu-glass').onchange = () => { state.menu.glass = $('#menu-glass').checked; save(); };
  $('#menu-clock').onchange = () => { state.menu.clock = $('#menu-clock').checked; save(); };
  $('#menu-tips').onchange = () => { state.menu.tips = $('#menu-tips').checked; save(); };
  $('#menu-radius').oninput = () => { state.menu.radius = +$('#menu-radius').value; renderMenuPreview(); };
  $('#menu-radius').onchange = () => save();
  renderMenuPreview();
}
function renderMenuPreview() {
  const M = state.menu, box = $('#menu-preview');
  box.className = `menu-preview l-${M.layout} b-${M.bg}${M.glass ? ' glass' : ''}`;
  box.style.setProperty('--mr', (M.radius / 2) + 'px');
  const btn = (t, big) => `<i class="mb${big ? ' big' : ''}">${t}</i>`;
  const btns = M.layout === 'bottom'
    ? `<div class="dock">${btn('▶ Einzel', 1)}${btn('⚑ Mehr', 1)}${btn('✦', 1)}${btn('⚙')}${btn('✎')}${btn('✕')}</div>`
    : `<div class="btns">${btn('▶ Einzelspieler', 1)}${btn('⚑ Mehrspieler', 1)}${M.layout === 'left' ? btn('✦ Baddy-Menü') : ''}</div>`;
  box.innerHTML = `<div class="logo"><b>✦ BADDY</b><small>C L I E N T</small></div>${btns}${M.clock || M.tips ? `<div class="info">${M.clock ? '<b>12:34</b>' : ''}<small>● Spieler</small>${M.tips ? '<small>Tipp: B = Emotes</small>' : ''}</div>` : ''}`;
}

// ---------- Allgemeine Einstellungen ----------
function setSetting(key, value) {
  state.s[key] = value;
  return api.settings.set({ [key]: value });
}
function initSettings() {
  const s = state.s;
  for (const inp of $$('[data-setting]')) {
    const key = inp.dataset.setting;
    if (inp.type === 'checkbox') inp.checked = !!s[key]; else inp.value = s[key] ?? '';
    inp.onchange = () => {
      let v = inp.type === 'checkbox' ? inp.checked : inp.value.trim();
      if (inp.dataset.type === 'number') v = Number(v) || 0;
      setSetting(key, v);
      if (key === 'showSnapshots') fillVersions($('#version').value);
    };
  }
  setupChoice('#java-mode', 'javaMode', v => { $('#java-custom').hidden = v !== 'custom'; });
  setupChoice('#source-pref', 'modSource');
  setupChoice('#on-launch', 'onLaunch');

  const maxRam = Math.min(32, Math.max(2, state.info.totalRam - 1));
  $('#ram').max = maxRam;
  if (s.ram > maxRam) { $('#ram').value = maxRam; setSetting('ram', maxRam); }
  $('#ram-val').textContent = `${$('#ram').value} GB`;
  $('#ram').oninput = () => { $('#ram-val').textContent = `${$('#ram').value} GB`; };
  $('#ram-hint').textContent = `Dein PC hat ${state.info.totalRam} GB. Empfohlen: 4 GB, mit vielen Mods 6–8 GB.`;

  $('#java-browse').onclick = async () => {
    const p = await api.settings.browseJava();
    if (p) { $('#java').value = p; state.s.javaPath = p; }
  };
  $('#open-runtimes').onclick = () => api.app.openFolder('runtimes');
  $('#open-root').onclick = () => api.app.openFolder('root');
  $('#cf-show').onclick = () => {
    const i = $('#cf-key');
    i.type = i.type === 'password' ? 'text' : 'password';
    $('#cf-show').textContent = i.type === 'password' ? 'Anzeigen' : 'Verbergen';
  };
  $('#cf-get').onclick = () => api.app.openExternal('https://console.curseforge.com/');
  $('#about').textContent = `Baddy Client ${state.info.version} · Electron ${state.info.electron} · Spieldaten: ${state.info.root}`;
  $('#diagnose').onclick = async () => {
    const box = $('#diag');
    box.innerHTML = '';
    box.appendChild(el('div', '', 'Teste…'));
    const results = await api.app.diagnose();
    box.innerHTML = '';
    for (const r of results) {
      const row = el('div');
      row.append(el('span', '', r.name), el('span', r.ok ? 'ok' : 'bad', r.ok ? `✓ ${r.ms} ms` : `✗ ${r.error}`));
      box.appendChild(row);
    }
  };
}
function setupChoice(sel, key, onChange) {
  const box = $(sel);
  const paint = () => box.querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.v === state.s[key]));
  box.querySelectorAll('button').forEach(b => b.onclick = () => { setSetting(key, b.dataset.v); paint(); onChange?.(b.dataset.v); });
  paint();
  onChange?.(state.s[key]);
}

// ---------- Skin & Vorschau ----------
async function loadSkin() {
  state.skin = null;
  if (state.account) {
    try {
      const data = await api.skin.get();
      if (data?.data) {
        const img = new Image();
        img.src = data.data;
        await img.decode();
        state.skin = { img, slim: data.slim };
      }
    } catch { /* Standardfigur verwenden */ }
  }
  renderStages();
}
function renderStage(stage) {
  const cos = stage.id === 'cos-stage';
  buildStage(stage, { skin: state.skin, equipped: state.cosmetics, spin: !cos, view: cos ? state.cosView : 'front', interactive: cos });
}
function renderStages() {
  renderStage($('#play-stage'));
  if ($('#page-cosmetics').classList.contains('active')) renderStage($('#cos-stage'));
  $('#skin-name').textContent = state.account ? state.account.name : 'Gast';
}
function syncWingSize() {
  const v = +state.custom.wingScale || 100;
  $('#wing-size').value = v; $('#ws-val').textContent = v + '%';
  const ps = +state.custom.petScale || 100;
  $('#pet-size').value = ps; $('#ps-val').textContent = ps + '%';
  $('#pet-spot').value = state.custom.petSpot || 'left';
}
$('#pet-size').oninput = (e) => {
  state.custom.petScale = +e.target.value;
  $('#ps-val').textContent = e.target.value + '%';
  setCustom(state.custom); renderStages();
};
$('#pet-size').onchange = () => api.settings.set({ cosmeticsCustom: state.custom });
$('#pet-spot').onchange = (e) => {
  state.custom.petSpot = e.target.value;
  setCustom(state.custom); renderStages();
  api.settings.set({ cosmeticsCustom: state.custom });
};
$('#wing-size').oninput = (e) => {
  state.custom.wingScale = +e.target.value;
  $('#ws-val').textContent = e.target.value + '%';
  setCustom(state.custom);
  renderStages();
};
$('#wing-size').onchange = () => api.settings.set({ cosmeticsCustom: state.custom });
$('#cos-turn').onclick = () => {
  state.cosView = state.cosView === 'front' ? 'back' : 'front';
  $('#cos-stage').turn?.();
};

// ---------- Cosmetics ----------
// ---------- Cosmetic-Editor ----------
// Editoren für eigene Cosmetics (mehrere pro Kategorie möglich)
const EDIT = {
  wings: {
    tab: 'wings', item: 'custom', label: 'Eigene Flügel', title: 'Eigene Flügel gestalten', base: () => ({ style: 'feather', colors: ['#7c3aed', '#e9d5ff'], glow: '#c084fc' }),
    fields: [
      ['select', 'style', 'Form', [['feather', 'Federn'], ['phoenix', 'Phönix'], ['galaxy', 'Galaxie'], ['marble', 'Marmor-Sterne'], ['starfeather', 'Sternenfedern'], ['aurora', 'Aurora'], ['seraph', 'Seraph (2 Paare)'], ['membrane', 'Drache'], ['frostdragon', 'Wyvern (faltet)'], ['crystal', 'Kristall'], ['butterfly', 'Schmetterling'], ['mecha', 'Mecha']]],
      ['color', 'colors.0', 'Farbe innen'], ['color', 'colors.1', 'Farbe außen'], ['glow', 'glow', 'Leuchten']
    ]
  },
  capeimg: {
    tab: 'cape', item: 'capeimg', label: 'Bild-Umhang (PNG)', title: 'Umhang mit eigenem Bild',
    base: () => ({ bg: '#111827', borderColor: '#a855f7', borderW: 3, borderGlow: true, zoom: 100, ox: 0, oy: 0, fit: 'cover', glowAll: false }),
    fields: [
      ['image', 'image', 'Bild hochladen (PNG/JPG)', { w: 360, h: 768 }],
      ['range', 'zoom', 'Zoom', [30, 300, 5, '%']], ['range', 'ox', 'Links ↔ Rechts', [-60, 60, 1]], ['range', 'oy', 'Hoch ↕ Runter', [-60, 60, 1]],
      ['select', 'fit', 'Anpassen', [['cover', 'Ausfüllen'], ['contain', 'Ganzes Bild']]],
      ['color', 'bg', 'Hintergrund'], ['color', 'borderColor', 'Rand-Farbe'], ['range', 'borderW', 'Rand-Dicke', [0, 8, 1]],
      ['check', 'borderGlow', 'Rand leuchtet'], ['check', 'glowAll', 'Umhang leuchtet im Dunkeln']
    ]
  },
  cape: {
    tab: 'cape', item: 'custom', label: 'Eigener Umhang', title: 'Eigenen Umhang gestalten', base: () => ({ c1: '#7c3aed', c2: '#1e1b4b', border: '#fbbf24', pattern: 'stars', emblem: 'Σ' }),
    fields: [
      ['color', 'c1', 'Farbe oben'], ['color', 'c2', 'Farbe unten'], ['color', 'border', 'Rand & Zeichen'],
      ['select', 'pattern', 'Muster', [['plain', 'Schlicht'], ['stars', 'Sterne'], ['stripes', 'Streifen'], ['waves', 'Wellen']]],
      ['select', 'emblem', 'Zeichen', [['', 'Keins'], ['Σ', 'Σ Zeichen'], ['★', '★ Stern'], ['♥', '♥ Herz']]]
    ]
  },
  head: {
    tab: 'head', item: 'custom', label: 'Eigenes Stirnband', title: 'Eigenes Stirnband gestalten', base: () => ({ color: '#7c3aed', color2: '#c4b5fd', color3: '#facc15', pattern: 'stripes', emblem: 'Σ', glow: null }),
    fields: [
      ['color', 'color', 'Farbe'], ['color', 'color2', 'Zweite Farbe'], ['color', 'color3', 'Dritte Farbe'],
      ['select', 'pattern', 'Muster', [['plain', 'Einfarbig'], ['stripes', 'Streifen'], ['dots', 'Punkte'], ['checker', 'Karo'], ['zigzag', 'Zickzack'], ['gradient', 'Farbverlauf'], ['tri', '3 Streifen'], ['rainbow', 'Regenbogen']]],
      ['select', 'emblem', 'Zeichen', [['', 'Keins'], ['Σ', 'Σ Zeichen'], ['★', '★ Stern'], ['♥', '♥ Herz']]],
      ['color', 'gem', 'Edelstein'], ['glow', 'glow', 'Leuchten']
    ]
  },
  photoband: {
    tab: 'head', item: 'photoband', label: 'Foto-Stirnband', title: 'Stirnband mit eigenem Foto',
    base: () => ({ color: '#111111', pzoom: 100, pox: 0, poy: 0, wrapSides: false, glowPhoto: false }),
    fields: [
      ['photo', 'px', 'Foto hochladen'], ['range', 'pzoom', 'Zoom', [100, 400, 10, '%']], ['range', 'pox', 'Links ↔ Rechts', [-100, 100, 5]], ['range', 'poy', 'Hoch ↕ Runter', [-100, 100, 5]],
      ['color', 'color', 'Bandfarbe'], ['check', 'wrapSides', 'Seiten in Bildfarbe'], ['check', 'glowPhoto', 'Foto leuchtet']
    ]
  },
  chainhalo: {
    tab: 'head', item: 'chainhalo', label: 'Ketten-Halo', title: 'Schwarz-Weiß-Halo mit Ketten',
    base: () => ({ c1: '#0a0a0a', c2: '#ffffff', chainColor: '#d4d4d8', chains: 2, spikes: true, sparks: true, r: 4.4 }),
    fields: [
      ['color', 'c1', 'Ring'], ['color', 'c2', 'Leuchten'], ['color', 'chainColor', 'Ketten'],
      ['select', 'chains', 'Anzahl Ketten', [[0, 'Keine'], [1, '1'], [2, '2'], [3, '3']]],
      ['check', 'spikes', 'Zacken'], ['check', 'sparks', 'Funken'], ['range', 'r', 'Größe', [3.5, 6, .1]]
    ]
  }
};
const getPath = (o, p) => p.split('.').reduce((v, k) => v?.[k], o);
function setPath(o, p, val) { const ks = p.split('.'); let t = o; ks.slice(0, -1).forEach(k => { t[k] = Array.isArray(t[k]) ? [...t[k]] : { ...(t[k] || {}) }; t = t[k]; }); t[ks.at(-1)] = val; }
const edSel = {};
const urlCanvas = new Map();
async function canvasFromURL(url) {
  if (urlCanvas.has(url)) return urlCanvas.get(url);
  const img = new Image(); img.src = url; await img.decode();
  const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
  c.getContext('2d').drawImage(img, 0, 0);
  urlCanvas.clear(); urlCanvas.set(url, c);
  return c;
}
async function refreshPhoto(cur) {
  if (!cur.pxSrc) return cur;
  const c = await canvasFromURL(cur.pxSrc);
  return { ...cur, px: SIGMA.photoPixels(c, (cur.pzoom || 100) / 100, (cur.pox || 0) / 100, (cur.poy || 0) / 100) };
}
let editTimer = null;
function renderEditor() {
  const box = $('#cos-editor'), tab = state.cosTab;
  const eds = Object.entries(EDIT).filter(([, d]) => d.tab === tab);
  if (!eds.length) { box.hidden = true; return; }
  const equippedEd = eds.find(([, d]) => d.item === state.cosmetics[tab]);
  const key = edSel[tab] && EDIT[edSel[tab]] ? edSel[tab] : (equippedEd ? equippedEd[0] : eds[0][0]);
  const def = EDIT[key];
  box.hidden = false;
  box.innerHTML = '';
  const cur = { ...def.base(), ...(state.custom[key] || {}) };
  const head = el('div', 'ed-head');
  if (eds.length > 1) {
    const sw = el('div', 'ed-switch');
    for (const [k, d] of eds) {
      const b = el('button', `chip${k === key ? ' on' : ''}`, '✎ ' + d.label);
      b.onclick = () => { edSel[tab] = k; renderEditor(); };
      sw.appendChild(b);
    }
    head.appendChild(sw);
  } else head.append(el('b', '', '✎ ' + def.title));
  const reset = el('button', 'btn ghost', 'Zurücksetzen');
  reset.onclick = () => { state.custom[key] = def.base(); saveCustom(key); };
  head.appendChild(reset);
  box.appendChild(head);
  const row = el('div', 'ed-fields');
  const commit = (c, now) => {
    // immer auf dem aktuellen Stand weiterarbeiten (vorher kam beim Verschieben/Zoomen das alte Bild zurück)
    for (const k of Object.keys(cur)) if (!(k in c)) delete cur[k];
    Object.assign(cur, c);
    c = { ...cur };
    state.custom[key] = c;
    clearTimeout(editTimer);
    if (now) saveCustom(key); else editTimer = setTimeout(() => saveCustom(key), 180);
  };
  for (const [type, k, label, opts] of def.fields) {
    const f = el('label', 'ed-field');
    f.appendChild(el('span', '', label));
    let inp;
    if (type === 'select') {
      inp = document.createElement('select');
      for (const [v, t] of opts) inp.appendChild(new Option(t, v));
      inp.value = getPath(cur, k) ?? '';
      inp.onchange = () => { const c = { ...cur }; const v = inp.value; setPath(c, k, v !== '' && !isNaN(v) && typeof opts[0][0] === 'number' ? +v : v); commit(c, true); };
    } else if (type === 'color') {
      inp = document.createElement('input');
      inp.type = 'color'; inp.value = getPath(cur, k) || '#ffffff';
      inp.onchange = () => { const c = { ...cur }; setPath(c, k, inp.value); commit(c, true); };
    } else if (type === 'range') {
      const [mn, mx, st, unit] = opts, wrap = el('div', 'row tight');
      inp = document.createElement('input'); inp.type = 'range'; inp.min = mn; inp.max = mx; inp.step = st; inp.value = cur[k] ?? mn;
      const val = el('b', 'ed-val', `${cur[k] ?? mn}${unit || ''}`);
      inp.oninput = async () => {
        val.textContent = inp.value + (unit || '');
        let c = { ...cur, [k]: +inp.value };
        if (def.item === 'photoband') c = await refreshPhoto(c);
        Object.assign(cur, c);
        commit(c, false);
      };
      wrap.append(inp, val); f.appendChild(wrap); row.appendChild(f); continue;
    } else if (type === 'check') {
      inp = document.createElement('input'); inp.type = 'checkbox'; inp.checked = cur[k] !== false && !!cur[k];
      inp.onchange = () => commit({ ...cur, [k]: inp.checked }, true);
    } else if (type === 'image' || type === 'photo') {
      inp = el('div', 'row tight');
      const file = document.createElement('input'); file.type = 'file'; file.accept = 'image/png,image/jpeg,image/webp,image/gif'; file.hidden = true;
      const btn = el('button', 'btn', (type === 'photo' ? cur.pxSrc : cur.image) ? '🖼 Anderes Bild' : '📁 Bild auswählen');
      btn.type = 'button';
      btn.onclick = (e) => { e.preventDefault(); file.click(); };
      file.onchange = async () => {
        const fl = file.files[0]; if (!fl) return;
        try {
          if (type === 'image') {
            const { url } = await SIGMA.loadImageFile(fl, opts.w, opts.h);
            commit({ ...cur, image: url }, true);
            renderEditor();
          } else {
            const { url } = await SIGMA.loadImageFile(fl, 360, 360);
            commit(await refreshPhoto({ ...cur, pxSrc: url }), true);
            renderEditor();
          }
          toast('Bild übernommen ✓');
        } catch (err) { toast(err.message, 'error'); }
      };
      inp.append(btn, file);
      if (type === 'image' && cur.image) { const rm = el('button', 'btn ghost', 'Entfernen'); rm.type = 'button'; rm.onclick = (e) => { e.preventDefault(); commit({ ...cur, image: null }, true); renderEditor(); }; inp.appendChild(rm); }
    } else {
      const wrap = el('div', 'row tight');
      const on = document.createElement('input'); on.type = 'checkbox'; on.checked = !!cur[k];
      const col = document.createElement('input'); col.type = 'color'; col.value = cur[k] || '#c084fc';
      const upd = () => commit({ ...cur, [k]: on.checked ? col.value : null }, true);
      on.onchange = upd; col.onchange = () => { on.checked = true; upd(); };
      wrap.append(on, col);
      inp = wrap;
    }
    f.appendChild(inp);
    row.appendChild(f);
  }
  box.appendChild(row);
  box.appendChild(el('p', 'muted small', 'Änderungen werden automatisch angelegt und erscheinen genau so im Spiel.'));
}
function saveCustom(key) {
  const def = EDIT[key];
  setCustom(state.custom);
  api.settings.set({ cosmeticsCustom: state.custom });
  state.cosmetics[def.tab] = def.item;
  api.settings.set({ cosmetics: state.cosmetics });
  renderGridMarks();
  renderStage($('#cos-stage'));
  renderStage($('#play-stage'));
  refreshCustomTile(def.tab, def.item);
}

// SVG -> PNG für die Mod (Texturen der aktuell angelegten Cosmetics)
async function rasterize(svg, w, h) {
  const src = svg.replace('<svg ', `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" `);
  const img = new Image();
  img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(src);
  await img.decode();
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  c.getContext('2d').drawImage(img, 0, 0, w, h);
  return c.toDataURL('image/png');
}
async function gameExtras() {
  const ex = { textures: {}, headBoxes: null, headGlow: false };
  const eq = state.cosmetics;
  try {
    // doppelte Auflösung für scharfe Details im Spiel
    if (eq.wings) ex.textures.wings = await rasterize(svgFor('wings', findItem('wings', eq.wings)), 800, 480);
    if (eq.cape) ex.textures.cape = await rasterize(svgFor('cape', findItem('cape', eq.cape)), 360, 768);
    ex.questDefs = SIGMA.QUESTS.map(({ id, name, desc, stat, goal }) => ({ id, name, desc, stat, goal }));
    ex.dailyPool = SIGMA.DAILY;
    const wi = eq.wings && findItem('wings', eq.wings);
    ex.wingFold = !!wi?.fold;
    const ci = eq.cape && findItem('cape', eq.cape);
    ex.capeGlow = !!ci?.glowAll;
    const hi = eq.head && findItem('head', eq.head);
    const hb = SIGMA.headBoxesFor(hi);
    if (hb) { ex.headBoxes = hb; ex.headGlow = hi.kind === 'band' && !!hi.glow; ex.headOrbitY = hi.orbitY ?? -4; }
    const fi = eq.feet && findItem('feet', eq.feet);
    if (fi) ex.feetBoxes = SIGMA.shoeBoxes(fi);
    const ai = eq.aura && findItem('aura', eq.aura);
    if (ai) {
      if (ai.ring) ex.textures.aura_ring = await rasterize(SIGMA.auraRingSVG(ai.ring, ai.c1, ai.c2), 256, 256);
      ex.textures.aura_sprite = await rasterize(SIGMA.spriteSVG(ai.sprite, ai.c1, ai.c2), 64, 64);
      ex.textures.aura_glow = await rasterize(SIGMA.glowSVG(ai.c1), 64, 64);
      ex.auraFx = { ring: !!ai.ring, ring2: !!ai.ring2, motion: ai.motion || 'rise', count: Math.min(24, ai.count || 14), speed: ai.speed || 1, pillar: !!ai.pillar, orbs: ai.orbs || 0, c1: ai.c1 };
    }
    const he = eq.helmet && findItem('helmet', eq.helmet);
    if (he) ex.helmBoxes = helmetBoxes(he);
    ex.petHeadTop = petHeadTop(he);
    ex.wingScale = (+state.custom.wingScale || 100) / 100;
  } catch (e) { console.warn('Texturen', e); }
  return ex;
}

function renderCosmetics() {
  const tabs = $('#cos-tabs');
  tabs.innerHTML = '';
  for (const [cat, def] of Object.entries(COSMETICS)) {
    const b = el('button', `tab${state.cosTab === cat ? ' active' : ''}`, `${def.icon} ${def.label} `);
    b.appendChild(el('small', 'muted', String(def.items.length)));
    b.onclick = () => { state.cosTab = cat; $('#cos-search').value = ''; renderCosmetics(); };
    tabs.appendChild(b);
  }
  renderEditor();
  renderGrid();
  renderStage($('#cos-stage'));
}
function renderGrid() {
  const grid = $('#cos-grid');
  grid.innerHTML = '';
  const cat = state.cosTab, q = ($('#cos-search').value || '').trim().toLowerCase(), rar = $('#cos-rar').value;
  const none = el('button', 'cos-item');
  none.dataset.id = '';
  none.style.setProperty('--rar', 'var(--muted)');
  const nv = el('div', 'vis', '∅'); nv.style.color = 'var(--muted)';
  none.append(nv, el('div', 'name', 'Nichts'), el('div', 'rar', '—'));
  none.onclick = () => equip(cat, null);
  grid.appendChild(none);
  const frag = document.createDocumentFragment();
  let n = 0;
  for (const raw of COSMETICS[cat].items) {
    if (q && !raw.name.toLowerCase().includes(q)) continue;
    if (rar && raw.rarity !== rar) continue;
    const item = raw.custom ? findItem(cat, raw.id) : raw;
    const r = RARITY[item.rarity];
    const locked = SIGMA.isLocked(item);
    const b = el('button', `cos-item r-${item.rarity}${locked ? ' locked' : ''}`);
    b.dataset.id = item.id;
    if (locked) b.title = item.quest ? `Quest: ${SIGMA.QUESTS.find(q => q.id === item.quest)?.name} – ${SIGMA.QUESTS.find(q => q.id === item.quest)?.desc}` : `Freischalten mit ${item.stars} ⭐`;
    b.style.setProperty('--rar', r.color);
    const vis = el('div', `vis v-${cat}`);
    vis.innerHTML = tile(cat, item);
    b.append(vis, el('div', 'name', item.name), el('div', 'rar', r.name));
    b.onclick = () => locked ? toast(`🔒 ${b.title}`) : equip(cat, state.cosmetics[cat] === item.id ? null : item.id);
    if (locked) b.appendChild(el('div', 'lock', '🔒'));
    frag.appendChild(b);
    n++;
  }
  grid.appendChild(frag);
  $('#cos-count').textContent = `${n} von ${COSMETICS[cat].items.length}`;
  renderGridMarks();
}
function renderGridMarks() {
  const cat = state.cosTab, cur = state.cosmetics[cat] || '';
  for (const b of $('#cos-grid').children) b.classList.toggle('on', b.dataset.id === cur);
  const eq = $('#equipped');
  eq.innerHTML = '';
  const names = Object.entries(state.cosmetics).map(([c, id]) => COSMETICS[c]?.items.find(i => i.id === id)?.name).filter(Boolean);
  if (!names.length) eq.appendChild(el('span', '', 'Nichts angelegt'));
  names.forEach(n => eq.appendChild(el('span', '', n)));
}
function refreshCustomTile(cat, id) {
  if (state.cosTab !== cat) return;
  const b = [...$('#cos-grid').children].find(x => x.dataset.id === id);
  if (b) b.querySelector('.vis').innerHTML = tile(cat, findItem(cat, id));
}
let searchTimer;
$('#cos-search').oninput = () => { clearTimeout(searchTimer); searchTimer = setTimeout(renderGrid, 120); };
$('#cos-rar').onchange = renderGrid;
function equip(cat, id) {
  if (id) state.cosmetics[cat] = id; else delete state.cosmetics[cat];
  if (cat === 'cape' && id) state.cosView = 'back';
  else if (cat !== 'cape' && id && state.cosView === 'back' && cat !== 'wings') state.cosView = 'front';
  api.settings.set({ cosmetics: state.cosmetics });
  const ed = Object.entries(EDIT).find(([, d]) => d.tab === cat && d.item === id);
  if (ed) { edSel[cat] = ed[0]; renderEditor(); }
  renderGridMarks();
  renderStage($('#cos-stage'));
  renderStage($('#play-stage'));
}

// ---------- Konto ----------
function renderAccount() {
  const a = state.account;
  $('#acc-name').textContent = a ? a.name : 'Nicht angemeldet';
  $('#acc-btn').textContent = a ? 'Konto wechseln' : 'Mit Microsoft anmelden';
  $('#logout').hidden = !a;
  const av = $('#avatar');
  if (a) { av.textContent = ''; av.style.backgroundImage = `url(https://mc-heads.net/avatar/${a.uuid}/64)`; }
  else { av.textContent = '?'; av.style.backgroundImage = ''; }
  loadSkin();
}
$('#acc-btn').onclick = async () => {
  try { state.account = await api.auth.login(); renderAccount(); toast(`Angemeldet als ${state.account.name}`, 'ok'); }
  catch (e) { toast(errMsg(e), 'err'); }
};
$('#logout').onclick = async () => { await api.auth.logout(); state.account = null; renderAccount(); toast('Abgemeldet'); };
api.on('auth:expired', () => { state.account = null; renderAccount(); });

// ---------- Versionen ----------
function fillVersions(keep) {
  const sel = $('#version');
  const V = state.versions;
  sel.innerHTML = '';
  if (!V) { sel.appendChild(new Option('Keine Versionen', '')); return updateVersionLabels(); }
  const loader = $('#loader').value;
  const fabric = new Set(V.fabric);
  const useFabricFilter = loader === 'fabric' && fabric.size > 0;
  const allowed = V.versions.filter(v =>
    (v.type === 'release' || (state.s.showSnapshots && v.type === 'snapshot')) &&
    (!useFabricFilter || fabric.has(v.id)));
  const groups = { release: 'Releases', snapshot: 'Snapshots' };
  for (const [type, label] of Object.entries(groups)) {
    const list = allowed.filter(v => v.type === type);
    if (!list.length) continue;
    const g = document.createElement('optgroup');
    g.label = label;
    for (const v of list) g.appendChild(new Option(v.id === V.latest?.release ? `${v.id} (neueste)` : v.id, v.id));
    sel.appendChild(g);
  }
  if (!allowed.length) sel.appendChild(new Option('Keine Versionen', ''));
  if (keep && allowed.some(v => v.id === keep)) sel.value = keep;
  updateVersionLabels();
}
function updateVerHint() {
  const ok = $('#version').value === '1.21.11' && $('#loader').value === 'fabric';
  $('#ver-hint').hidden = ok || !$('#version').value;
}
$('#ver-fix').onclick = (e) => {
  e.preventDefault();
  $('#loader').value = 'fabric'; $('#loader').onchange();
  if ([...$('#version').options].some(o => o.value === '1.21.11')) { $('#version').value = '1.21.11'; $('#version').onchange(); }
  else toast('1.21.11 nicht in der Liste – unter Einstellungen „Snapshots“ prüfen oder Versionen neu laden', 'err');
};
function updateVersionLabels() {
  const { mc, loader } = current();
  const txt = mc ? `für Minecraft ${mc} · ${loader === 'fabric' ? 'Fabric' : 'Vanilla'}` : 'Keine Version gewählt';
  $('#mods-for').textContent = txt;
  $('#browser-for').textContent = txt;
}
async function loadVersions() {
  const sel = $('#version');
  const keep = (state.versions && sel.value) || state.s.lastVersion;
  sel.innerHTML = '<option>Lädt…</option>';
  $('#version-error').hidden = true;
  try {
    state.versions = await api.versions.list();
    fillVersions(keep);
    if (!state.versions.fabricOk && $('#loader').value === 'fabric') toast('Fabric-Server nicht erreichbar – es werden alle Versionen angezeigt', 'err');
  } catch (e) {
    state.versions = null;
    fillVersions();
    const box = $('#version-error');
    box.hidden = false;
    box.textContent = `Versionen konnten nicht geladen werden: ${errMsg(e)}`;
    const retry = el('button', 'btn', 'Erneut versuchen');
    retry.onclick = loadVersions;
    const diag = el('button', 'btn ghost', 'Verbindung testen');
    diag.onclick = () => { showPage('settings'); showSettings('about'); $('#diagnose').click(); };
    box.append(retry, diag);
  }
}
$('#reload-versions').onclick = loadVersions;
$('#loader').onchange = () => {
  fillVersions($('#version').value);
  updateVerHint();
  setSetting('lastLoader', $('#loader').value);
  if ($('#version').value) setSetting('lastVersion', $('#version').value);
  if ($('#page-mods').classList.contains('active')) refreshMods();
};
$('#version').onchange = () => {
  updateVersionLabels();
  updateVerHint();
  setSetting('lastVersion', $('#version').value);
  if ($('#page-mods').classList.contains('active')) refreshMods();
};

// ---------- Spielen ----------
const play = $('#play');
function setProgress(label, pct) {
  $('#progress').classList.add('show');
  $('#progress-label').textContent = label;
  if (pct != null) $('#bar-fill').style.width = `${Math.max(0, Math.min(100, pct))}%`;
}
play.onclick = async () => {
  const { mc, loader } = current();
  if (!mc) return toast('Bitte zuerst eine Version auswählen', 'err');
  if (loader === 'vanilla') {
    const mods = await api.mods.list(mc, 'vanilla');
    if (mods.some(m => m.enabled)) toast('Hinweis: Vanilla lädt keine Mods – wähle Fabric', 'err');
  }
  play.disabled = true; play.textContent = 'STARTET…';
  $('#log').textContent = '';
  setProgress('Vorbereiten…', 0);
  try { await api.game.launch({ mc, loader, extras: await gameExtras() }); }
  catch (e) {
    toast(errMsg(e), 'err');
    play.disabled = false; play.textContent = 'SPIELEN';
    $('#progress').classList.remove('show');
  }
};
api.on('launch:progress', (e) => {
  const pct = e.total ? (e.task / e.total) * 100 : null;
  setProgress(`Lade ${e.type}… ${e.total ? `${e.task}/${e.total}` : ''}`, pct);
});
api.on('launch:started', () => {
  if (play.textContent !== 'LÄUFT') { play.textContent = 'LÄUFT'; setProgress('Minecraft läuft', 100); }
});
api.on('launch:closed', (code) => {
  play.disabled = false; play.textContent = 'SPIELEN';
  $('#progress').classList.remove('show');
  if (code && code !== 0) toast(`Minecraft wurde mit Code ${code} beendet – siehe Spiel-Log`, 'err');
});
api.on('launch:log', (line) => {
  const log = $('#log');
  log.textContent += line;
  if (log.textContent.length > 200000) log.textContent = log.textContent.slice(-150000);
  log.scrollTop = log.scrollHeight;
});

// ---------- Installierte Mods ----------
const modView = { filter: 'all', query: '', list: [] };
const isSigmaCore = (m) => /^sigma-cosmetics|^fabric-api/i.test(m.file);
async function refreshMods() {
  const { mc, loader } = current();
  if (!mc) { modView.list = []; renderModList(); return; }
  try { modView.list = await api.mods.list(mc, loader); }
  catch (e) { modView.list = []; toast(errMsg(e), 'err'); }
  renderModList();
}
function renderModList() {
  if (!$('#mods-perf').hidden) renderPerfList();
  const list = $('#mod-list');
  list.innerHTML = '';
  const { mc, loader } = current();
  const all = modView.list;
  const on = all.filter(m => m.enabled).length;
  $('#cnt-all').textContent = all.length; $('#cnt-all2').textContent = all.length; $('#cnt-on').textContent = on; $('#cnt-off').textContent = all.length - on;
  $$('#mod-state .tab').forEach(t => t.classList.toggle('active', t.dataset.f === modView.filter));
  if (!mc) { list.appendChild(el('div', 'empty', 'Wähle zuerst unter „Spielen" eine Version aus.')); return; }
  if (!all.length) {
    const box = el('div', 'empty-box');
    box.append(el('h3', '', 'Noch keine Mods für diese Version'), el('p', '', 'Stöbere im Mod-Browser oder zieh eigene .jar-Dateien hierher.'));
    const b = el('button', 'btn primary', '+ Mods hinzufügen');
    b.onclick = openBrowser;
    box.appendChild(b);
    list.appendChild(box);
    return;
  }
  const q = modView.query.toLowerCase();
  const shown = all
    .filter(m => modView.filter === 'all' || (modView.filter === 'on') === m.enabled)
    .filter(m => !q || m.title.toLowerCase().includes(q) || m.file.toLowerCase().includes(q))
    .sort((a, b) => (isSigmaCore(b) - isSigmaCore(a)) || a.title.localeCompare(b.title));
  if (!shown.length) { list.appendChild(el('div', 'empty', 'Keine Mods passen zu deiner Suche.')); return; }
  const groupOf = (m) => isSigmaCore(m) ? 0 : perfMatch(m) ? 1 : 2;
  const GROUP = ['Baddy Client', '⚡ Performance', 'Weitere Mods'];
  shown.sort((a, b) => groupOf(a) - groupOf(b) || a.title.localeCompare(b.title));
  let lastGroup = -1;
  for (const m of shown) {
    const g = groupOf(m);
    if (g !== lastGroup) {
      lastGroup = g;
      const cnt = shown.filter(x => groupOf(x) === g).length;
      const h = el('div', 'mod-group', GROUP[g]); h.appendChild(el('span', 'badge', String(cnt)));
      list.appendChild(h);
    }
    const core = isSigmaCore(m);
    const row = el('div', `mod${m.enabled ? '' : ' off'}${core ? ' core' : ''}`);
    row.appendChild(iconEl(m.icon, m.title));
    const info = el('div', 'info');
    const t = el('div', 'title', /^sigma-cosmetics/i.test(m.file) ? 'Baddy-Mod' : m.title);
    if (core) t.appendChild(el('span', 'src sigma', 'Baddy'));
    else t.appendChild(el('span', `src ${m.source}`, SOURCE_NAME[m.source] || 'Datei'));
    info.append(t, el('div', 'desc', core ? 'Wird vom Baddy Client gebraucht' : m.file));
    row.appendChild(info);

    const sw = el('label', 'switch');
    sw.title = m.enabled ? 'Ausschalten' : 'Einschalten';
    const cb = document.createElement('input');
    cb.type = 'checkbox'; cb.checked = m.enabled;
    cb.onchange = async () => {
      try { await api.mods.toggle(mc, loader, m.file); refreshMods(); }
      catch (e) { toast(errMsg(e), 'err'); }
    };
    sw.append(cb, el('span'));
    row.appendChild(sw);

    const del = el('button', 'icon-btn', '✕');
    del.title = 'Entfernen';
    del.disabled = core;
    del.onclick = async () => {
      if (!confirm(`„${m.title}" wirklich entfernen?`)) return;
      try { await api.mods.remove(mc, loader, m.file); toast(`${m.title} entfernt`); refreshMods(); }
      catch (e) { toast(errMsg(e), 'err'); }
    };
    row.appendChild(del);
    list.appendChild(row);
  }
}
$('#mod-filter').oninput = () => { modView.query = $('#mod-filter').value.trim(); renderModList(); };
$$('#mod-state .tab').forEach(t => t.onclick = () => { modView.filter = t.dataset.f; renderModList(); });
$('#mods-all-off').onclick = async () => {
  const { mc, loader } = current();
  const targets = modView.list.filter(m => m.enabled && !isSigmaCore(m));
  if (!targets.length) return toast('Alle zusätzlichen Mods sind schon aus');
  if (!confirm(`${targets.length} Mods ausschalten? (Baddy-Mod und Fabric API bleiben an)`)) return;
  for (const m of targets) { try { await api.mods.toggle(mc, loader, m.file); } catch { /* weiter */ } }
  toast(`${targets.length} Mods ausgeschaltet`, 'ok');
  refreshMods();
};
// ---------- Empfohlene Performance-Mods (ein Klick an/aus) ----------
const PERF_MODS = [
  { slug: 'sodium', name: 'Sodium', re: /^sodium-(fabric|\d)/i, desc: 'Baut das Rendering neu – oft doppelte bis dreifache FPS.', fx: 'Riesig' },
  { slug: 'lithium', name: 'Lithium', re: /^lithium/i, desc: 'Schnellere Spiel-Logik (Mobs, Redstone, Blöcke).', fx: 'Hoch' },
  { slug: 'entityculling', name: 'Entity Culling', re: /^entityculling/i, desc: 'Zeichnet keine Mobs und Truhen, die hinter Wänden sind.', fx: 'Hoch' },
  { slug: 'immediatelyfast', name: 'ImmediatelyFast', re: /^immediatelyfast/i, desc: 'HUD, Text, Schilder und Karten viel schneller.', fx: 'Hoch' },
  { slug: 'moreculling', name: 'More Culling', re: /^moreculling/i, desc: 'Lässt unsichtbare Blockseiten (Blätter usw.) weg.', fx: 'Mittel' },
  { slug: 'ferrite-core', name: 'FerriteCore', re: /^ferritecore/i, desc: 'Braucht viel weniger Arbeitsspeicher (RAM).', fx: 'Mittel' },
  { slug: 'modernfix', name: 'ModernFix', re: /^modernfix/i, desc: 'Schnellerer Start und weniger Ruckler.', fx: 'Mittel' },
  { slug: 'dynamic-fps', name: 'Dynamic FPS', re: /^dynamic-?fps/i, desc: 'Spart Leistung im Hintergrund und im Menü.', fx: 'Klein' },
  { slug: 'badoptimizations', name: 'BadOptimizations', re: /^badoptimizations/i, desc: 'Viele kleine Optimierungen (Licht, Himmel, Partikel).', fx: 'Klein' },
  { slug: 'krypton', name: 'Krypton', re: /^krypton/i, desc: 'Schnelleres Netzwerk auf Servern.', fx: 'Klein' }
];
const perfMatch = (m) => PERF_MODS.find(p => p.re.test(m.file));
function renderPerfList() {
  const box = $('#perf-list');
  box.innerHTML = '';
  const { mc, loader } = current();
  if (!mc) { box.appendChild(el('div', 'empty', 'Wähle zuerst unter „Spielen" eine Version aus.')); return; }
  if (loader !== 'fabric') { box.appendChild(el('div', 'empty', 'Performance-Mods brauchen Fabric. Wähle unter „Spielen" eine Fabric-Version.')); return; }
  for (const p of PERF_MODS) {
    const inst = modView.list.find(m => p.re.test(m.file));
    const on = !!inst?.enabled;
    const card = el('div', `perf-card${on ? ' on' : ''}`);
    const info = el('div', 'info');
    const t = el('div', 'title', p.name);
    t.appendChild(el('span', `fx fx-${p.fx.toLowerCase()}`, `FPS: ${p.fx}`));
    info.append(t, el('div', 'desc', p.desc), el('div', 'state muted small', inst ? (on ? 'Installiert · an' : 'Installiert · aus') : 'Nicht installiert – wird beim Einschalten geladen'));
    const sw = el('label', 'switch');
    const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = on;
    cb.onchange = () => setPerfMod(p, cb.checked, card);
    sw.append(cb, el('span'));
    card.append(info, sw);
    box.appendChild(card);
  }
}
async function setPerfMod(p, want, card) {
  const { mc, loader } = current();
  const inst = modView.list.find(m => p.re.test(m.file));
  card?.classList.add('busy');
  try {
    if (want && !inst) { await api.browse.install({ source: 'modrinth', id: p.slug, mc, loader }); toast(`${p.name} installiert ✓`, 'ok'); }
    else if (inst && inst.enabled !== want) await api.mods.toggle(mc, loader, inst.file);
  } catch (e) { toast(`${p.name}: ${errMsg(e)}`, 'err'); }
  await refreshMods();
  renderPerfList();
}
$('#perf-all').onclick = async () => { const b = $('#perf-all'); b.disabled = true; for (const p of PERF_MODS) { b.textContent = `⚡ ${p.name}…`; await setPerfMod(p, true); } b.disabled = false; b.textContent = '⚡ Alle an'; toast('Performance-Mods sind an – mehr FPS beim nächsten Start!', 'ok'); };
$('#perf-none').onclick = async () => { for (const p of PERF_MODS) await setPerfMod(p, false); toast('Performance-Mods ausgeschaltet'); };
$$('#mod-tabs button').forEach(b => b.onclick = () => {
  $$('#mod-tabs button').forEach(x => x.classList.toggle('on', x === b));
  $('#mods-installed').hidden = b.dataset.t !== 'installed';
  $('#mods-perf').hidden = b.dataset.t !== 'perf';
  if (b.dataset.t === 'perf') renderPerfList();
});
api.on('mods:autoDisabled', (names) => {
  toast(`Ausgeschaltet, weil sie nur in Feather/Lunar laufen: ${names.join(', ')}`, 'err');
  if ($('#page-mods').classList.contains('active')) refreshMods();
});
$('#add-jar').onclick = async () => {
  const { mc, loader } = current();
  if (!mc) return toast('Bitte zuerst eine Version auswählen', 'err');
  const n = await api.mods.addFiles(mc, loader);
  if (n) { toast(`${n} Mod(s) hinzugefügt`, 'ok'); refreshMods(); }
};
$('#open-mods').onclick = () => { const { mc, loader } = current(); if (mc) api.mods.openFolder(mc, loader); };
$('#open-browser').onclick = () => openBrowser();

const dz = $('#dropzone');
['dragenter', 'dragover'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.add('over'); }));
['dragleave', 'drop'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.remove('over'); }));
dz.addEventListener('drop', async (e) => {
  const paths = [...e.dataTransfer.files].map(f => api.pathForFile(f)).filter(p => /\.jar$/i.test(p));
  if (!paths.length) return toast('Nur .jar-Dateien werden unterstützt', 'err');
  const { mc, loader } = current();
  const n = await api.mods.addPaths(mc, loader, paths);
  toast(`${n} Mod(s) hinzugefügt`, 'ok');
  refreshMods();
});
window.addEventListener('dragover', e => e.preventDefault());
window.addEventListener('drop', e => e.preventDefault());

// ---------- Mod-Browser ----------
async function openBrowser() {
  const { mc, loader } = current();
  if (!mc) return toast('Bitte zuerst unter „Spielen" eine Version auswählen', 'err');
  if (loader !== 'fabric') {
    toast('Mods brauchen den Fabric-Loader – ich habe Fabric für dich ausgewählt', 'ok');
    $('#loader').value = 'fabric';
    $('#loader').onchange();
    if (!$('#version').value) return;
  }
  $('#browser').hidden = false;
  browser.selected.clear();
  updateFooter();
  setSource(state.s.modSource || 'modrinth');
  $('#search').focus();
}
function closeBrowser() {
  if (browser.busy) return;
  $('#browser').hidden = true;
  if ($('#page-mods').classList.contains('active')) refreshMods();
}
$('#browser-close').onclick = closeBrowser;
$('#browser').addEventListener('mousedown', e => { if (e.target.id === 'browser') closeBrowser(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape' && !$('#browser').hidden) closeBrowser(); });

async function setSource(source) {
  browser.source = source;
  $$('#source-tabs .tab').forEach(t => t.classList.toggle('active', t.dataset.source === source));
  const cat = $('#category');
  cat.innerHTML = '<option value="">Alle Kategorien</option>';
  search(true);
  try {
    const list = await api.browse.categories(source);
    if (browser.source !== source) return;
    for (const c of list) cat.appendChild(new Option(c.name, c.id));
  } catch { /* Kategorien sind optional */ }
}
$$('#source-tabs .tab').forEach(t => t.onclick = () => { if (!browser.busy) setSource(t.dataset.source); });
$('#search').oninput = () => { clearTimeout(browser.timer); browser.timer = setTimeout(() => search(true), 350); };
$('#category').onchange = () => search(true);
$('#sort').onchange = () => search(true);
$('#more').onclick = () => search(false);

async function refreshInstalled() {
  const { mc, loader } = current();
  const mods = await api.mods.list(mc, loader);
  browser.installed = new Set(mods.filter(m => m.projectId).map(m =>
    m.projectId.startsWith('cf:') ? `curseforge:${m.projectId.slice(3)}` : `modrinth:${m.projectId}`));
}
async function search(reset) {
  const { mc, loader } = current();
  const id = ++browser.reqId;
  const results = $('#results');
  if (reset) {
    browser.offset = 0; browser.hits = [];
    results.innerHTML = '';
    results.appendChild(el('div', 'empty-box', 'Suche…'));
    $('#more').hidden = true;
  } else {
    $('#more').disabled = true; $('#more').textContent = 'Lädt…';
  }
  try {
    const [r] = await Promise.all([
      api.browse.search({
        source: browser.source, query: $('#search').value.trim(), mc, loader,
        category: $('#category').value, sort: $('#sort').value, offset: browser.offset
      }),
      reset ? refreshInstalled() : null
    ]);
    if (id !== browser.reqId) return;
    browser.hits.push(...r.hits);
    browser.total = r.total;
    browser.offset += r.hits.length;
    renderResults();
  } catch (e) {
    if (id !== browser.reqId) return;
    const raw = String(e?.message || e);
    results.innerHTML = '';
    const box = el('div', 'empty-box');
    if (raw.includes('CF_NO_KEY') || raw.includes('Schlüssel ungültig')) {
      box.append(el('h3', '', raw.includes('ungültig') ? 'CurseForge-Schlüssel ungültig' : 'CurseForge braucht einen Schlüssel'),
        el('p', '', 'CurseForge erlaubt die Suche nur mit einem kostenlosen API-Schlüssel. Trag ihn in den Einstellungen ein – oder nutz einfach Modrinth.'));
      const go = el('button', 'btn primary', 'Schlüssel eintragen');
      go.onclick = () => { closeBrowser(); showPage('settings'); showSettings('modset'); $('#cf-key').focus(); };
      const mr = el('button', 'btn ghost', 'Zu Modrinth wechseln');
      mr.style.marginLeft = '8px';
      mr.onclick = () => setSource('modrinth');
      box.append(go, mr);
    } else {
      box.append(el('h3', '', 'Suche fehlgeschlagen'), el('p', '', errMsg(e)));
      const retry = el('button', 'btn', 'Erneut versuchen');
      retry.onclick = () => search(true);
      box.appendChild(retry);
    }
    results.appendChild(box);
    $('#more').hidden = true;
  } finally {
    $('#more').disabled = false; $('#more').textContent = 'Mehr laden';
  }
}
function renderResults() {
  const results = $('#results');
  results.innerHTML = '';
  if (!browser.hits.length) {
    const { mc } = current();
    const box = el('div', 'empty-box');
    box.append(el('h3', '', 'Nichts gefunden'), el('p', '', `Keine passenden Fabric-Mods für Minecraft ${mc}. Probier einen anderen Suchbegriff oder eine ältere Version.`));
    results.appendChild(box);
  }
  for (const h of browser.hits) {
    const key = `${h.source}:${h.id}`;
    const installed = browser.installed.has(key);
    const card = el('button', `rcard${browser.selected.has(key) ? ' sel' : ''}${installed || !h.canInstall ? ' dim' : ''}`);
    card.appendChild(iconEl(h.icon, h.title));
    const info = el('div', 'info');
    info.append(el('div', 'title', h.title), el('div', 'by', `von ${h.author || 'unbekannt'} · ⬇ ${fmt(h.downloads || 0)}`), el('div', 'desc', h.description || ''));
    const tags = el('div', 'tags');
    if (installed) tags.appendChild(el('span', 'tag ok', '✓ Installiert'));
    else if (!h.canInstall) tags.appendChild(el('span', 'tag warn', 'Nur auf der CurseForge-Seite'));
    const link = el('span', 'page-link', 'Seite öffnen ↗');
    link.onclick = (e) => { e.stopPropagation(); api.app.openExternal(h.url); };
    tags.appendChild(link);
    info.appendChild(tags);
    card.appendChild(info);
    if (!installed && h.canInstall) card.appendChild(el('span', 'check', '✓'));
    card.onclick = () => {
      if (browser.busy || installed) return;
      if (!h.canInstall) { toast('Diesen Mod erlaubt der Autor nur auf CurseForge – lade ihn dort und zieh die .jar in Baddy'); api.app.openExternal(h.url); return; }
      if (browser.selected.has(key)) browser.selected.delete(key); else browser.selected.set(key, h);
      card.classList.toggle('sel');
      updateFooter();
    };
    results.appendChild(card);
  }
  $('#more').hidden = browser.offset >= browser.total || !browser.hits.length;
}
function updateFooter() {
  const n = browser.selected.size;
  $('#sel-count').textContent = n ? `${n} Mod${n > 1 ? 's' : ''} ausgewählt` : 'Klicke Mods an, um sie auszuwählen';
  $('#sel-install').disabled = !n || browser.busy;
  $('#sel-install').textContent = n ? `${n} installieren` : 'Installieren';
  $('#sel-clear').hidden = !n || browser.busy;
}
$('#sel-clear').onclick = () => { browser.selected.clear(); renderResults(); updateFooter(); };
$('#sel-install').onclick = async () => {
  const { mc, loader } = current();
  const items = [...browser.selected.values()];
  browser.busy = true;
  $('#sel-install').disabled = true; $('#sel-clear').hidden = true;
  const done = [], failed = [];
  for (let i = 0; i < items.length; i++) {
    const h = items[i];
    $('#sel-count').textContent = `Installiere ${i + 1}/${items.length}: ${h.title}…`;
    try {
      const added = await api.browse.install({ source: h.source, id: h.id, mc, loader });
      done.push(...(added.length ? added : [h.title]));
      browser.selected.delete(`${h.source}:${h.id}`);
    } catch (e) { failed.push(`${h.title}: ${errMsg(e)}`); }
  }
  browser.busy = false;
  await refreshInstalled();
  renderResults();
  updateFooter();
  if (done.length) toast(`Installiert: ${done.join(', ')}`, 'ok');
  failed.forEach(f => toast(f, 'err'));
};

// ---------- Import aus Lunar / Minecraft ----------
function importTargetText() {
  const { mc, loader } = current();
  $('#imp-target').textContent = mc ? `Minecraft ${mc} · ${loader === 'fabric' ? 'Fabric' : 'Vanilla'}` : 'keine Version gewählt';
}
function checkRow(label, checked, data) {
  const row = el('label', 'check-row');
  const cb = document.createElement('input');
  cb.type = 'checkbox'; cb.checked = checked;
  Object.assign(cb.dataset, data);
  row.append(cb, el('span', '', label));
  return row;
}
function renderImport() {
  const box = $('#imp-result');
  box.innerHTML = '';
  const sources = state.imports;
  if (!sources.length) {
    box.appendChild(el('p', 'muted imp-empty', 'Keine Lunar- oder Minecraft-Daten gefunden. Wähle den Ordner selbst aus.'));
    return;
  }
  const sel = document.createElement('select');
  sel.className = 'wide';
  sources.forEach((s, i) => sel.appendChild(new Option(s.label, i)));
  sel.value = box.dataset.sel || 0;
  sel.onchange = () => { box.dataset.sel = sel.value; renderImport(); };
  const src = sources[sel.value] || sources[0];
  box.append(el('div', 'sub-label', 'Quelle'), sel);

  const list = el('div', 'imp-list');
  if (src.options) list.appendChild(checkRow('Einstellungen (Tasten, Maus, Grafik, Sound)', true, { k: 'options' }));
  if (src.servers) list.appendChild(checkRow('Serverliste', true, { k: 'servers' }));
  if (src.resourcepacks) list.appendChild(checkRow(`Texturepacks (${src.resourcepacks})`, true, { k: 'resourcepacks' }));
  if (src.shaderpacks) list.appendChild(checkRow(`Shader (${src.shaderpacks})`, true, { k: 'shaderpacks' }));
  box.appendChild(list);

  if (src.saves.length) {
    box.appendChild(el('div', 'sub-label', `Welten (${src.saves.length}) – werden kopiert, Originale bleiben`));
    const w = el('div', 'imp-list cols');
    src.saves.forEach(n => w.appendChild(checkRow(n, false, { save: n })));
    box.appendChild(w);
  }
  if (src.mods.length) {
    const fabric = current().loader === 'fabric';
    box.appendChild(el('div', 'sub-label', `Mods (${src.mods.length})`));
    box.appendChild(el('p', 'muted small', fabric
      ? 'Nur Fabric-Mods für die gleiche Minecraft-Version funktionieren. Lunars eigene Mods (Keystrokes, FPS usw.) gibt es nur in Lunar.'
      : 'Mods brauchen Fabric – wähle unter „Spielen" den Loader Fabric, um Mods zu übernehmen.'));
    const m = el('div', 'imp-list cols');
    src.mods.forEach(x => {
      const r = checkRow(x.file, fabric, { mod: x.path });
      r.querySelector('input').disabled = !fabric;
      m.appendChild(r);
    });
    box.appendChild(m);
  }
  box.appendChild(el('p', 'warn-note', '⚠ Übernimm am besten in dieselbe Minecraft-Version, die du dort gespielt hast. Welten aus neueren Versionen können in älteren kaputtgehen.'));
  const go = el('button', 'btn primary', 'Übernehmen');
  go.onclick = async () => {
    const { mc, loader } = current();
    if (!mc) return toast('Bitte zuerst unter „Spielen" eine Version auswählen', 'err');
    const what = { saves: [], mods: [] };
    box.querySelectorAll('input[type=checkbox]:checked').forEach(cb => {
      if (cb.dataset.k) what[cb.dataset.k] = true;
      if (cb.dataset.save) what.saves.push(cb.dataset.save);
      if (cb.dataset.mod) what.mods.push(cb.dataset.mod);
    });
    go.disabled = true; go.textContent = 'Übernehme…';
    try {
      const done = await api.importer.run({ source: src.path, mc, loader, what });
      toast(done.length ? `Übernommen nach ${mc}: ${done.join(', ')}` : 'Nichts ausgewählt', done.length ? 'ok' : '');
    } catch (e) { toast(errMsg(e), 'err'); }
    go.disabled = false; go.textContent = 'Übernehmen';
  };
  box.appendChild(go);
}
$('#imp-scan').onclick = async () => {
  importTargetText();
  $('#imp-result').innerHTML = '<p class="muted">Suche…</p>';
  try { state.imports = await api.importer.scan(); } catch (e) { state.imports = []; toast(errMsg(e), 'err'); }
  $('#imp-result').dataset.sel = 0;
  renderImport();
};
$('#imp-pick').onclick = async () => {
  importTargetText();
  const r = await api.importer.pick();
  if (!r) return;
  if (r.error) return toast(r.error, 'err');
  state.imports = [r, ...state.imports.filter(s => s.path !== r.path)];
  $('#imp-result').dataset.sel = 0;
  renderImport();
};
$('#goto-import').onclick = () => { showPage('settings'); showSettings('import'); importTargetText(); };
$$('.set-tab[data-set="import"]').forEach(b => b.addEventListener('click', importTargetText));

// ---------- Quests ----------
const fmtN = (n) => Math.floor(n).toLocaleString('de-DE');
function dailyFor(dateStr) {
  // gleiche Auswahl wie im Spiel: 3 Quests, abhängig vom Datum
  let h = 0; for (const ch of dateStr) h = (h * 31 + ch.charCodeAt(0)) | 0;
  const pool = [...SIGMA.DAILY], out = [];
  let x = Math.abs(h) || 7;
  while (out.length < 3 && pool.length) { x = (Math.imul(x, 1103515245) + 12345) & 0x7fffffff; out.push(pool.splice(x % pool.length, 1)[0]); }
  return out;
}
function rewardTile(cat, id) {
  const it = COSMETICS[cat]?.items.find(i => i.id === id);
  const t = el('div', 'q-reward');
  if (!it) return t;
  const v = el('div', `vis v-${cat}`); v.innerHTML = tile(cat, it);
  t.append(v, el('small', '', it.name.replace(/^🏆 |^⭐ /, '')));
  return t;
}
async function loadQuests() {
  let q = { stats: {}, done: [], stars: 0, daily: null };
  try { q = { ...q, ...(await api.quests.get()) }; } catch { }
  state.quests = q;
  SIGMA.setUnlocks(q);
  $('#q-stars').textContent = `⭐ ${q.stars}`;
  const list = $('#q-list'); list.innerHTML = '';
  for (const d of SIGMA.QUESTS) {
    const val = d.stat === 'quests' ? q.done.filter(x => x !== 'all').length : (q.stats[d.stat] || 0);
    const done = q.done.includes(d.id), pct = Math.min(100, val / d.goal * 100);
    const c = el('div', `q-card${done ? ' done' : ''}`);
    const head = el('div', 'q-head');
    head.append(el('b', '', (done ? '✅ ' : '🏆 ') + d.name), el('span', 'muted small', done ? 'Geschafft!' : `${fmtN(val)} / ${fmtN(d.goal)}`));
    const bar = el('div', 'q-bar'); const fill = el('i'); fill.style.width = pct + '%'; bar.appendChild(fill);
    c.append(head, el('div', 'muted small', d.desc + (d.stat === 'play' ? ' (in Minuten gezählt)' : '')), bar, rewardTile(...d.reward));
    list.appendChild(c);
  }
  const nd = new Date(), today = `${nd.getFullYear()}-${String(nd.getMonth() + 1).padStart(2, '0')}-${String(nd.getDate()).padStart(2, '0')}`, daily = $('#q-daily'); daily.innerHTML = '';
  const dq = q.daily && q.daily.date === today ? q.daily : null;
  for (const d of dailyFor(today)) {
    const base = dq?.base?.[d.stat] ?? (q.stats[d.stat] || 0), val = Math.max(0, (q.stats[d.stat] || 0) - base);
    const done = !!dq?.done?.includes(d.id), pct = done ? 100 : Math.min(100, val / d.goal * 100);
    const r = el('div', `q-row${done ? ' done' : ''}`);
    const bar = el('div', 'q-bar'); const fill = el('i'); fill.style.width = pct + '%'; bar.appendChild(fill);
    r.append(el('span', '', (done ? '✅ ' : '⭐ ') + d.desc), bar);
    daily.appendChild(r);
  }
  const sl = $('#q-stars-list'); sl.innerHTML = '';
  for (const [n, cat, id] of SIGMA.STAR_REWARDS) {
    const r = el('div', `q-row${q.stars >= n ? ' done' : ''}`);
    r.append(el('span', '', `${q.stars >= n ? '✅' : '🔒'} ${n} ⭐`), rewardTile(cat, id));
    sl.appendChild(r);
  }
}
$('#q-refresh').onclick = () => loadQuests().then(() => toast('Quests aktualisiert'));

// ---------- Secret Code ----------
const SECRET = 'SIGMAFREI';
function renderSecret() {
  const on = !!state.s.secretUnlock;
  SIGMA.setAllFree(on);
  $('#secret-state').textContent = on ? '✅ Alles freigeschaltet!' : '🔒 Noch nichts freigeschaltet.';
  $('#secret-off').hidden = !on;
}
$('#secret-go').onclick = async () => {
  const code = $('#secret-input').value.trim().toUpperCase().replace(/[\s-]/g, '');
  if (code !== SECRET) { toast('Falscher Code', 'err'); return; }
  await setSetting('secretUnlock', true);
  $('#secret-input').value = '';
  renderSecret();
  toast('🔓 Alle Cosmetics freigeschaltet!', 'ok');
};
$('#secret-input').onkeydown = (e) => { if (e.key === 'Enter') $('#secret-go').click(); };
$('#secret-off').onclick = async () => { await setSetting('secretUnlock', false); renderSecret(); };

// ---------- Updates ----------
async function checkUpdate() {
  const u = await api.update.check().catch(() => null);
  if (!u) return;
  $('#upd-text').textContent = `✨ Update ${u.version} ist da${u.notes ? ': ' + u.notes : ''}`;
  $('#upd-bar').hidden = false;
}
$('#upd-later').onclick = () => { $('#upd-bar').hidden = true; };
$('#upd-go').onclick = async () => {
  const b = $('#upd-go'); b.disabled = true; b.textContent = 'Wird geladen …';
  try { await api.update.install(); b.textContent = 'Neustart …'; }
  catch (e) { toast(errMsg(e), 'err'); b.disabled = false; b.textContent = 'Nochmal versuchen'; }
};

// ---------- Start ----------
(async () => {
  const [s, info] = await Promise.all([api.settings.get(), api.app.info()]);
  state.s = s; state.info = info;
  state.look = { ...DEFAULT_LOOK, ...(s.appearance || {}) };
  state.cosmetics = { ...(s.cosmetics || {}) };
  state.custom = { ...(s.cosmeticsCustom || {}) };
  try { syncWingSize(); } catch {}
  setCustom(state.custom);
  try { SIGMA.setUnlocks(await api.quests.get()); } catch { }
  renderSecret();
  applyLook();
  api.settings.set({ themeColors: themeColors() });
  initLookControls();
  initSettings();
  $('#loader').value = s.lastLoader === 'vanilla' ? 'vanilla' : 'fabric';
  state.account = await api.auth.status();
  renderAccount();
  await loadVersions();
  updateVerHint();
  checkUpdate();
})();
